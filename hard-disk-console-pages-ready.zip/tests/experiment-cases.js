import { HardDiskEngine } from '../src/engine.js';
import { createModel } from '../src/model.js';
import { spatialStatistics } from '../src/statistics.js';
import { ExperimentSession, ForwardReference, perturbPosition, rotateVelocity, deviations, modelUnits, REVERSAL_TOLERANCE } from '../src/experiments.js';

const cases = []; const test = (name, run) => cases.push({ name, run });
function assert(ok, message = 'Assertion failed') { if (!ok) throw Error(message); }
function close(a, b, tolerance = 1e-12) { assert(Number.isFinite(a) && Math.abs(a - b) < tolerance, `${a} != ${b}`); }
function rejects(fn, code) { let e; try { fn(); } catch (error) { e = error; } assert(e?.code === code, `Expected ${code}, got ${e?.code ?? e?.message ?? 'no error'}`); }
const disk = (x, y, vx, vy, radius = 0.05) => ({ x, y, vx, vy, radius, mass: 1 });
const physical = s => s.particles.map(p => [p.x, p.y, p.vx, p.vy]);
function reach(session, time, batch = 500) {
  let n = 0; while (session.commonTime < time && !session.complete) { session.advanceBatch({ maxEvents: batch, maxMillis: Infinity }); if (++n > 100000) throw Error('Controller failed to progress'); }
}
function finish(session, batch = 500) { let n = 0; while (!session.complete) { session.advanceBatch({ maxEvents: batch, maxMillis: Infinity }); if (++n > 100000) throw Error('Reversal failed to finish'); } }

test('相同双初态：delta=0，两独立堆、完整轨迹及快照相同', () => {
  for (const seed of [1, 42, 71]) {
    const s = new ExperimentSession(createModel(seed, 50), { mode: 'chaos', delta: 0 });
    assert(s.engines.A !== s.engines.B && s.engines.A.heap !== s.engines.B.heap);
    for (let k = 1; k <= 50; k++) { reach(s, k * 0.02); assert(JSON.stringify(s.engines.A.snapshot()) === JSON.stringify(s.engines.B.snapshot())); close(s.last.comparison.AB.phase, 0); }
  }
});
test('位置扰动：三档delta，Dx(0)=delta/sqrtN，能量／动量严格不变', () => {
  const results = [];
  for (const delta of [1e-6, 1e-8, 1e-10]) {
    const s = new ExperimentSession(createModel(42, 50), { mode: 'chaos', delta });
    close(s.last.comparison.AB.normalizedPosition, delta / Math.sqrt(50), 1e-16);
    assert(s.engines.A.state().energy === s.engines.B.state().energy); assert(JSON.stringify(s.engines.A.momentum()) === JSON.stringify(s.engines.B.momentum()));
    close(s.last.comparison.AB.velocity, 0); s.engines.B.validate(); s.engines.B.audit(); results.push({ delta, actualRms: s.last.comparison.AB.normalizedPosition });
  }
  return results;
});
test('非法位置扰动：重叠／越界拒绝，不自动改方向或原状态', () => {
  const e = new HardDiskEngine({ box: { x: 1, y: 0.6 }, particles: [disk(0.3, 0.3, 1, 0), disk(0.400001, 0.3, 0, 0)] }), s = e.snapshot(), before = JSON.stringify(s);
  rejects(() => perturbPosition(s, 0, 1e-5), 'POSITION_PERTURBATION_OVERLAP');
  rejects(() => perturbPosition(s, 0, 1, { x: -1, y: 0 }), 'POSITION_PERTURBATION_OUTSIDE');
  assert(JSON.stringify(s) === before); rejects(() => new ExperimentSession(createModel(1, 50), { mode: 'reversal', particle: 50 }), 'EXPERIMENT_PARTICLE_INDEX');
});
test('三分支同源：精确相同fork快照，A未干预，B全反号，C仅一个旋转', () => {
  const cfg = createModel(42, 50), s = new ExperimentSession(cfg, { mode: 'reversal', reversalTime: 0.5, angle: 1e-6 }); reach(s, 0.5);
  const source = s.forkSnapshot(), normal = new HardDiskEngine(cfg); normal.advanceTo(0.5);
  assert(JSON.stringify(source) === JSON.stringify(normal.snapshot()));
  assert(JSON.stringify(source) === JSON.stringify(s.engines.A.snapshot()));
  const src = HardDiskEngine.restore(source).state(), B = s.engines.B.state(), C = s.engines.C.state();
  B.particles.forEach((p, i) => { assert(p.x === src.particles[i].x && p.y === src.particles[i].y); assert(p.vx === -src.particles[i].vx && p.vy === -src.particles[i].vy); });
  for (let i = 1; i < C.particles.length; i++) assert(JSON.stringify(physical({ particles: [C.particles[i]] })) === JSON.stringify(physical({ particles: [B.particles[i]] })));
  close(Math.hypot(C.particles[0].vx, C.particles[0].vy), Math.hypot(B.particles[0].vx, B.particles[0].vy));
  source.particles[0].vx = 123; assert(s.forkSnapshot().particles[0].vx !== 123);
});
test('反演事件队列：独立重建、版本有效，与源未来事件不同', () => {
  const s = new ExperimentSession(createModel(42, 50), { mode: 'reversal', reversalTime: 0.5 }); reach(s, 0.5);
  const source = HardDiskEngine.restore(s.forkSnapshot()), future = source.nextEvent();
  const referenceB = HardDiskEngine.restore(s.forkSnapshot()); referenceB.reverseVelocities();
  assert(JSON.stringify(referenceB.nextEvent()) === JSON.stringify(s.engines.B.nextEvent()));
  assert(JSON.stringify(future) !== JSON.stringify(s.engines.B.nextEvent()));
  for (const e of Object.values(s.engines)) { e.heap.assertValid(); assert(e.nextEvent().time >= e.time); }
  assert(s.engines.A.heap !== s.engines.B.heap && s.engines.C.heap !== s.engines.B.heap);
});
test('C角度干预：能量容差内不变、独立累计外部动量余额', () => {
  const e = new HardDiskEngine(createModel(71, 50)); e.advanceTo(0.5); e.reverseVelocities();
  const before = e.state(), after = rotateVelocity(e, 0, 1e-6), state = after.engine.state();
  close(state.energy, before.energy, 1e-12); close(after.engine.momentumBalance().norm, 0, 1e-12);
  const p = before.particles[0], q = state.particles[0]; close(after.intervention.deltaMomentum.x, p.mass * (q.vx - p.vx)); close(after.intervention.deltaMomentum.y, p.mass * (q.vy - p.vy));
  assert(JSON.stringify(before) === JSON.stringify(e.state()));
});
test('只读参考：非网格时刻自由飞行查询与真实前向轨迹一致', () => {
  const cfg = createModel(71, 50), s = new ExperimentSession(cfg, { mode: 'reversal', reversalTime: 0.517 }); reach(s, 0.517);
  let max = 0;
  for (const time of [0, 0.0137, 0.1333, 0.3991, 0.50123]) {
    const e = new HardDiskEngine(cfg); e.advanceTo(time); const ref = s.referenceAt(time), real = e.state();
    real.particles.forEach((p, i) => { const q = ref.particles[i]; max = Math.max(max, Math.hypot(p.x - q.x, p.y - q.y), Math.hypot(p.vx - q.vx, p.vy - q.vy)); });
  }
  assert(max < 1e-12); const ref = s.referenceAt(0.1333); ref.particles[0].x = -999; assert(s.referenceAt(0.1333).particles[0].x !== -999); return { maximumReferenceError: max };
});
test('参考碰撞时刻：位置连续、速度比较明确歧义', () => {
  const e = new HardDiskEngine({ box: { x: 1, y: 0.6 }, particles: [disk(0.5, 0.3, 1, 0)] }), ref = new ForwardReference(e.state());
  const event = e.step(); ref.record(event, e.state()); ref.maxTime = 0.6;
  assert(ref.at(event.time).collisionAmbiguous); close(ref.at(event.time).particles[0].x, 0.95);
});
test('指定反演恰为碰撞：显式稍移实际T，真实推进后分叉', () => {
  const cfg = { box: { x: 1, y: 0.6 }, particles: [disk(0.5, 0.3, 1, 0)] };
  const collision = new HardDiskEngine(cfg).nextEvent().time;
  const s = new ExperimentSession(cfg, { mode: 'reversal', reversalTime: collision, angle: 0 }); finish(s);
  assert(s.actualForkTime > s.requestedForkTime); assert(s.actualForkTime - s.requestedForkTime < 1e-7);
  close(s.last.comparison.B.normalizedPosition, 0, 1e-12); close(s.last.comparison.B.normalizedVelocity, 0);
  return { requested: s.requestedForkTime, actual: s.actualForkTime };
});
test('短程反演：3固定50粒子种子、至少20次粒子碰撞，RMS<1e-8', () => {
  const results = [];
  for (const seed of [1, 42, 71]) {
    const s = new ExperimentSession(createModel(seed, 50), { mode: 'reversal', reversalTime: 0.5, angle: 1e-8, validateEveryEvent: true }); finish(s);
    assert(s.forkSnapshot().pairCollisions >= 20); const b = s.last.comparison.B;
    assert(b.normalizedPosition < REVERSAL_TOLERANCE && b.normalizedVelocity < REVERSAL_TOLERANCE);
    assert(s.engines.B.pairCollisions - s.forkSnapshot().pairCollisions === s.forkSnapshot().pairCollisions);
    results.push({ seed, forwardPairs: s.forkSnapshot().pairCollisions, positionRms: b.normalizedPosition, negatedVelocityRms: b.normalizedVelocity, reliability: s.reliability });
  }
  return results;
});
test('无扰动C：theta=0时B/C轨迹、完整快照和熵严格相同', () => {
  const s = new ExperimentSession(createModel(42, 50), { mode: 'reversal', reversalTime: 0.5, angle: 0 }); finish(s);
  assert(JSON.stringify(s.engines.B.snapshot()) === JSON.stringify(s.engines.C.snapshot()));
  for (const p of s.history().filter(p => p.BEntropy !== null)) assert(p.BEntropy === p.CEntropy);
});
test('三分支能量／动量／每事件穿透：50/100粒子实际反演', () => {
  const results = [];
  for (const count of [50, 100]) {
    const s = new ExperimentSession(createModel(42, count, 'left'), { mode: 'reversal', reversalTime: 0.5, angle: 1e-6, validateEveryEvent: true }); finish(s);
    for (const [key, e] of Object.entries(s.engines)) {
      assert(e.maxRelativeEnergyError < 1e-10); assert(e.momentumBalance().norm < 1e-10); const a = e.audit();
      assert(Math.min(a.minGap, a.minWallGap, a.minFlightGap) > -1e-10);
      results.push({ count, branch: key, collisions: e.collisions, maxEnergyError: e.maxRelativeEnergyError, momentumBalance: e.momentumBalance().norm, audit: a });
    }
  }
  return results;
});
test('帧率／采样间隔／批量：固定最终物理时刻各分支状态逐位一致', () => {
  const cfg = createModel(42, 50), runs = [];
  for (const mode of ['chaos', 'reversal']) {
    let expected = null;
    for (const interval of [0.01, 0.02, 0.05]) for (const batch of [1, 7, 500]) {
      const s = new ExperimentSession(cfg, { mode, sampleInterval: interval, reversalTime: 0.5 });
      if (mode === 'chaos') reach(s, 1, batch); else finish(s, batch);
      // Rendering/observation repeated at 15/30/60 fps equivalents never advances anything.
      for (const fps of [15, 30, 60]) for (let i = 0; i < fps; i++) { const copy = JSON.parse(JSON.stringify(s.last)); spatialStatistics(copy.states.A); }
      const states = JSON.stringify(Object.fromEntries(Object.entries(s.engines).map(([k, e]) => [k, e.snapshot()])));
      expected ??= states; assert(states === expected, `${mode} interval=${interval} batch=${batch}`); runs.push({ mode, interval, batch });
    }
  }
  return { strictComparisons: runs.length };
});
test('暂停中的半同步快照：保存各分支进度，恢复不丢事件不改轨迹', () => {
  const cfg = createModel(42, 50), s = new ExperimentSession(cfg, { mode: 'chaos' });
  const partial = s.advanceBatch({ maxEvents: 1, maxMillis: Infinity }); assert(!partial.reached && s.pendingTarget !== null);
  assert(s.last.time === 0); const restored = ExperimentSession.restore(JSON.parse(JSON.stringify(s.snapshot())));
  assert(JSON.stringify(s.snapshot()) === JSON.stringify(restored.snapshot())); reach(s, 1); reach(restored, 1, 7);
  for (const key of ['A', 'B']) assert(JSON.stringify(s.engines[key].snapshot()) === JSON.stringify(restored.engines[key].snapshot()));
});
test('前向／分叉后快照恢复：参考、历史和正常继续严格一致', () => {
  const cfg = createModel(71, 50), baseline = new ExperimentSession(cfg, { mode: 'reversal', reversalTime: 0.5 }); finish(baseline);
  for (const time of [0.1, 0.5, 0.7]) {
    const s = new ExperimentSession(cfg, { mode: 'reversal', reversalTime: 0.5 }); reach(s, time, 7);
    const r = ExperimentSession.restore(JSON.parse(JSON.stringify(s.snapshot()))); finish(r, 1);
    for (const key of ['A', 'B', 'C']) assert(JSON.stringify(r.engines[key].snapshot()) === JSON.stringify(baseline.engines[key].snapshot()));
    assert(JSON.stringify(r.history()) === JSON.stringify(baseline.history()));
  }
});
test('非零起点物理快照：返回参考精确落在原起点，无相减越界', () => {
  const e = new HardDiskEngine(createModel(42, 50)); e.advanceTo(0.127);
  const s = new ExperimentSession(e.snapshot(), { mode: 'reversal', reversalTime: 0.5 }); finish(s);
  assert(s.last.comparison.referenceTime === 0.127);
  assert(s.last.comparison.B.normalizedPosition < 1e-8 && s.last.comparison.B.normalizedVelocity < 1e-8);
  return { origin: s.origin, finalTime: s.commonTime, referenceTime: s.last.comparison.referenceTime, B: s.last.comparison.B };
});
test('熵实线来源：每个实际分支状态独立计算，不引用反向熵驱动', () => {
  const s = new ExperimentSession(createModel(42, 50, 'left'), { mode: 'reversal', reversalTime: 0.5, angle: 1e-6 });
  while (!s.complete) {
    const r = s.advanceBatch({ maxMillis: Infinity }); if (!r.reached) continue;
    for (const [key, state] of Object.entries(s.last.states)) close(s.last.point[`${key}Entropy`], spatialStatistics(state).entropy);
    if (s.phase === 'reversed') close(s.last.point.referenceEntropy, spatialStatistics(s.referenceAt(s.last.comparison.referenceTime)).entropy);
  }
  assert(s.last.point.BPosition !== null && s.last.point.CPosition !== null);
});
test('超可信基线：真实长一点反演触发告警，不把失败当物理不可逆', () => {
  const s = new ExperimentSession(createModel(1, 50), { mode: 'reversal', reversalTime: 1 }); finish(s);
  assert(!s.reliability.trustworthy && s.reliability.firstExceededTime !== null); assert(s.reliability.reasons.includes('B_BASELINE_THRESHOLD_EXCEEDED'));
  return { firstExceededTime: s.reliability.firstExceededTime, finalB: s.last.comparison.B, finalC: s.last.comparison.C };
});
test('同种子／扰动重置：三档实际混沌曲线严格可重复', () => {
  const results = [];
  for (const delta of [1e-6, 1e-8, 1e-10]) {
    const options = { mode: 'chaos', delta }, a = new ExperimentSession(createModel(71, 50), options), b = new ExperimentSession(createModel(71, 50), options);
    reach(a, 1); reach(b, 1, 7); assert(JSON.stringify(a.history()) === JSON.stringify(b.history()));
    results.push({ delta, final: a.last.comparison.AB });
  }
  return results;
});
test('参考限额／无效实验快照：明确拒绝，未伪造缺失历史', () => {
  const s = new ExperimentSession(createModel(42, 50), { mode: 'reversal' }), snapshot = s.snapshot();
  rejects(() => ExperimentSession.restore({ ...snapshot, experimentVersion: 'unknown' }), 'EXPERIMENT_SNAPSHOT_SCHEMA');
  const ref = new ForwardReference(new HardDiskEngine(createModel(42, 50)).state()), data = ref.snapshot();
  data.events = new Array(20001).fill({ time: 0, uncertainty: 1e-12 }); rejects(() => ForwardReference.restore(data), 'REFERENCE_SNAPSHOT');
});
test('NUMERICAL_OVERLAP不隐藏：分支日志保留且无能量／坐标纠偏', () => {
  const s = new ExperimentSession(createModel(1, 50), { mode: 'reversal', reversalTime: 0.5 }); finish(s);
  assert(s.engines.B.diagnostics.counts.NUMERICAL_OVERLAP > 0);
  assert(!s.engines.B.diagnostics.counts.STABILIZATION_COLLISION); return Object.fromEntries(Object.entries(s.engines).map(([key, e]) => [key, e.diagnostics.counts]));
});

export function runExperimentCases(onResult = () => {}) {
  const results = [];
  for (const c of cases) {
    const start = performance.now();
    try { results.push({ name: c.name, passed: true, metrics: c.run() ?? null, elapsedMs: performance.now() - start }); }
    catch (e) { results.push({ name: c.name, passed: false, error: { code: e.code, message: e.message, stack: e.stack }, elapsedMs: performance.now() - start }); }
    onResult(results.at(-1));
  }
  return { passed: results.filter(r => r.passed).length, failed: results.filter(r => !r.passed).length, results };
}
