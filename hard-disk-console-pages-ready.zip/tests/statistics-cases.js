import { HardDiskEngine } from '../src/engine.js';
import { createModel } from '../src/model.js';
import { entropyFromCounts, spatialStatistics, speedStatistics, maxwellBinProbabilities, sampleStatistics, SampleHistory, SPEED_EDGES, SAMPLE_INTERVAL } from '../src/statistics.js';

const cases = [];
const test = (name, run) => cases.push({ name, run });
function assert(ok, message = 'Assertion failed') { if (!ok) throw new Error(message); }
function close(a, b, tol = 1e-12) { assert(Number.isFinite(a) && Math.abs(a - b) < tol, `${a} != ${b}`); }
function rejects(run, code) { let error; try { run(); } catch (e) { error = e; } assert(error?.code === code, `Expected ${code}, got ${error?.code ?? 'no error'}`); }
const particle = (x, y, vx = 0, vy = 0) => ({ x, y, vx, vy, radius: 0.01, mass: 1 });
const state = particles => ({ time: 0, box: { x: 1, y: 0.6 }, particles });

test('空间熵解析：全在一格为0，15格等计数为ln15', () => {
  close(entropyFromCounts([15, ...new Array(14).fill(0)]), 0);
  close(entropyFromCounts(new Array(15).fill(4)), Math.log(15));
  close(entropyFromCounts([1, 1, 0]), Math.log(2));
  rejects(() => entropyFromCounts([0, 0]), 'STATISTICS_EMPTY');
  rejects(() => entropyFromCounts([1, -1]), 'STATISTICS_COUNTS');
});
test('5×3中心可达网格：15格各1粒子，密度积分为N', () => {
  const ps = [];
  for (let row = 0; row < 3; row++) for (let col = 0; col < 5; col++) ps.push(particle(0.01 + 0.98 * (col + 0.5) / 5, 0.01 + 0.58 * (row + 0.5) / 3));
  const grid = spatialStatistics(state(ps));
  assert(grid.counts.every(n => n === 1)); close(grid.entropy, Math.log(15)); close(grid.densities.reduce((s, d) => s + d * grid.cellArea, 0), 15);
  close(grid.cellArea * 15, 0.98 * 0.58);
});
test('网格边界：四角各自归属，内部边界采取左闭右开', () => {
  const grid = spatialStatistics(state([particle(0.01, 0.01), particle(0.99, 0.01), particle(0.01, 0.59), particle(0.99, 0.59), particle(0.01 + 0.98 / 5, 0.01)]));
  assert(grid.counts[0] === 1 && grid.counts[4] === 1 && grid.counts[10] === 1 && grid.counts[14] === 1 && grid.counts[1] === 1);
  assert(grid.counts.reduce((s, n) => s + n, 0) === 5);
});
test('微小边界残差只分箱：显式计数，不修改坐标；超容差拒绝', () => {
  const s = state([particle(0.01 - 1e-14, 0.3)]), before = JSON.stringify(s), grid = spatialStatistics(s);
  assert(grid.boundaryAssignments === 1); assert(JSON.stringify(s) === before);
  rejects(() => spatialStatistics(state([particle(0.01 - 1e-10, 0.3)])), 'STATISTICS_OUTSIDE_GRID');
});
test('速率已知列表：8个固定箱、准确边界归属与溢出守恒', () => {
  const speeds = [0, 0.1, 0.375, 0.75, 1.125, 1.5, 1.875, 2.25, 2.625, 3, 5];
  const result = speedStatistics(speeds.map(v => particle(0.5, 0.3, v, 0)), 5.5);
  assert(JSON.stringify(result.counts) === JSON.stringify([2, 1, 1, 1, 1, 1, 1, 1, 2]));
  assert(result.counts.reduce((s, n) => s + n, 0) === speeds.length); close(result.probabilities.reduce((s, p) => s + p, 0), 1);
  close(result.rmsSpeed, Math.sqrt(speeds.reduce((s, v) => s + v * v, 0) / speeds.length));
});
test('二维Maxwell：已知CDF逐箱积分与解析溢出概率', () => {
  const r = maxwellBinProbabilities(50, 100), beta = 1;
  for (let i = 0; i < 8; i++) close(r.probabilities[i], Math.exp(-beta * SPEED_EDGES[i] ** 2) - Math.exp(-beta * SPEED_EDGES[i + 1] ** 2));
  close(r.probabilities[8], Math.exp(-9)); close(r.referenceTemperature, 0.5); close(r.beta, 1);
});
test('二维Maxwell：独立Simpson数值积分对照每箱', () => {
  const r = maxwellBinProbabilities(50, 100); let maxError = 0;
  for (let i = 0; i < 8; i++) {
    const lo = SPEED_EDGES[i], hi = SPEED_EDGES[i + 1], steps = 1000, dx = (hi - lo) / steps;
    const pdf = v => 2 * v * Math.exp(-v * v); let sum = pdf(lo) + pdf(hi);
    for (let k = 1; k < steps; k++) sum += (k % 2 ? 4 : 2) * pdf(lo + k * dx);
    const integral = sum * dx / 3; maxError = Math.max(maxError, Math.abs(integral - r.probabilities[i]));
  }
  assert(maxError < 1e-12); return { maxIntegrationError: maxError };
});
test('二维Maxwell：多能量／质量／N归一化，含尾部，无人工归一化', () => {
  let maxError = 0;
  for (const e of [0.001, 1, 25, 50, 100, 10000]) for (const n of [1, 50, 100, 200]) for (const mass of [0.2, 1, 3]) {
    const probabilities = maxwellBinProbabilities(e, n, mass).probabilities;
    assert(probabilities.every(p => p >= 0 && p <= 1)); maxError = Math.max(maxError, Math.abs(probabilities.reduce((s, p) => s + p, 0) - 1));
  }
  assert(maxError < 1e-12); return { combinations: 72, maximumNormalizationError: maxError };
});
test('零能量：连续Maxwell参考明确未定义，实际零速率仍计数', () => {
  const result = speedStatistics([particle(0.3, 0.3), particle(0.6, 0.3)], 0);
  assert(!result.reference.defined && result.reference.reason === 'ZERO_REFERENCE_TEMPERATURE'); assert(result.expectedCounts === null && result.counts[0] === 2);
});
test('统计无效输入：非有限速率／错误箱／负能量明确拒绝', () => {
  rejects(() => speedStatistics([particle(0.2, 0.3, NaN, 0)], 0.5), 'STATISTICS_NONFINITE');
  rejects(() => maxwellBinProbabilities(-1, 50), 'STATISTICS_MAXWELL_PARAMETERS');
  rejects(() => maxwellBinProbabilities(1, 50, 1, [0, 1]), 'STATISTICS_SPEED_EDGES');
});
test('两种非平衡初态复用：3种N、3个种子，合法构型与规定动能', () => {
  for (const n of [50, 100, 200]) for (const seed of [1, 42, 2026]) for (const preset of ['left', 'mono-speed']) {
    const cfg = createModel(seed, n, preset); assert(JSON.stringify(cfg) === JSON.stringify(createModel(seed, n, preset)));
    const engine = new HardDiskEngine(cfg); engine.audit(); close(engine.initialEnergy, n / 2, 1e-10);
    if (preset === 'left') assert(cfg.particles.every(p => p.x <= 0.5 - p.radius));
    if (preset === 'mono-speed') for (const p of cfg.particles) close(Math.hypot(p.vx, p.vy), 1);
  }
  return { legalInitialStates: 18 };
});
test('真实引擎取样：N=50/100/200、2种初态各101样本，总数与熵范围', () => {
  let maximumEntropy = 0, minimumEntropy = Infinity;
  for (const n of [50, 100, 200]) for (const preset of ['left', 'mono-speed']) {
    const engine = new HardDiskEngine(createModel(42, n, preset));
    for (let k = 0; k <= 100; k++) {
      engine.advanceTo(k * SAMPLE_INTERVAL); const stats = sampleStatistics(engine.state(), engine.initialEnergy);
      assert(stats.spatial.counts.reduce((s, v) => s + v, 0) === n && stats.speed.counts.reduce((s, v) => s + v, 0) === n);
      assert(stats.spatial.entropy >= -1e-12 && stats.spatial.entropy <= Math.log(15) + 1e-12);
      minimumEntropy = Math.min(minimumEntropy, stats.spatial.entropy); maximumEntropy = Math.max(maximumEntropy, stats.spatial.entropy);
    }
  }
  return { physicalSamples: 606, minimumEntropy, maximumEntropy };
});
test('统计纯函数：冻结输入，可重复读取，完整引擎快照不变', () => {
  const e = new HardDiskEngine(createModel(71, 100, 'left')); e.advanceTo(0.3);
  const before = JSON.stringify(e.snapshot()), s = e.state();
  s.particles.forEach(Object.freeze); Object.freeze(s.particles); Object.freeze(s.box); Object.freeze(s);
  const a = sampleStatistics(s, e.initialEnergy), b = sampleStatistics(s, e.initialEnergy);
  assert(JSON.stringify(a) === JSON.stringify(b)); assert(JSON.stringify(e.snapshot()) === before);
});
test('统计开关独立性：同物理时刻、不同采样与绘制频率，快照逐位一致', () => {
  let compared = 0;
  for (const preset of ['left', 'mono-speed']) for (const seed of [1, 42]) {
    const cfg = createModel(seed, 50, preset), plain = new HardDiskEngine(cfg); plain.advanceTo(2);
    const expected = JSON.stringify(plain.snapshot());
    for (const frequency of [15, 30, 60]) {
      const observed = new HardDiskEngine(cfg);
      for (let k = 1; k <= 100; k++) {
        observed.advanceTo(k * SAMPLE_INTERVAL); const s = observed.state();
        for (let j = 0; j < frequency / 15; j++) sampleStatistics(s, observed.initialEnergy);
      }
      assert(JSON.stringify(observed.snapshot()) === expected); compared++;
    }
  }
  return { strictSnapshotComparisons: compared };
});
test('自然统计涨落：真实轨迹熵存在下降段，原始值不被改写', () => {
  const e = new HardDiskEngine(createModel(42, 50, 'left')), history = new SampleHistory(); let decreases = 0, previous = null;
  for (let k = 0; k <= 300; k++) {
    e.advanceTo(k * SAMPLE_INTERVAL); const value = sampleStatistics(e.state(), e.initialEnergy).spatial.entropy;
    if (previous !== null && value < previous - 1e-12) decreases++;
    history.push({ time: e.time, entropy: value }); previous = value;
  }
  assert(decreases > 0); assert(history.toArray().at(-1).entropy === previous);
  return { samples: 301, decreasingSteps: decreases };
});
test('NUMERICAL_OVERLAP诊断保留：统计采样与无统计运行计数一致', () => {
  const cfg = createModel(1, 50), plain = new HardDiskEngine(cfg), observed = new HardDiskEngine(cfg);
  plain.advanceTo(2);
  for (let k = 1; k <= 100; k++) { observed.advanceTo(k * SAMPLE_INTERVAL); sampleStatistics(observed.state(), observed.initialEnergy); }
  assert(observed.diagnostics.counts.NUMERICAL_OVERLAP > 0);
  assert(JSON.stringify(observed.diagnostics) === JSON.stringify(plain.diagnostics));
  return { retainedNumericalOverlap: observed.diagnostics.counts.NUMERICAL_OVERLAP };
});
test('完整快照恢复后启用统计：继续运行状态及观测严格重现', () => {
  const e = new HardDiskEngine(createModel(2026, 50, 'mono-speed')); e.advanceTo(0.127);
  const restored = HardDiskEngine.restore(JSON.parse(JSON.stringify(e.snapshot())));
  for (let k = 1; k <= 20; k++) {
    const target = 0.127 + k * SAMPLE_INTERVAL; e.advanceTo(target); restored.advanceTo(target);
    assert(JSON.stringify(sampleStatistics(e.state(), e.initialEnergy)) === JSON.stringify(sampleStatistics(restored.state(), restored.initialEnergy)));
  }
  assert(JSON.stringify(e.snapshot()) === JSON.stringify(restored.snapshot()));
});
test('有界历史：10000次写入仅保留4096个原始点，次序和丢弃计数正确', () => {
  const h = new SampleHistory();
  for (let i = 0; i < 10000; i++) h.push({ time: i * SAMPLE_INTERVAL, entropy: i % 3 });
  assert(h.length === 4096 && h.dropped === 5904);
  const records = h.toArray(); assert(records[0].time === 5904 * SAMPLE_INTERVAL && records.at(-1).time === 9999 * SAMPLE_INTERVAL);
  records[0].entropy = -1; assert(h.toArray()[0].entropy !== -1);
  h.clear(); assert(h.length === 0 && h.dropped === 0);
});

export function runStatisticsCases(onResult = () => {}) {
  const results = [];
  for (const item of cases) {
    const start = performance.now();
    try { results.push({ name: item.name, passed: true, metrics: item.run() ?? null, elapsedMs: performance.now() - start }); }
    catch (error) { results.push({ name: item.name, passed: false, error: { message: error.message, code: error.code, stack: error.stack }, elapsedMs: performance.now() - start }); }
    onResult(results.at(-1));
  }
  return { passed: results.filter(r => r.passed).length, failed: results.filter(r => !r.passed).length, results };
}
