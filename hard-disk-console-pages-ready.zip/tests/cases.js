import { HardDiskEngine } from '../src/engine.js';
import { pairDelay, elasticPair, positionAt, PhysicsError } from '../src/physics.js';
import { IndexedMinHeap } from '../src/heap.js';
import { createGas, SeededRandom } from '../src/random.js';
import { createModel } from '../src/model.js';
import { FullScanReference } from '../src/reference.js';
import { reversalTest } from '../src/reversal.js';

function assert(ok, message = 'Assertion failed') { if (!ok) throw new Error(message); }
function close(actual, expected, tolerance = 1e-12) {
  assert(Number.isFinite(actual) && Math.abs(actual - expected) < tolerance, `${actual} != ${expected} (tol ${tolerance})`);
}
function throws(action, code) {
  let error; try { action(); } catch (e) { error = e; }
  assert(error?.code === code, `Expected ${code}, got ${error?.code ?? error?.message ?? 'no error'}`);
}
const disk = (x, y, vx, vy, radius = 0.05) => ({ x, y, vx, vy, radius, mass: 1, at: 0, version: 0 });
const config = particles => ({ box: { x: 1, y: 0.6 }, particles });
export const cases = [];
const test = (name, run) => cases.push({ name, run });

test('正面：解析接触时刻、单位法线、速度交换', () => {
  const a = disk(0.3, 0.3, 1, 0), b = disk(0.7, 0.3, -1, 0), e = new HardDiskEngine(config([a, b]));
  close(pairDelay(a, b, 0, 1e-12), 0.15); const event = e.step();
  close(event.time, 0.15); close(event.normal.x, -1); close(event.normal.y, 0);
  const p = e.state().particles; close(p[0].vx, -1); close(p[1].vx, 1); close(p[0].vy, 0);
  close(Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y), 0.1);
});
test('斜向：规范法线(3/5,4/5)与解析速度', () => {
  const a = disk(0.46, 0.38, -1, 0), b = disk(0.4, 0.3, 0, 0);
  const r = elasticPair(a, b, 0, 1e-12);
  close(r.normal.x, 0.6); close(r.normal.y, 0.8);
  close(r.p.vx, -0.64); close(r.p.vy, 0.48); close(r.q.vx, -0.36); close(r.q.vy, -0.48);
});
test('斜向：飞行后接触时刻及接触归一化', () => {
  const a = disk(0.66, 0.38, -1, 0), b = disk(0.4, 0.3, 0, 0);
  close(pairDelay(a, b, 0, 1e-12), 0.2);
  const e = new HardDiskEngine(config([a, b])); close(e.step().time, 0.2); close(e.state().particles[0].vy, 0.48);
});
for (const [label, vx, vy, axis] of [['左', -1, 0.1, 'x'], ['右', 1, 0.1, 'x'], ['下', 0.1, -1, 'y'], ['上', 0.1, 1, 'y']]) {
  test(`墙反射：${label}墙与冲量余额`, () => {
    const e = new HardDiskEngine(config([disk(0.5, 0.3, vx, vy)]));
    const event = e.step(), p = e.state().particles[0]; assert(event.kind === 'wall'); assert(event.axes[0] === axis);
    close(p.vx, axis === 'x' ? -vx : vx); close(p.vy, axis === 'y' ? -vy : vy);
    close(e.wallImpulse.x, p.vx - vx); close(e.wallImpulse.y, p.vy - vy); close(e.momentumBalance().norm, 0);
  });
}
test('精确角点：单墙事件、双分量反射、墙冲量', () => {
  const e = new HardDiskEngine({ box: { x: 1, y: 1 }, particles: [disk(0.5, 0.5, 1, 1, 0.125)] });
  assert(e.heap.size === 1); const ev = e.step(); assert(ev.axes.length === 2);
  close(e.state().particles[0].vx, -1); close(e.state().particles[0].vy, -1); close(e.wallImpulse.x, -2); close(e.wallImpulse.y, -2);
});
test('近角点：无法可靠排序时明确暂停', () => {
  const e = new HardDiskEngine({ box: { x: 1, y: 1 }, particles: [disk(0.5, 0.5, 1, 1 + 1e-15, 0.125)] });
  throws(() => e.step(), 'MULTIPLE_CONTACT'); assert(e.collisions === 0);
});
test('自由飞行：多次只读查询不写回Float64状态', () => {
  const e = new HardDiskEngine(config([disk(0.5, 0.3, 0.1, 0.2)])), before = JSON.stringify(e.snapshot().particles);
  for (const t of [0.01, 0.05, 0.1]) {
    e.advanceTo(t); const p = e.state().particles[0]; close(p.x, 0.5 + 0.1 * t); close(p.y, 0.3 + 0.2 * t);
  }
  assert(JSON.stringify(e.snapshot().particles) === before);
});
test('高速：10^6倍速度，解析时间缩放，无穿透', () => {
  const e = new HardDiskEngine(config([disk(0.3, 0.3, 1e6, 0), disk(0.7, 0.3, -1e6, 0)]));
  close(e.step().time, 0.15 / 1e6, 1e-18); close(e.state().particles[0].vx, -1e6); close(e.state().particles[1].vx, 1e6); e.audit();
});
test('高速斜向：映射按速度缩放', () => {
  const e = new HardDiskEngine(config([disk(0.66, 0.38, -1e6, 0), disk(0.4, 0.3, 0, 0)]));
  close(e.step().time, 0.2e-6, 1e-18); close(e.state().particles[0].vx / 1e6, -0.64); close(e.state().particles[0].vy / 1e6, 0.48); e.audit();
});
test('精确擦边：零冲量，显式分类，不制造碰撞', () => {
  const notes = [], a = disk(0.1, 0.25, 1, 0, 0.0625), b = disk(0.5, 0.375, 0, 0, 0.0625);
  assert(pairDelay(a, b, 0, 1e-12, code => notes.push(code)) === null); assert(notes.includes('GRAZING'));
});
test('近擦边命中与错开：三类不混淆', () => {
  const a = disk(0.1, 0.2, 1, 0), hit = disk(0.5, 0.3 - 1e-9, 0, 0), miss = disk(0.5, 0.3 + 1e-9, 0, 0);
  assert(pairDelay(a, hit, 0, 1e-12) > 0); assert(pairDelay(a, miss, 0, 1e-12) === null);
});
test('判别式不确定：明确报告数值擦边歧义', () => {
  throws(() => pairDelay(disk(0.1, 0.2, 1, 0), disk(0.5, 0.3 + 1e-15, 0, 0), 0, 1e-12), 'NUMERICAL_GRAZING_AMBIGUITY');
});
test('相对静止与已分离接触：不重复反射', () => {
  assert(pairDelay(disk(0.3, 0.3, 1, 0), disk(0.4, 0.3, 1, 0), 0, 1e-12) === null);
  assert(pairDelay(disk(0.3, 0.3, -1, 0), disk(0.4, 0.3, 1, 0), 0, 1e-12) === null);
});
test('微小重叠接近：零时刻稳定化并记录，禁止移动位置', () => {
  const e = new HardDiskEngine(config([disk(0.3, 0.3, 1, 0), disk(0.4 - 1e-14, 0.3, -1, 0)]));
  const before = e.state().particles.map(p => [p.x, p.y]); close(e.step().time, 0);
  assert(e.diagnostics.counts.STABILIZATION_COLLISION > 0);
  assert(JSON.stringify(e.state().particles.map(p => [p.x, p.y])) === JSON.stringify(before));
});
test('微小重叠分离：报告后自由脱离，不反射', () => {
  const e = new HardDiskEngine(config([disk(0.3, 0.3, -1, 0), disk(0.4 - 1e-14, 0.3, 1, 0)]));
  assert(e.diagnostics.counts.NUMERICAL_OVERLAP > 0); e.advanceTo(0.01); assert(e.collisions === 0); assert(!e.diagnostics.counts.STABILIZATION_COLLISION);
});
test('超过位置容差的重叠：拒绝初态', () => {
  throws(() => new HardDiskEngine(config([disk(0.3, 0.3, 1, 0), disk(0.4 - 1e-11, 0.3, -1, 0)])), 'OVERLAP');
});
test('三盘同时接触：暂停且不更新速度', () => {
  const e = new HardDiskEngine(config([disk(0.3, 0.3, 1, 0), disk(0.5, 0.3, 0, 0), disk(0.7, 0.3, -1, 0)]));
  const before = e.snapshot().particles; throws(() => e.step(), 'MULTIPLE_CONTACT');
  assert(e.collisions === 0); assert(JSON.stringify(before) === JSON.stringify(e.snapshot().particles)); assert(e.halted);
});
test('静止第三盘接触：也识别耦合接触图', () => {
  const e = new HardDiskEngine(config([disk(0.3, 0.3, 1, 0), disk(0.5, 0.3, 0, 0), disk(0.6, 0.3, 0, 0)]));
  throws(() => e.step(), 'MULTIPLE_CONTACT');
});
test('粒子—粒子—墙同时接触：暂停', () => {
  const e = new HardDiskEngine(config([disk(0.15, 0.3, -1, 0), disk(0.05, 0.3, 0, 0)]));
  throws(() => e.step(), 'MULTIPLE_CONTACT');
});
test('不相交同时事件：按键确定排序并全部处理', () => {
  const e = new HardDiskEngine(config([disk(0.3, 0.15, -1, 0), disk(0.3, 0.45, -1, 0)]));
  close(e.step().time, 0.25); close(e.step().time, 0.25); assert(e.collisions === 2); e.audit();
});
test('浮点异常：非有限初值与运算溢出拒绝', () => {
  throws(() => new HardDiskEngine(config([disk(0.5, 0.3, Infinity, 0)])), 'FLOAT_NONFINITE');
  throws(() => new HardDiskEngine(config([disk(0.5, 0.3, 1e308, 0)])), 'FLOAT_NONFINITE');
});
test('时间正增量无法表示：明确暂停条件', () => {
  const p = disk(0.5, 0.3, 1, 0); p.at = 1e16;
  throws(() => new HardDiskEngine({ ...config([p]), time: 1e16 }), 'TIME_RESOLUTION');
});
test('时间原点重设：物理状态与下一延迟保持', () => {
  const e = new HardDiskEngine(config([disk(0.5, 0.3, 1, 0)])); e.advanceTo(0.123);
  const p = e.state().particles, delay = e.nextEvent().time - e.time; e.rebaseTimeOrigin();
  assert(e.time === 0); close(e.nextEvent().time, delay); close(e.timeOrigin, 0.123);
  close(e.state().particles[0].x, p[0].x); close(e.state().particles[0].vx, p[0].vx);
});
test('索引堆：随机替换、删除、弹出与独立排序对照', () => {
  const heap = new IndexedMinHeap(), rng = new SeededRandom(31), map = new Map();
  for (let i = 0; i < 5000; i++) {
    const key = `k${Math.floor(rng.next() * 100)}`;
    if (rng.next() < 0.3) { heap.delete(key); map.delete(key); }
    else { const event = { key, time: rng.next() * 100 }; heap.set(event); map.set(key, event); }
    heap.assertValid(); assert(heap.size === map.size);
    const sorted = [...map.values()].sort((a, b) => a.time - b.time || (a.key < b.key ? -1 : 1));
    assert(JSON.stringify(heap.peek()) === JSON.stringify(sorted[0]));
  }
  let last = -Infinity; while (heap.size) { const e = heap.pop(); assert(e.time >= last); last = e.time; heap.assertValid(); }
});
test('过期事件版本防线：检测后不执行', () => {
  const e = new HardDiskEngine(config([disk(0.5, 0.3, 1, 0)])); e.heap.peek().versions[0]++;
  throws(() => e.step(), 'STALE_EVENT'); assert(e.collisions === 0);
});
test('全扫描参考：10个种子，逐事件独立数学与状态对照', () => {
  let maxTimeError = 0, maxPositionError = 0, maxVelocityError = 0;
  for (let seed = 1; seed <= 10; seed++) {
    const cfg = createGas(seed, 8, 20, 0.15), engine = new HardDiskEngine(cfg);
    for (let k = 0; k < 300; k++) {
      // Reanchor reference to SAME pre-event state: isolates scheduling correctness from
      // exponential amplification of independent arithmetic paths over long trajectories.
      const ref = new FullScanReference(engine.state());
      const a = engine.step(), b = ref.step();
      assert(a.kind === b.kind && a.i === b.i && a.j === b.j, `event mismatch seed=${seed} k=${k}`);
      if (a.kind === 'wall') assert(a.axes.length === 1 && a.axes[0] === b.axis && a.sides[0] === b.side);
      maxTimeError = Math.max(maxTimeError, Math.abs(a.time - b.time));
      engine.state().particles.forEach((p, i) => {
        maxPositionError = Math.max(maxPositionError, Math.hypot(p.x - ref.particles[i].x, p.y - ref.particles[i].y));
        maxVelocityError = Math.max(maxVelocityError, Math.hypot(p.vx - ref.particles[i].vx, p.vy - ref.particles[i].vy));
      });
      engine.heap.assertValid(); engine.audit();
    }
  }
  assert(maxTimeError < 2e-11 && maxPositionError < 2e-11 && maxVelocityError < 2e-11, JSON.stringify({ maxTimeError, maxPositionError, maxVelocityError }));
  return { mode: 'same-state next-event full scan', comparedEvents: 3000, maxTimeError, maxPositionError, maxVelocityError };
});
test('全扫描参考：解析二粒子连续独立轨迹，300事件', () => {
  let maxTimeError = 0, maxPositionError = 0, maxVelocityError = 0;
  {
    const cfg = { box: { x: 1, y: 1 }, particles: [disk(0.25, 0.5, 1, 0, 0.0625), disk(0.75, 0.5, -1, 0, 0.0625)] };
    const engine = new HardDiskEngine(cfg), ref = new FullScanReference(cfg);
    for (let k = 0; k < 300; k++) {
      const a = engine.step(), b = ref.step(); assert(a.kind === b.kind && a.i === b.i && a.j === b.j);
      maxTimeError = Math.max(maxTimeError, Math.abs(a.time - b.time));
      engine.state().particles.forEach((p, i) => {
        maxPositionError = Math.max(maxPositionError, Math.hypot(p.x - ref.particles[i].x, p.y - ref.particles[i].y));
        maxVelocityError = Math.max(maxVelocityError, Math.hypot(p.vx - ref.particles[i].vx, p.vy - ref.particles[i].vy));
      });
    }
  }
  assert(maxTimeError < 2e-11 && maxPositionError < 2e-11 && maxVelocityError < 2e-11, JSON.stringify({ maxTimeError, maxPositionError, maxVelocityError }));
  return { mode: 'continuous independent trajectory', comparedEvents: 300, maxTimeError, maxPositionError, maxVelocityError };
});
test('完整快照恢复：总是重建队列，连续运行严格重现', () => {
  const e = new HardDiskEngine(createModel(123, 50)); e.advanceTo(0.127);
  const s = JSON.parse(JSON.stringify(e.snapshot())), restored = HardDiskEngine.restore(s);
  assert(!('events' in s)); assert(JSON.stringify(e.nextEvent()) === JSON.stringify(restored.nextEvent()));
  e.advanceTo(0.5); restored.advanceTo(0.5);
  assert(JSON.stringify(e.snapshot()) === JSON.stringify(restored.snapshot()));
  throws(() => HardDiskEngine.restore({ ...s, engineVersion: 'bogus' }), 'SNAPSHOT_SCHEMA');
});
test('短程反演：至少20次碰撞，返回位置与反号速度RMS', () => {
  const cfg = config([disk(0.21, 0.18, 0.713, 0.237, 0.025), disk(0.72, 0.42, -0.319, 0.817, 0.025)]);
  const result = reversalTest(cfg, 12.345, 120);
  assert(result.outwardCollisions >= 20); assert(result.strictBenchmarkEligible); assert(result.outwardCollisions === result.returnCollisions);
  assert(result.rmsPositionError < 1e-8 && result.rmsNegatedVelocityError < 1e-8, JSON.stringify(result)); return result;
});
test('碰撞时刻反演：拒绝，要求明确选择非事件时刻', () => {
  const e = new HardDiskEngine(config([disk(0.5, 0.3, 1, 0)])); e.step(); throws(() => e.reverseVelocities(), 'REVERSAL_AT_COLLISION');
});
test('低占据率50粒子短程反演：3固定种子，各至少20次粒子碰撞', () => {
  const results = [1, 42, 71].map(seed => ({ seed, ...reversalTest(createModel(seed, 50), 0.5, 50) }));
  for (const r of results) {
    assert(r.outwardPairCollisions >= 20 && r.strictBenchmarkEligible);
    assert(r.outwardPairCollisions === r.returnPairCollisions && r.outwardCollisions === r.returnCollisions);
    assert(r.rmsPositionError < 1e-8 && r.rmsNegatedVelocityError < 1e-8, JSON.stringify(r));
  }
  return results;
});
test('帧率与分批独立：15/30/60fps、无渲染与暂停', () => {
  const cfg = createModel(9, 50), baseline = new HardDiskEngine(cfg); baseline.advanceTo(0.8);
  const expected = JSON.stringify(baseline.snapshot());
  for (const fps of [15, 30, 60]) {
    const e = new HardDiskEngine(cfg);
    for (let i = 1; i <= fps; i++) { e.advanceTo(0.8 * i / fps); e.state(); }
    assert(JSON.stringify(e.snapshot()) === expected, `${fps} fps changed physics`);
  }
  for (const batch of [1, 7, 500]) {
    const e = new HardDiskEngine(cfg); let result;
    do { result = e.advanceTo(0.8, batch); e.state(); } while (!result.reached);
    assert(JSON.stringify(e.snapshot()) === expected, `batch ${batch} changed physics`);
  }
});
test('默认模型：50/100/200粒子、5:3、phi=.01、RMS单位', () => {
  for (const n of [50, 100, 200]) {
    const cfg = createModel(10, n), e = new HardDiskEngine(cfg);
    close(cfg.box.x / cfg.box.y, 5 / 3); close(n * Math.PI * cfg.particles[0].radius ** 2 / 0.6, 0.01); close(e.initialEnergy / n, 0.5);
    assert(e.heap.size <= n * (n - 1) / 2 + n); e.audit();
  }
  assert(JSON.stringify(createModel(10)) === JSON.stringify(createModel(10)));
});
test('等质量等半径约束：拒绝异质参数', () => {
  const a = disk(0.2, 0.2, 0, 0), b = { ...disk(0.7, 0.4, 0, 0), mass: 2 };
  throws(() => new HardDiskEngine(config([a, b])), 'UNEQUAL_MODEL_PARAMETERS');
});
test('两种初态：左半扩散／等速松弛，无隐式零动量', () => {
  const left = createModel(71, 50, 'left'), mono = createModel(71, 50, 'mono-speed');
  assert(left.particles.every(p => p.x <= 0.5 - p.radius));
  for (const p of mono.particles) close(Math.hypot(p.vx, p.vy), 1);
  new HardDiskEngine(left).audit(); new HardDiskEngine(mono).audit();
});
test('穿透审计：每事件全对检查及下一次飞行最小间距', () => {
  const e = new HardDiskEngine(createModel(721, 50)); let minGap = 0;
  for (let k = 0; k < 2000; k++) { e.audit(); e.step(); const audit = e.audit(); minGap = Math.min(minGap, audit.minGap, audit.minFlightGap, audit.minWallGap); }
  assert(minGap >= -1e-10); return { events: 2000, minimumGap: minGap };
});

export function runCases(onResult = () => {}) {
  const results = [];
  for (const item of cases) {
    const start = performance.now();
    try { const metrics = item.run(); results.push({ name: item.name, passed: true, elapsedMs: performance.now() - start, metrics: metrics ?? null }); }
    catch (error) { results.push({ name: item.name, passed: false, elapsedMs: performance.now() - start, error: { message: error.message, code: error.code, stack: error.stack } }); }
    onResult(results[results.length - 1]);
  }
  return { passed: results.filter(r => r.passed).length, failed: results.filter(r => !r.passed).length, results };
}
