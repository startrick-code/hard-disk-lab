import { runFluxCases } from './flux-cases.js';
import { runCorrelationCases } from './correlation-cases.js';
import { runCases } from './cases.js';
import { runStatisticsCases } from './statistics-cases.js';
import { runExperimentCases } from './experiment-cases.js';
const run = document.getElementById('run'), summary = document.getElementById('summary'), results = document.getElementById('results');
run.onclick = () => {
  run.disabled = true; summary.textContent = '正在执行…'; results.textContent = '';
  setTimeout(() => {
    const display = r => { results.textContent += `${r.passed ? 'PASS' : 'FAIL'} ${r.name}${r.error ? ': ' + r.error.message : ''}\n`; };
    const core = runCases(display), statistics = runStatisticsCases(display), experiments = runExperimentCases(display);
    const correlations = runCorrelationCases(display);
    const flux = runFluxCases(display);
    const report = { core, statistics, experiments, correlations, flux, passed: flux.passed + correlations.passed + core.passed + statistics.passed + experiments.passed, failed: flux.failed + correlations.failed + core.failed + statistics.failed + experiments.failed };
    window.testReport = { executedAt: new Date().toISOString(), userAgent: navigator.userAgent, ...report };
    summary.textContent = `${report.passed} 通过，${report.failed} 失败`; summary.className = report.failed ? 'fail' : 'pass'; run.disabled = false;
  }, 0);
};
