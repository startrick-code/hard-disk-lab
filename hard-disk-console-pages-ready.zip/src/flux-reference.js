/** D1: independent local empirical-product contact measure; never writes to physics. */
import { SeededRandom } from './random.js';
const clone=x=>structuredClone(x), zero=()=>[0,0,0,0];
export function incomingFlux(a,b,n){const w=-((a.vx-b.vx)*n.x+(a.vy-b.vy)*n.y);if(!Number.isFinite(w))throw Error('NONFINITE_FLUX');return Math.max(0,w);}
export function symmetricBins(a,b){const x=a.vx>0?1:0,y=b.vx>0?1:0,c=zero();c[2*x+y]+=.5;c[2*y+x]+=.5;return c;}
export function inRegion(z,box,r,region){
  if(region==='all')return true;
  if(region==='left')return z.x<box.x/2;
  if(region==='right')return z.x>=box.x/2;
  const inside=z.x>=5*r&&z.x<=box.x-5*r&&z.y>=5*r&&z.y<=box.y-5*r;
  if(region==='interior')return inside;if(region==='wall')return !inside;throw Error('INVALID_REGION');
}
export function contactGeometry(z,n,box,r){const a={x:z.x+r*n.x,y:z.y+r*n.y},b={x:z.x-r*n.x,y:z.y-r*n.y};const inside=p=>p.x>=r&&p.x<=box.x-r&&p.y>=r&&p.y<=box.y-r;return {a,b,valid:inside(a)&&inside(b)};}
function moments(){return {n:0,w:0,w2:0,bins:zero(),xx:zero(),xw:zero()};}
export function addWeighted(m,c,w){if(!Number.isFinite(w)||w<0)throw Error('INVALID_WEIGHT');m.n++;m.w+=w;m.w2+=w*w;for(let k=0;k<4;k++){const x=w*c[k];m.bins[k]+=x;m.xx[k]+=x*x;m.xw[k]+=x*w;}}
export function summarizeMoments(m){return {proposals:m.n,totalWeight:m.w,probability:m.w?m.bins.map(x=>x/m.w):null,ess:m.w2?m.w*m.w/m.w2:0};}
function scaledAdd(target,m,scale){target.n+=m.n;target.w+=scale*m.w;target.w2+=scale*scale*m.w2;for(let k=0;k<4;k++){target.bins[k]+=scale*m.bins[k];target.xx[k]+=scale*scale*m.xx[k];target.xw[k]+=scale*scale*m.xw[k];}}
export function ratioStandardErrors(strata,probability,totalWeight){
  if(!probability||!(totalWeight>0)||strata.some(s=>s.m.n<2))return null;
  return probability.map((p,k)=>{let v=0;for(const {m,scale} of strata){const sum=m.bins[k]-p*m.w;const sum2=m.xx[k]-2*p*m.xw[k]+p*p*m.w2;v+=scale*scale*m.n/(m.n-1)*Math.max(0,sum2-sum*sum/m.n);}return Math.sqrt(v)/totalWeight;});
}
export function validateFluxOptions(o={}){
  const r={window:.2,region:'all',grid:'5x3',proposals:512,...o};
  if(![.2,.5,1].includes(r.window)||!['all','left','right','interior','wall'].includes(r.region)||!['5x3','3x2'].includes(r.grid)||![128,512,2048].includes(r.proposals))throw Error('INVALID_D1_OPTIONS');return r;
}
/** All proposals include rejects as zero weights, preserving the proposal measure. */
export function proposeContactReference(state,options,rng,observe=null){
  const o=validateFluxOptions(options),[nx,ny]=o.grid.split('x').map(Number),ps=state.particles,r=ps[0]?.radius,box=state.box;
  if(!ps.length||!Number.isFinite(r)||r<=0||box.x<=2*r||box.y<=2*r)throw Error('INVALID_REFERENCE_STATE');
  const area=(box.x-2*r)*(box.y-2*r)/(nx*ny),cells=Array.from({length:nx*ny},()=>[]);
  const index=p=>Math.min(nx-1,Math.max(0,Math.floor((p.x-r)/(box.x-2*r)*nx)))+nx*Math.min(ny-1,Math.max(0,Math.floor((p.y-r)/(box.y-2*r)*ny)));
  for(const p of ps){if(![p.x,p.y,p.vx,p.vy].every(Number.isFinite))throw Error('INVALID_REFERENCE_STATE');cells[index(p)].push(p);}
  const global=moments(),geometry=moments(),incoming=moments(),flux=moments(),stats={proposed:o.proposals,region:0,wallRejected:0,emptyPool:0,geometry:0,incoming:0,smallPool:0,smallPoolFlux:0,normalBins:Array(8).fill(0),cellCounts:cells.map(c=>c.length)};
  const pick=a=>a[Math.floor(rng.next()*a.length)];
  for(let j=0;j<o.proposals;j++){
    addWeighted(global,symmetricBins(pick(ps),pick(ps)),1);
    const z={x:r+(box.x-2*r)*rng.next(),y:r+(box.y-2*r)*rng.next()},theta=2*Math.PI*rng.next(),n={x:Math.cos(theta),y:Math.sin(theta)};
    let weight=0,w=0,c=zero();
    const row=observe?{proposal:j,midpoint_x:z.x,midpoint_y:z.y,nx:n.x,ny:n.y,theta,region_match:inRegion(z,box,r,o.region),geometry_valid:null,pool1:null,pool2:null,pool1_n:0,pool2_n:0,cell_area:area,rejection:"outside_region"}:null;
    if(inRegion(z,box,r,o.region)){
      stats.region++;const g=contactGeometry(z,n,box,r);
      if(row)Object.assign(row,{geometry_valid:g.valid,x1:g.a.x,y1:g.a.y,x2:g.b.x,y2:g.b.y,rejection:g.valid?"empty_pool":"wall_geometry"});
      if(!g.valid)stats.wallRejected++;
      else {const a=cells[index(g.a)],b=cells[index(g.b)];if(row)Object.assign(row,{pool1:index(g.a),pool2:index(g.b),pool1_n:a.length,pool2_n:b.length});if(!a.length||!b.length)stats.emptyPool++;
        else {const v1=pick(a),v2=pick(b);weight=a.length*b.length/(area*area);w=incomingFlux(v1,v2,n);c=symmetricBins(v1,v2);if(row)Object.assign(row,{v1x:v1.vx,v1y:v1.vy,v2x:v2.vx,v2y:v2.vy,normal_relative_velocity:(v1.vx-v2.vx)*n.x+(v1.vy-v2.vy)*n.y,rejection:w>0?"accepted":"not_incoming"});stats.geometry++;if(w>0)stats.incoming++;
          if(Math.min(a.length,b.length)<10){stats.smallPool++;stats.smallPoolFlux+=weight*w;}
          const normalBin=Math.floor(theta/(2*Math.PI)*8);stats.normalBins[normalBin]+=.5*weight*w;stats.normalBins[(normalBin+4)%8]+=.5*weight*w;}}
    }
    if(observe)observe({...row,incoming:w>0,flux_weight:w,density_weight:weight,proposal_weight:weight*w});
    addWeighted(geometry,c,weight);addWeighted(incoming,c,w>0?weight:0);addWeighted(flux,c,weight*w);
  }
  return {global,geometry,incoming,flux,stats,box:clone(box),radius:r};
}
function newWindow(start,end){return {start,end,through:start,global:moments(),geometry:moments(),incoming:moments(),flux:moments(),strata:[],actual:zero(),actualCount:0,normalActual:Array(8).fill(0),normalReference:Array(8).fill(0),intervals:0,maxInterval:0,smallFlux:0,counts:{proposed:0,region:0,wallRejected:0,emptyPool:0,geometry:0,incoming:0,smallPool:0}};}
export class FluxReferenceLab {
  constructor(options={},metadata={}){
    this.options=validateFluxOptions(options);this.metadata={seed:941083,branch:'A',experiment:'D1',...metadata};this.rng=new SeededRandom(this.metadata.seed);this.origin=null;this.lastTime=null;this.pending=[];this.proposal=null;this.active=null;this.latest=null;this.history=[];this.error=null;this.index=0;
  }
  generate(state){
    this.observer?.begin(state,this.options,this.metadata);
    const p=proposeContactReference(state,this.options,this.rng,this.observer?.proposal);
    this.observer?.end();return p;
  }
  ingest(event){
    if(this.error)return;
    if(!event.contact||!event.before||!Number.isFinite(event.time)){this.error='D1_MISSING_CONTACT: 旧记录缺少接触位置，不补造几何';return;}
    if(this.pending.length>=20000){this.error='D1_CAPACITY: 当前段记录已满，D1 已停止，物理继续';return;}
    this.pending.push({time:event.time,contact:clone(event.contact),before:clone(event.before),normal:clone(event.normal)});
  }
  sample(state){
    if(this.error||state.time===this.lastTime)return;
    if(this.lastTime!==null&&state.time<this.lastTime){this.error='D1_TIME_ORDER';return;}
    try{
      if(this.origin===null){this.origin=this.lastTime=state.time;this.active=newWindow(state.time,state.time+this.options.window);this.proposal=this.generate(state);this.latest=this.result();return;}
      let left=this.lastTime;const fullDt=state.time-left;
      if(fullDt>.100000000001){this.error='D1_SAMPLE_GAP: 采样间隔超过 0.1，重启 D1 后使用连续播放';return;}
      while(left<state.time){
        const a=this.active,right=Math.min(state.time,a.end),dt=right-left,p=this.proposal,scale=dt/this.options.proposals;
        if(!(dt>0)||a.strata.length>=1000)throw Error('D1_INTERVAL_CAPACITY');
        this.observer?.use({index:this.index+1,start:a.start,end:a.end,left,right,scale,sourceTime:this.lastTime});
        for(const k of ['global','geometry','incoming','flux'])scaledAdd(a[k],p[k],scale);
        a.strata.push({m:clone(p.flux),scale});a.intervals++;a.maxInterval=Math.max(a.maxInterval,fullDt);a.smallFlux+=scale*p.stats.smallPoolFlux;
        for(const k of Object.keys(a.counts))a.counts[k]+=p.stats[k];for(let k=0;k<8;k++)a.normalReference[k]+=scale*p.stats.normalBins[k];
        for(const e of this.pending){if(e.time<=left||e.time>right)continue;const z={x:(e.contact[0].x+e.contact[1].x)/2,y:(e.contact[0].y+e.contact[1].y)/2};if(!inRegion(z,p.box,p.radius,this.options.region))continue;
          const c=symmetricBins(e.before[0],e.before[1]);for(let k=0;k<4;k++)a.actual[k]+=c[k];a.actualCount++;
          const angle=(Math.atan2(e.normal.y,e.normal.x)+2*Math.PI)%(2*Math.PI),bin=Math.min(7,Math.floor(angle/(2*Math.PI)*8));a.normalActual[bin]+=.5;a.normalActual[(bin+4)%8]+=.5;
        }
        a.through=right;this.latest=this.result();left=right;
        if(right===a.end){this.onComplete?.(clone(this.latest));this.history.push(clone(this.latest));if(this.history.length>32)this.history.shift();this.index++;this.active=newWindow(a.end,this.origin+(this.index+1)*this.options.window);}
      }
      this.pending=this.pending.filter(e=>e.time>state.time);this.lastTime=state.time;this.proposal=this.generate(state);
    }catch(e){this.error=e.message;}
  }
  result(){
    const a=this.active,flux=summarizeMoments(a.flux),actual=a.actualCount?a.actual.map(x=>x/a.actualCount):null;
    const mcSE=ratioStandardErrors(a.strata,flux.probability,a.flux.w),diff=actual&&flux.probability?actual.map((x,k)=>x-flux.probability[k]):null;
    const smallFraction=a.flux.w?a.smallFlux/a.flux.w:null;
    return {options:clone(this.options),metadata:clone(this.metadata),start:a.start,end:a.end,through:a.through,complete:a.through===a.end,
      distributions:{global:summarizeMoments(a.global),geometry:summarizeMoments(a.geometry),incoming:summarizeMoments(a.incoming),flux,actual:{n:a.actualCount,counts:clone(a.actual),probability:actual}},
      difference:diff,totalVariation:diff?diff.reduce((s,x)=>s+Math.abs(x),0)/2:null,mcSE,
      actualIidScale:actual?actual.map(p=>Math.sqrt(p*(1-p)/a.actualCount)):null,
      status:!actual||!flux.probability||a.actualCount<40||flux.ess<100||flux.probability.some(p=>p*a.actualCount<10)||smallFraction>.2?'不足以判断':'探索性比较；不足以判断分子混沌',
      smallPoolFluxFraction:smallFraction,counts:clone(a.counts),intervals:a.intervals,maxInterval:a.maxInterval,
      normalActual:clone(a.normalActual),normalReference:clone(a.normalReference)};
  }
  view(){return {latest:clone(this.latest),error:this.error,pending:this.pending.length,completedWindows:this.history.length};}
  snapshot(){return clone({schema:'flux-reference/v1',options:this.options,metadata:this.metadata,rng:this.rng.state,origin:this.origin,lastTime:this.lastTime,pending:this.pending,proposal:this.proposal,active:this.active,latest:this.latest,history:this.history,error:this.error,index:this.index});}
  static restore(s){
    if(s?.schema!=='flux-reference/v1'||!Array.isArray(s.pending)||s.pending.length>20000||!Array.isArray(s.history)||s.history.length>32||!Number.isSafeInteger(s.index)||s.index<0||s.active?.strata?.length>1000)throw Error('INVALID_D1_SNAPSHOT');
    const lab=new FluxReferenceLab(s.options,s.metadata);lab.rng=new SeededRandom(s.rng);for(const k of ['origin','lastTime','pending','proposal','active','latest','history','error','index'])lab[k]=clone(s[k]);return lab;
  }
}
