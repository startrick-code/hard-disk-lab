import { IndexedMinHeap } from './heap.js';
import { DEFAULT_TOLERANCES, PhysicsError, finite, positionAt, energy, pairDelay, wallDelay, elasticPair } from './physics.js';
import { ENGINE_VERSION } from './model.js';

const clone = value => JSON.parse(JSON.stringify(value));
const participants = e => e.kind === 'pair' ? [e.i, e.j] : [e.i];

export class HardDiskEngine {
  #particles;
  #data;
  constructor(config, { onDiagnostic } = {}) {
    this.onDiagnostic = onDiagnostic;
    this.box = Object.freeze({ ...config.box });
    this.tolerances = Object.freeze({ ...DEFAULT_TOLERANCES, ...config.tolerances });
    this.time = config.time ?? 0;
    this.#data = new Float64Array(config.particles.length * 5);
    this.#particles = config.particles.map((p, i) => {
      const view = { radius: p.radius, mass: p.mass, version: p.version ?? 0 };
      ['x', 'y', 'vx', 'vy', 'at'].forEach((field, k) => {
        this.#data[i * 5 + k] = field === 'at' ? p.at ?? this.time : p[field];
        Object.defineProperty(view, field, { enumerable: true, get: () => this.#data[i * 5 + k], set: value => { this.#data[i * 5 + k] = value; } });
      });
      return view;
    });
    this.seed = config.seed ?? null; this.rngState = config.rngState ?? null;
    this.statisticalRngState = config.statisticalRngState ?? null; this.metadata = clone(config.metadata ?? {});
    this.timeOrigin = config.timeOrigin ?? 0;
    this.wallImpulse = { x: 0, y: 0 }; this.wallImpulseCorrection = { x: 0, y: 0 };
    this.interventionImpulse = { x: 0, y: 0 }; this.interventionImpulseCorrection = { x: 0, y: 0 };
    this.collisions = 0; this.pairCollisions = 0; this.wallCollisions = 0;
    this.maxRelativeEnergyError = 0;
    this.diagnostics = { counts: {}, examples: [] };
    this.halted = null; this.heap = new IndexedMinHeap();
    this.geometryTolerance = this.tolerances.position * this.box.x;
    this.penetrationTolerance = this.tolerances.significantPenetration * this.box.x;
    this.validate(); this.initialEnergy = energy(this.#particles); this.initialMomentum = this.momentum(); this.rebuildQueue();
  }
  note(code, details = {}) {
    this.diagnostics.counts[code] = (this.diagnostics.counts[code] ?? 0) + 1;
    const record = { code, time: this.time, collision: this.collisions, ...details };
    if (this.diagnostics.examples.length < 64) this.diagnostics.examples.push(record);
    this.onDiagnostic?.(record);
  }
  fail(error) {
    const e = error instanceof PhysicsError ? error : new PhysicsError('INTERNAL_ERROR', { message: error.message });
    this.note(e.code, e.details); this.halted = { code: e.code, details: e.details, time: this.time };
    throw e;
  }
  validate() {
    finite(this.box.x, this.box.y, this.time, this.geometryTolerance);
    if (this.box.x <= 0 || this.box.y <= 0 || this.time < 0 || !this.#particles.length) throw new PhysicsError('INVALID_STATE');
    for (const value of Object.values(this.tolerances)) {
      if (!Number.isFinite(value) || value <= 0) throw new PhysicsError('INVALID_TOLERANCE');
    }
    for (const [i, p] of this.#particles.entries()) {
      finite(p.x, p.y, p.vx, p.vy, p.radius, p.mass, p.at, p.version);
      if (p.radius <= 0 || p.mass <= 0 || 2 * p.radius >= Math.min(this.box.x, this.box.y) || p.at > this.time || !Number.isSafeInteger(p.version) || p.version < 0) throw new PhysicsError('INVALID_PARTICLE', { i });
      if (p.radius !== this.#particles[0].radius || p.mass !== this.#particles[0].mass) throw new PhysicsError('UNEQUAL_MODEL_PARAMETERS', { i });
      const pos = positionAt(p, this.time);
      if (pos.x < p.radius - this.geometryTolerance || pos.x > this.box.x - p.radius + this.geometryTolerance || pos.y < p.radius - this.geometryTolerance || pos.y > this.box.y - p.radius + this.geometryTolerance) throw new PhysicsError('OUTSIDE_BOX', { i });
      for (let j = 0; j < i; j++) {
        const q = this.#particles[j], qpos = positionAt(q, this.time);
        const gap = Math.hypot(pos.x - qpos.x, pos.y - qpos.y) - p.radius - q.radius;
        if (gap < -this.geometryTolerance) throw new PhysicsError('OVERLAP', { i, j, gap });
      }
    }
  }
  timeTolerance(t) { return this.tolerances.timeUlps * Number.EPSILON * Math.max(1, Math.abs(t)); }
  schedule(event, delay, origin = this.time) {
    if (delay === null) { this.heap.delete(event.key); return; }
    const time = origin + delay;
    finite(time);
    if (delay > 0 && time === origin) throw new PhysicsError('TIME_RESOLUTION', { delay, time });
    if (time < this.time) throw new PhysicsError('PAST_EVENT', { key: event.key, time });
    let normalSpeed;
    if (event.kind === 'pair') {
      const p = this.#particles[event.i], q = this.#particles[event.j];
      const rp = positionAt(p, time), rq = positionAt(q, time), d = Math.hypot(rp.x - rq.x, rp.y - rq.y);
      normalSpeed = Math.abs(((p.vx - q.vx) * (rp.x - rq.x) + (p.vy - q.vy) * (rp.y - rq.y)) / d);
    } else {
      const p = this.#particles[event.i];
      normalSpeed = Math.min(...event.axes.map(axis => Math.abs(axis === 'x' ? p.vx : p.vy)));
    }
    finite(normalSpeed);
    if (normalSpeed === 0) throw new PhysicsError('NUMERICAL_GRAZING_AMBIGUITY', { key: event.key });
    const uncertainty = this.timeTolerance(time) + this.tolerances.timeUlps * Number.EPSILON * this.box.x / normalSpeed;
    finite(uncertainty);
    this.heap.set({ ...event, time, uncertainty, versions: participants(event).map(i => this.#particles[i].version) });
  }
  schedulePair(i, j) {
    const key = `p:${i}:${j}`;
    const origin = Math.max(this.#particles[i].at, this.#particles[j].at);
    const delay = pairDelay(this.#particles[i], this.#particles[j], origin, this.geometryTolerance,
      (code, details) => this.note(code, { i, j, ...details }), this.tolerances.discriminantUlps);
    this.schedule({ key, kind: 'pair', i, j }, delay, origin);
  }
  scheduleWalls(i) {
    const p = this.#particles[i], origin = p.at, candidates = [];
    for (const axis of ['x', 'y']) {
      const v = axis === 'x' ? p.vx : p.vy, side = v > 0 ? 1 : 0;
      const delay = wallDelay(p, axis, side, this.box, origin, this.geometryTolerance,
        (code, details) => this.note(code, { i, ...details }));
      if (delay !== null) candidates.push({ axis, side, delay });
    }
    candidates.sort((a, b) => a.delay - b.delay);
    if (!candidates.length) { this.heap.delete(`w:${i}`); return; }
    const first = candidates[0], corner = candidates.length === 2 && first.delay === candidates[1].delay;
    const selected = corner ? candidates : [first];
    const ambiguousCorner = !corner && candidates.length === 2 && candidates[1].delay - first.delay <= this.timeTolerance(origin + first.delay) + this.tolerances.timeUlps * Number.EPSILON * this.box.x / Math.min(Math.abs(p.vx), Math.abs(p.vy));
    this.schedule({ key: `w:${i}`, kind: 'wall', i, axes: selected.map(c => c.axis), sides: selected.map(c => c.side), ambiguousCorner }, first.delay, origin);
  }
  rebuildQueue() {
    this.heap.clear();
    try {
      this.validate();
      for (let i = 0; i < this.#particles.length; i++) {
        this.scheduleWalls(i);
        for (let j = i + 1; j < this.#particles.length; j++) this.schedulePair(i, j);
      }
    } catch (e) { this.fail(e); }
  }
  refresh(changed) {
    for (const i of changed) this.scheduleWalls(i);
    for (const i of changed) for (let j = 0; j < this.#particles.length; j++) {
      if (j === i || (changed.has(j) && j < i)) continue;
      this.schedulePair(Math.min(i, j), Math.max(i, j));
    }
  }
  checkVersion(e) {
    if (participants(e).some((i, k) => this.#particles[i].version !== e.versions[k])) {
      throw new PhysicsError('STALE_EVENT', { key: e.key });
    }
  }
  // Reject coupled contact graphs, including a resting third particle without a queued event.
  checkOtherContacts(e) {
    for (const i of participants(e)) {
      const p = this.#particles[i], pos = positionAt(p, e.time);
      for (let j = 0; j < this.#particles.length; j++) {
        if (j === i || (e.kind === 'pair' && (j === e.i || j === e.j))) continue;
        const q = this.#particles[j], qpos = positionAt(q, e.time);
        const gap = Math.hypot(pos.x - qpos.x, pos.y - qpos.y) - p.radius - q.radius;
        if (gap < -this.geometryTolerance) throw new PhysicsError('OVERLAP', { i, j, gap });
        if (gap <= this.geometryTolerance) throw new PhysicsError('MULTIPLE_CONTACT', { key: e.key, i, j });
      }
      for (const axis of ['x', 'y']) for (const side of [0, 1]) {
        if (e.kind === 'wall' && e.axes.some((a, k) => a === axis && e.sides[k] === side)) continue;
        const gap = side === 0 ? pos[axis] - p.radius : this.box[axis] - p.radius - pos[axis];
        if (gap <= this.geometryTolerance) throw new PhysicsError('MULTIPLE_CONTACT', { key: e.key, i, axis, side });
      }
    }
  }
  nextEvent() { return this.heap.peek() ? clone(this.heap.peek()) : null; }
  step() {
    if (this.halted) throw new PhysicsError('ENGINE_HALTED', this.halted);
    const e = this.heap.peek();
    if (!e) return null;
    try {
      this.checkVersion(e);
      if (e.ambiguousCorner) throw new PhysicsError('MULTIPLE_CONTACT', { key: e.key, reason: 'near-corner ordering ambiguous' });
      if (e.time < this.time) throw new PhysicsError('PAST_EVENT', { event: e });
      // Near-simultaneous events are conservatively rejected if they share a participant.
      const frontier = [0];
      while (frontier.length) {
        const index = frontier.pop(), other = this.heap.items[index];
        if (!other || other.time - e.time > e.uncertainty) continue;
        frontier.push(index * 2 + 1, index * 2 + 2);
        if (other.key === e.key) continue;
        if (participants(e).some(i => participants(other).includes(i))) throw new PhysicsError('MULTIPLE_CONTACT', { keys: [e.key, other.key], times: [e.time, other.time] });
      }
      this.checkOtherContacts(e);
      const p = this.#particles[e.i], oldEnergy = energy(participants(e).map(i => this.#particles[i]));
      let changes, normal = null;
      if (e.kind === 'pair') {
        const q = this.#particles[e.j], result = elasticPair(p, q, e.time, this.geometryTolerance);
        normal = result.normal;
        changes = [[e.i, result.p], [e.j, result.q]];
        const oldMx = p.mass * p.vx + q.mass * q.vx, oldMy = p.mass * p.vy + q.mass * q.vy;
        const newMx = p.mass * result.p.vx + q.mass * result.q.vx, newMy = p.mass * result.p.vy + q.mass * result.q.vy;
        const momentumScale = Math.max(p.mass * Math.hypot(p.vx, p.vy) + q.mass * Math.hypot(q.vx, q.vy), Number.MIN_VALUE);
        finite(oldMx, oldMy, newMx, newMy, momentumScale);
        if (Math.hypot(newMx - oldMx, newMy - oldMy) > this.tolerances.conservationUlps * Number.EPSILON * momentumScale) throw new PhysicsError('MOMENTUM_RESIDUAL');
      } else {
        const pos = positionAt(p, e.time);
        e.axes.forEach((axis, k) => {
          const boundary = e.sides[k] === 0 ? p.radius : this.box[axis] - p.radius;
          if (Math.abs(pos[axis] - boundary) > this.geometryTolerance) throw new PhysicsError('CONTACT_RESIDUAL', { axis, position: pos[axis], boundary });
        });
        changes = [[e.i, { vx: e.axes.includes('x') ? -p.vx : p.vx, vy: e.axes.includes('y') ? -p.vy : p.vy }]];
      }
      const newEnergy = energy(changes.map(([i, v]) => ({ ...this.#particles[i], ...v })));
      if (Math.abs(newEnergy - oldEnergy) > this.tolerances.conservationUlps * Number.EPSILON * Math.max(oldEnergy, Number.MIN_VALUE)) throw new PhysicsError('ENERGY_RESIDUAL', { oldEnergy, newEnergy });
      // Commit only after geometry, contact topology and conservation checks pass.
      const positions = changes.map(([i]) => positionAt(this.#particles[i], e.time));
      if (changes.some(([i]) => !Number.isSafeInteger(this.#particles[i].version + 1))) throw new PhysicsError('VERSION_OVERFLOW');
      this.heap.pop(); this.time = e.time;
      if (e.kind === 'wall') {
        const v = changes[0][1];
        this.addImpulse('wall', { x: p.mass * (v.vx - p.vx), y: p.mass * (v.vy - p.vy) });
      }
      changes.forEach(([i, v], k) => Object.assign(this.#particles[i], positions[k], v, { at: this.time, version: this.#particles[i].version + 1 }));
      this.collisions++; if (e.kind === 'pair') this.pairCollisions++; else this.wallCollisions++;
      this.maxRelativeEnergyError = Math.max(this.maxRelativeEnergyError, this.relativeEnergyError());
      this.refresh(new Set(changes.map(([i]) => i)));
      return { ...e, normal, collision: this.collisions };
    } catch (error) { this.fail(error); }
  }
  advanceTo(target, maxEvents = 1000000) {
    if (this.halted) throw new PhysicsError('ENGINE_HALTED', this.halted);
    finite(target);
    if (target < this.time) throw new PhysicsError('NEGATIVE_TIME');
    let processed = 0;
    while (this.heap.peek() && this.heap.peek().time <= target) {
      if (processed >= maxEvents) return { reached: false, processed, time: this.time };
      this.step(); processed++;
    }
    this.time = target;
    return { reached: true, processed, time: this.time };
  }
  relativeEnergyError() {
    const delta = Math.abs(energy(this.#particles) - this.initialEnergy);
    return this.initialEnergy === 0 ? (delta === 0 ? 0 : Infinity) : delta / this.initialEnergy;
  }
  signedEnergyError() { return this.initialEnergy === 0 ? 0 : (energy(this.#particles) - this.initialEnergy) / this.initialEnergy; }
  momentum() {
    const result = { x: 0, y: 0 }, correction = { x: 0, y: 0 };
    for (const p of this.#particles) for (const axis of ['x', 'y']) {
      const value = p.mass * (axis === 'x' ? p.vx : p.vy) - correction[axis];
      const total = result[axis] + value;
      correction[axis] = (total - result[axis]) - value; result[axis] = total;
    }
    finite(result.x, result.y); return result;
  }
  addImpulse(kind, delta) {
    const sum = kind === 'wall' ? this.wallImpulse : this.interventionImpulse;
    const correction = kind === 'wall' ? this.wallImpulseCorrection : this.interventionImpulseCorrection;
    for (const axis of ['x', 'y']) {
      const value = delta[axis] - correction[axis], total = sum[axis] + value;
      finite(value, total);
      correction[axis] = (total - sum[axis]) - value; sum[axis] = total;
    }
  }
  momentumBalance() {
    const p = this.momentum();
    const x = p.x - this.initialMomentum.x - this.wallImpulse.x - this.interventionImpulse.x;
    const y = p.y - this.initialMomentum.y - this.wallImpulse.y - this.interventionImpulse.y;
    return { x, y, norm: Math.hypot(x, y) };
  }
  /** Exhaustive validation at current time AND analytic closest approach before next event. */
  audit() {
    const states = this.#particles.map(p => ({ ...p, ...positionAt(p, this.time) }));
    const interval = this.heap.peek() ? Math.max(0, this.heap.peek().time - this.time) : 0;
    let minGap = Infinity, minFlightGap = Infinity, minWallGap = Infinity;
    for (let i = 0; i < states.length; i++) {
      const p = states[i];
      for (const axis of ['x', 'y']) {
        const v = axis === 'x' ? p.vx : p.vy;
        minWallGap = Math.min(minWallGap, p[axis] - p.radius, this.box[axis] - p.radius - p[axis], p[axis] + v * interval - p.radius, this.box[axis] - p.radius - p[axis] - v * interval);
      }
      for (let j = i + 1; j < states.length; j++) {
        const q = states[j], dx = p.x - q.x, dy = p.y - q.y, vx = p.vx - q.vx, vy = p.vy - q.vy;
        const vv = vx * vx + vy * vy, dot = dx * vx + dy * vy;
        finite(vv, dot);
        const closest = vv === 0 ? 0 : Math.max(0, Math.min(interval, -dot / vv));
        minGap = Math.min(minGap, Math.hypot(dx, dy) - p.radius - q.radius);
        minFlightGap = Math.min(minFlightGap, Math.hypot(dx + vx * closest, dy + vy * closest) - p.radius - q.radius);
      }
    }
    if (Math.min(minGap, minFlightGap, minWallGap) < -this.penetrationTolerance) this.fail(new PhysicsError('SIGNIFICANT_PENETRATION', { minGap, minFlightGap, minWallGap }));
    return { minGap: Number.isFinite(minGap) ? minGap : null, minFlightGap: Number.isFinite(minFlightGap) ? minFlightGap : null, minWallGap, interval };
  }
  state() {
    return { time: this.time, box: { ...this.box }, particles: this.#particles.map(p => ({ ...p, ...positionAt(p, this.time), at: this.time })),
      collisions: this.collisions, pairCollisions: this.pairCollisions, wallCollisions: this.wallCollisions,
      energy: energy(this.#particles), signedEnergyError: this.signedEnergyError(), relativeEnergyError: this.relativeEnergyError(), maxRelativeEnergyError: this.maxRelativeEnergyError,
      wallImpulse: { ...this.wallImpulse }, interventionImpulse: { ...this.interventionImpulse }, momentumBalance: this.momentumBalance(), diagnostics: clone(this.diagnostics), halted: clone(this.halted), timeOrigin: this.timeOrigin };
  }
  snapshot() {
    return clone({ schema: 'hard-disk/v1', engineVersion: ENGINE_VERSION, box: this.box, particles: this.#particles, time: this.time, tolerances: this.tolerances,
      seed: this.seed, rngState: this.rngState, initialEnergy: this.initialEnergy, collisions: this.collisions,
      pairCollisions: this.pairCollisions, wallCollisions: this.wallCollisions, maxRelativeEnergyError: this.maxRelativeEnergyError,
      statisticalRngState: this.statisticalRngState, metadata: this.metadata, timeOrigin: this.timeOrigin,
      initialMomentum: this.initialMomentum, wallImpulse: this.wallImpulse, wallImpulseCorrection: this.wallImpulseCorrection,
      interventionImpulse: this.interventionImpulse, interventionImpulseCorrection: this.interventionImpulseCorrection,
      diagnostics: this.diagnostics, halted: this.halted });
  }
  static restore(snapshot, { onDiagnostic } = {}) {
    if (snapshot.schema !== 'hard-disk/v1' || snapshot.engineVersion !== ENGINE_VERSION) throw new PhysicsError('SNAPSHOT_SCHEMA');
    const s = clone(snapshot), engine = new HardDiskEngine(s);
    finite(s.initialEnergy, s.maxRelativeEnergyError, s.collisions, s.pairCollisions, s.wallCollisions);
    if (s.initialEnergy < 0 || s.maxRelativeEnergyError < 0 || ![s.collisions, s.pairCollisions, s.wallCollisions].every(n => Number.isSafeInteger(n) && n >= 0) || s.collisions !== s.pairCollisions + s.wallCollisions) throw new PhysicsError('SNAPSHOT_INVALID');
    engine.initialEnergy = s.initialEnergy; engine.collisions = s.collisions;
    engine.pairCollisions = s.pairCollisions; engine.wallCollisions = s.wallCollisions;
    engine.maxRelativeEnergyError = s.maxRelativeEnergyError; engine.diagnostics = s.diagnostics; engine.halted = s.halted;
    for (const field of ['initialMomentum', 'wallImpulse', 'wallImpulseCorrection', 'interventionImpulse', 'interventionImpulseCorrection']) {
      finite(s[field]?.x, s[field]?.y); engine[field] = s[field];
    }
    finite(s.timeOrigin);
    if (!s.diagnostics || !s.diagnostics.counts || !Array.isArray(s.diagnostics.examples)) throw new PhysicsError('SNAPSHOT_INVALID');
    engine.onDiagnostic = onDiagnostic;
    return engine;
  }
  reverseVelocities() {
    if (this.halted) throw new PhysicsError('ENGINE_HALTED', this.halted);
    const next = this.heap.peek();
    if ((next && next.time - this.time <= next.uncertainty) || (this.collisions > 0 && this.#particles.some(p => this.time - p.at <= this.timeTolerance(this.time)))) throw new PhysicsError('REVERSAL_AT_COLLISION', { time: this.time });
    if (this.#particles.some(p => !Number.isSafeInteger(p.version + 1))) throw new PhysicsError('VERSION_OVERFLOW');
    const positions = this.#particles.map(p => positionAt(p, this.time));
    const pBefore = this.momentum();
    this.addImpulse('intervention', { x: -2 * pBefore.x, y: -2 * pBefore.y });
    this.#particles.forEach((p, i) => Object.assign(p, positions[i], { vx: -p.vx, vy: -p.vy, at: this.time, version: p.version + 1 }));
    this.rebuildQueue();
  }
  rebaseTimeOrigin() {
    if (this.halted && this.halted.code !== 'TIME_RESOLUTION') throw new PhysicsError('ENGINE_HALTED', this.halted);
    const positions = this.#particles.map(p => positionAt(p, this.time)), previousTime = this.time;
    this.timeOrigin += previousTime; finite(this.timeOrigin);
    this.#particles.forEach((p, i) => Object.assign(p, positions[i], { at: 0 }));
    this.time = 0; this.halted = null; this.note('TIME_ORIGIN_REBASE', { previousTime, timeOrigin: this.timeOrigin });
    this.rebuildQueue();
  }
}
