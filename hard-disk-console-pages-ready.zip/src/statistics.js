/** Pure, read-only observables. No engine import, random draws or particle writes. */
export const STATISTICS_VERSION = '1.0.0';
export const GRID = Object.freeze({ columns: 5, rows: 3 });
export const SAMPLE_INTERVAL = 0.02;
export const HISTORY_CAPACITY = 4096;
export const SPEED_EDGES = Object.freeze(Array.from({ length: 9 }, (_, i) => i * 0.375));

export class StatisticsError extends Error {
  constructor(code, details = {}) { super(code); this.name = 'StatisticsError'; this.code = code; this.details = details; }
}
function requireFinite(...values) {
  if (!values.every(Number.isFinite)) throw new StatisticsError('STATISTICS_NONFINITE');
}
export function entropyFromCounts(counts) {
  if (!counts.length || counts.some(n => !Number.isSafeInteger(n) || n < 0)) throw new StatisticsError('STATISTICS_COUNTS');
  const total = counts.reduce((s, n) => s + n, 0);
  if (!Number.isSafeInteger(total) || total === 0) throw new StatisticsError('STATISTICS_EMPTY');
  let entropy = 0;
  for (const n of counts) if (n > 0) { const p = n / total; entropy -= p * Math.log(p); }
  return entropy; // no smoothing, clipping or monotonicity enforcement
}
export function spatialStatistics(state, positionTolerance = 1e-12 * state.box.x) {
  const { particles, box } = state, n = particles.length, radius = particles[0]?.radius;
  requireFinite(box.x, box.y, radius, positionTolerance);
  if (!n || radius <= 0 || positionTolerance < 0) throw new StatisticsError('STATISTICS_MODEL');
  const width = box.x - 2 * radius, height = box.y - 2 * radius;
  if (width <= 0 || height <= 0) throw new StatisticsError('STATISTICS_MODEL');
  const area = width * height / 15, counts = new Array(15).fill(0);
  let boundaryAssignments = 0;
  for (const [i, p] of particles.entries()) {
    requireFinite(p.x, p.y, p.radius);
    if (p.radius !== radius) throw new StatisticsError('STATISTICS_UNEQUAL_RADIUS');
    if (p.x < radius - positionTolerance || p.x > box.x - radius + positionTolerance || p.y < radius - positionTolerance || p.y > box.y - radius + positionTolerance) {
      throw new StatisticsError('STATISTICS_OUTSIDE_GRID', { i, x: p.x, y: p.y });
    }
    if (p.x < radius || p.x > box.x - radius || p.y < radius || p.y > box.y - radius) boundaryAssignments++;
    // Classify within-tolerance boundary residuals into the boundary cell ONLY.
    // Neither p.x nor p.y is modified. Larger residuals fail explicitly above.
    const column = Math.max(0, Math.min(4, Math.floor((p.x - radius) / width * 5)));
    const row = Math.max(0, Math.min(2, Math.floor((p.y - radius) / height * 3)));
    counts[row * 5 + column]++;
  }
  return { columns: 5, rows: 3, bounds: { x0: radius, x1: box.x - radius, y0: radius, y1: box.y - radius },
    cellArea: area, counts, densities: counts.map(count => count / area), probabilities: counts.map(count => count / n),
    total: n, entropy: entropyFromCounts(counts), entropyMaximum: Math.log(15), boundaryAssignments };
}
function validateEdges(edges) {
  if (!Array.isArray(edges) || edges.length !== 9 || edges[0] !== 0 || !edges.every(Number.isFinite) || edges.some((v, i) => i && v <= edges[i - 1])) throw new StatisticsError('STATISTICS_SPEED_EDGES');
}
/** 2D Maxwell speed law: beta=m/(2*kBT), kBT=E0/N.
 * Integral [lo,hi) = exp(-beta*lo²) * -expm1(-beta*(hi²-lo²)). */
export function maxwellBinProbabilities(initialEnergy, count, mass = 1, edges = SPEED_EDGES) {
  validateEdges(edges); requireFinite(initialEnergy, count, mass);
  if (initialEnergy < 0 || !Number.isSafeInteger(count) || count <= 0 || mass <= 0) throw new StatisticsError('STATISTICS_MAXWELL_PARAMETERS');
  if (initialEnergy === 0) return { defined: false, reason: 'ZERO_REFERENCE_TEMPERATURE', probabilities: null, referenceTemperature: 0 };
  const referenceTemperature = initialEnergy / count, beta = mass / (2 * referenceTemperature);
  requireFinite(referenceTemperature, beta);
  const probabilities = [];
  for (let i = 0; i < 8; i++) {
    const lo = edges[i], hi = edges[i + 1];
    probabilities.push(Math.exp(-beta * lo * lo) * -Math.expm1(-beta * (hi * hi - lo * lo)));
  }
  probabilities.push(Math.exp(-beta * edges[8] * edges[8])); // exact analytic tail [vmax,+inf)
  return { defined: true, probabilities, referenceTemperature, beta };
}
export function speedStatistics(particles, initialEnergy, edges = SPEED_EDGES) {
  validateEdges(edges);
  const n = particles.length, mass = particles[0]?.mass;
  if (!n) throw new StatisticsError('STATISTICS_EMPTY');
  const counts = new Array(9).fill(0), speeds = [];
  for (const p of particles) {
    requireFinite(p.vx, p.vy, p.mass);
    if (p.mass !== mass) throw new StatisticsError('STATISTICS_UNEQUAL_MASS');
    const speed = Math.hypot(p.vx, p.vy); requireFinite(speed); speeds.push(speed);
    let bin = 8;
    for (let i = 0; i < 8; i++) if (speed < edges[i + 1]) { bin = i; break; }
    counts[bin]++;
  }
  const reference = maxwellBinProbabilities(initialEnergy, n, mass, edges);
  return { edges: [...edges], speeds, counts, probabilities: counts.map(count => count / n), total: n,
    rmsSpeed: Math.sqrt(speeds.reduce((s, speed) => s + speed * speed, 0) / n),
    reference, expectedCounts: reference.defined ? reference.probabilities.map(p => p * n) : null };
}
export function sampleStatistics(state, initialEnergy, positionTolerance) {
  requireFinite(state.time);
  return { version: STATISTICS_VERSION, time: state.time, count: state.particles.length,
    spatial: spatialStatistics(state, positionTolerance), speed: speedStatistics(state.particles, initialEnergy) };
}
/** Fixed-capacity circular buffer, O(1) append. Contains raw samples in temporal order. */
export class SampleHistory {
  constructor(capacity = HISTORY_CAPACITY) {
    if (!Number.isSafeInteger(capacity) || capacity < 1 || capacity > HISTORY_CAPACITY) throw new StatisticsError('STATISTICS_HISTORY_CAPACITY');
    this.capacity = capacity; this.values = new Array(capacity); this.start = 0; this.length = 0; this.dropped = 0;
  }
  push(record) {
    if (this.length < this.capacity) this.values[(this.start + this.length++) % this.capacity] = { ...record };
    else { this.values[this.start] = { ...record }; this.start = (this.start + 1) % this.capacity; this.dropped++; }
  }
  clear() { this.values = new Array(this.capacity); this.start = 0; this.length = 0; this.dropped = 0; }
  toArray() { return Array.from({ length: this.length }, (_, i) => ({ ...this.values[(this.start + i) % this.capacity] })); }
}
