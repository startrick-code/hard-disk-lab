/** ZIP STORE with data descriptors and incremental CRC32. No dependency/network. */
const encoder=new TextEncoder(),table=Uint32Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
const bytes=(length,fn)=>{const a=new Uint8Array(length);fn(new DataView(a.buffer));return a;};
export class ZipStore {
  constructor(){this.parts=[];this.files=[];this.offset=0;this.current=null;}
  add(a){this.parts.push(a);this.offset+=a.byteLength;}
  start(name){if(this.current)throw Error('ZIP_FILE_NOT_CLOSED');const n=encoder.encode(name);if(n.length>65535)throw Error('ZIP_NAME_TOO_LONG');const f={name:n,offset:this.offset,size:0,crc:0xffffffff};this.current=f;
    this.add(bytes(30,v=>{v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x808,true);v.setUint16(12,33,true);v.setUint16(26,n.length,true);}));this.add(n);
  }
  write(value){if(!this.current)throw Error('ZIP_NO_FILE');const a=typeof value==='string'?encoder.encode(value):value,f=this.current;for(const b of a)f.crc=table[(f.crc^b)&255]^(f.crc>>>8);f.size+=a.length;if(f.size>0xffffffff)throw Error('ZIP_TOO_LARGE');this.add(a);}
  end(){const f=this.current;if(!f)throw Error('ZIP_NO_FILE');f.crc=(f.crc^0xffffffff)>>>0;this.add(bytes(16,v=>{v.setUint32(0,0x08074b50,true);v.setUint32(4,f.crc,true);v.setUint32(8,f.size,true);v.setUint32(12,f.size,true);}));this.files.push(f);this.current=null;}
  finish(){if(this.current)throw Error('ZIP_FILE_NOT_CLOSED');const start=this.offset;for(const f of this.files){this.add(bytes(46,v=>{v.setUint32(0,0x02014b50,true);v.setUint16(4,20,true);v.setUint16(6,20,true);v.setUint16(8,0x808,true);v.setUint16(14,33,true);v.setUint32(16,f.crc,true);v.setUint32(20,f.size,true);v.setUint32(24,f.size,true);v.setUint16(28,f.name.length,true);v.setUint32(42,f.offset,true);}));this.add(f.name);}const size=this.offset-start;this.add(bytes(22,v=>{v.setUint32(0,0x06054b50,true);v.setUint16(8,this.files.length,true);v.setUint16(10,this.files.length,true);v.setUint32(12,size,true);v.setUint32(16,start,true);}));return new Blob(this.parts,{type:'application/zip'});}
}
