const $=id=>document.getElementById(id),f=x=>x==null?'未定义':Number(x).toPrecision(4);
export class FluxCharts {
  constructor(send){this.send=send;for(const id of ['d1-enabled','d1-region','d1-window','d1-grid','d1-proposals'])$(id).onchange=()=>send({type:'flux-reference',enabled:$('d1-enabled').checked,options:{region:$('d1-region').value,window:Number($('d1-window').value),grid:$('d1-grid').value,proposals:Number($('d1-proposals').value)}});}
  update(data){
    if(!('correlations' in data))return;
    const d=data.correlations?.fluxReference;$('d1-enabled').checked=!!d;
    if(!d){$('d1-status').textContent='D1 未启用 · 启用会独立开始参考时段';$('d1-table').textContent='';$('d1-difference').textContent='';$('d1-chart').getContext('2d').clearRect(0,0,720,320);return;}
    $('correlations-enabled').checked=true;const s=d.latest;if(!s)return;
    for(const k of ['region','window','grid','proposals'])$(`d1-${k}`).value=String(s.options[k]);
    $('d1-status').textContent=d.error||`${s.status} · 分支 ${s.metadata.branch} / ${s.metadata.experiment} · (${s.start.toFixed(4)}, ${s.through.toFixed(4)}] T₀ ${s.complete?'完整短段':'段内累计'}`;
    const dist=s.distributions,keys=['global','geometry','incoming','flux','actual'],labels=['① 无条件全域经验乘积','② 局部接触几何＋密度乘积','③ 局部接触＋入射条件（不按速率加权）','④ 局部入射通量参考','⑤ 真实碰撞（标签对称）'];
    $('d1-table').innerHTML=keys.map((k,i)=>{const v=dist[k];return `<tr><td>${labels[i]}</td>${[0,1,2,3].map(j=>`<td>${f(v.probability?.[j])}</td>`).join('')}<td>${k==='actual'?v.n:v.proposals}</td><td>${k==='actual'?'非独立事件':f(v.ess)}</td></tr>`;}).join('');
    $('d1-difference').textContent=`实际 − 通量参考 [00,01,10,11]：${s.difference?.map(f).join(' / ')??'未定义'}；总变差距离 TV=${f(s.totalVariation)}。参考 MC 标准误：${s.mcSE?.map(f).join(' / ')??'未定义'}；实际独立计数尺度：${s.actualIidScale?.map(f).join(' / ')??'未定义'}（不是有效置信区间）。`;
    $('d1-conditions').textContent=`区域=${s.options.region}；局部格=${s.options.grid}；每固定时刻 ${s.options.proposals} 次提议；${s.intervals} 个时间积分片；最大采样间隔 ${f(s.maxInterval)} T₀。区域内提议 ${s.counts.region}，越墙接触拒绝 ${s.counts.wallRejected}，空速度池 ${s.counts.emptyPool}，有效几何 ${s.counts.geometry}，入射提议 ${s.counts.incoming}。来自任一速度池少于 10 粒子的通量权重比例 ${f(s.smallPoolFluxFraction)}。`;
    $('d1-normal').textContent=`8 个等角法线箱：实际（对称计数）${s.normalActual.map(f).join(' / ')}；参考（未归一化通量积分）${s.normalReference.map(f).join(' / ')}。角测度均匀提议经过几何与通量筛选后不要求均匀。`;
    const c=$('d1-chart'),ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);ctx.font='14px sans-serif';ctx.fillStyle='#344c55';ctx.fillText('每箱概率（标签对称二元方向）',16,20);const p=dist.actual.probability,q=dist.flux.probability;
    for(let k=0;k<4;k++){const x=100+k*160;ctx.fillStyle='#344c55';ctx.fillText(['00','01','10','11'][k],x,303);for(const [v,offset,color] of [[p?.[k],-30,'#177b83'],[q?.[k],15,'#b36a16']])if(v!=null){ctx.fillStyle=color;ctx.fillRect(x+offset,275-v*230,35,v*230);}if(q&&s.mcSE){const y=275-q[k]*230,e=s.mcSE[k]*230;ctx.strokeStyle='#6d3c05';ctx.beginPath();ctx.moveTo(x+32,y-e);ctx.lineTo(x+32,y+e);ctx.moveTo(x+25,y-e);ctx.lineTo(x+39,y-e);ctx.moveTo(x+25,y+e);ctx.lineTo(x+39,y+e);ctx.stroke();}}
  }
}
