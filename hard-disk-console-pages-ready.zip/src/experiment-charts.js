import { SampleHistory } from './statistics.js';

const $ = id => document.getElementById(id);
const number = v => v === null || v === undefined ? '—' : v.toExponential(3);
export class ExperimentCharts {
  constructor() { this.history = new SampleHistory(); this.view = null; this.dirty = true; }
  update(data) {
    if (!data.experiment) return;
    this.view = data.experiment; this.dirty = true;
    if (data.experimentHistory) { this.history.clear(); data.experimentHistory.forEach(p => this.history.push(p)); }
    if (data.experimentPoint) this.history.push(data.experimentPoint);
    const v = this.view, reverse = v.mode === 'reversal';
    $('common-time').textContent = v.time.toFixed(6);
    $('branch').value = data.selected;
    for (const option of $('branch').options) option.disabled = !v.states[option.value];
    const d = reverse ? v.comparison?.B : v.comparison?.AB;
    $('deviation-position').textContent = number(d?.normalizedPosition);
    $('deviation-velocity').textContent = number(d?.normalizedVelocity);
    $('deviation-phase').textContent = number(reverse ? v.comparison?.C?.normalizedPosition : d?.phase);
    $('deviation-phase-label').textContent = reverse ? 'C 返回位置 RMS / L₀' : '无量纲相空间偏离 D*';
    $('deviation-label').textContent = reverse ? 'B 返回参考误差（位置／反号速度）' : 'A/B 同编号粒子偏离';
    $('actual-fork').textContent = reverse ? `指定 T=${v.requestedForkTime.toFixed(9)}；实际 T=${v.actualForkTime.toFixed(9)} T₀；${v.phase === 'forward' ? '正常记录中' : data.complete ? '已完成至 2T' : '真实引擎反演中'}` :
      `仅移动 B 的一个粒子；实际位移 (${number(v.intervention?.actualDx)}, ${number(v.intervention?.actualDy)}) L₀`;
    let reliability = reverse ? '分叉前：正在记录正常演化的只读碰撞历史。' : '偏离曲线不等于熵曲线，不据此宣称严格李雅普诺夫指数。';
    if (reverse && v.phase === 'reversed') {
      reliability = v.reliability.trustworthy ? 'B 仍在已采样的 10⁻⁸ RMS 误差门槛内；这不是任意时间可逆精度的保证。' :
        `B 已受显著数值误差或退化事件影响（首次标记 t=${v.reliability.firstExceededTime.toFixed(6)} T₀）。此后 C 不能解释为纯受控扰动；反演失败不代表物理不可逆。`;
      if (v.comparison.referenceAmbiguous) reliability += ' 当前参考与碰撞不可区分，反号速度误差标为未定义。';
    }
    if (data.pendingTarget !== null && data.pendingTarget !== undefined) reliability += ` 正在同步至 ${data.pendingTarget.toFixed(6)}；画面保持上次共同时间。`;
    $('reliability').textContent = reliability; $('reliability').classList.toggle('error', !v.reliability.trustworthy);
    $('experiment-counts').replaceChildren();
    for (const [key, s] of Object.entries(v.states)) {
      const row = document.createElement('tr');
      const values = [key, s.time.toFixed(6), s.pairCollisions, s.wallCollisions, number(s.maxRelativeEnergyError), number(s.momentumBalance.norm), s.diagnostics.counts.NUMERICAL_OVERLAP ?? 0];
      values.forEach(value => { const td = document.createElement('td'); td.textContent = value; row.appendChild(td); }); $('experiment-counts').appendChild(row);
    }
    $('experiment-diagnostics').textContent = JSON.stringify({ branches: Object.fromEntries(Object.entries(v.states).map(([key, s]) => [key, { diagnostics: s.diagnostics.counts, halted: s.halted, audit: v.audits[key] }])),
      intervention: v.intervention, comparison: v.comparison, reliability: v.reliability }, null, 2);
  }
  paint() {
    if (!this.view || !this.dirty) return; this.dirty = false;
    const reverse = this.view.mode === 'reversal';
    this.draw('deviation-chart', reverse ? [['BPosition', '#126d77'], ['BVelocity', '#426aaf'], ['CPosition', '#bd6937'], ['CVelocity', '#ae3f67']] :
      [['dx', '#126d77'], ['dv', '#bd6937'], ['phase', '#426aaf']], $('log-scale').checked);
    this.draw('branch-entropy-chart', [['AEntropy', '#126d77'], ['BEntropy', '#426aaf'], ['CEntropy', '#bd6937'], ['referenceEntropy', '#7b7b7b', true]], false, Math.log(15));
  }
  draw(id, series, logarithmic, fixedMaximum = null) {
    const c = $(id), ctx = c.getContext('2d'), points = this.history.toArray(), left = 65, right = c.width - 20, top = 24, bottom = c.height - 46;
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.font = '13px -apple-system,sans-serif';
    const x0 = points[0]?.time ?? 0, x1 = Math.max(x0 + 0.02, points.at(-1)?.time ?? 0);
    const values = points.flatMap(p => series.map(([key]) => p[key])).filter(v => Number.isFinite(v) && (!logarithmic || v > 0));
    let lo = logarithmic ? Math.floor(Math.log10(Math.min(...values, 1e-10))) : 0;
    let hi = logarithmic ? Math.ceil(Math.log10(Math.max(...values, 1e-9))) : fixedMaximum ?? Math.max(...values, 1e-10) * 1.1;
    if (hi <= lo) hi = lo + 1;
    const y = v => bottom - (bottom - top) * ((logarithmic ? Math.log10(v) : v) - lo) / (hi - lo);
    for (let i = 0; i <= 3; i++) {
      const value = lo + (hi - lo) * i / 3, yy = bottom - (bottom - top) * i / 3;
      ctx.strokeStyle = '#dbe5e7'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(left, yy); ctx.lineTo(right, yy); ctx.stroke();
      ctx.fillStyle = '#53717b'; ctx.textAlign = 'right'; ctx.fillText(logarithmic ? `10^${value.toFixed(1)}` : value < 0.01 ? value.toExponential(1) : value.toFixed(2), left - 8, yy + 4);
    }
    for (const [key, color, dashed] of series) {
      ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.setLineDash(dashed ? [7, 5] : []); ctx.beginPath(); let connected = false;
      for (const p of points) {
        const value = p[key];
        if (!Number.isFinite(value) || (logarithmic && value <= 0)) { connected = false; continue; }
        const xx = left + (right - left) * (p.time - x0) / (x1 - x0), yy = y(value);
        if (connected) ctx.lineTo(xx, yy); else ctx.moveTo(xx, yy); connected = true;
      }
      ctx.stroke(); ctx.setLineDash([]);
    }
    ctx.fillStyle = '#53717b'; ctx.textAlign = 'left'; ctx.fillText(x0.toFixed(2), left, bottom + 25); ctx.textAlign = 'right'; ctx.fillText(`${x1.toFixed(2)} T₀`, right, bottom + 25);
  }
}
