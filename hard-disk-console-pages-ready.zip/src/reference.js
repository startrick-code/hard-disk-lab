// Deliberately independent full scan: no heap, no production predictor/impulse imports.
// This reference supports isolated nondegenerate contacts, not multi-contact resolution.
export class FullScanReference {
  constructor(config) {
    this.box = { ...config.box }; this.time = config.time ?? 0; this.collisions = 0;
    this.particles = config.particles.map(p => ({ ...p }));
  }
  candidates() {
    const result = [], p = this.particles;
    for (let i = 0; i < p.length; i++) {
      const a = p[i];
      for (const axis of ['x', 'y']) {
        const velocity = axis === 'x' ? a.vx : a.vy;
        if (velocity === 0) continue;
        const side = velocity < 0 ? 0 : 1;
        const boundary = side === 0 ? a.radius : this.box[axis] - a.radius;
        const delay = (boundary - a[axis]) / velocity;
        result.push({ kind: 'wall', key: `w:${i}:${axis}:${side}`, i, axis, side, delay: Math.max(0, delay) });
      }
      for (let j = i + 1; j < p.length; j++) {
        const b = p[j], rx = b.x - a.x, ry = b.y - a.y;
        const ux = b.vx - a.vx, uy = b.vy - a.vy;
        const aa = ux * ux + uy * uy, bb = rx * ux + ry * uy;
        if (aa === 0 || bb >= 0) continue;
        const radius = a.radius + b.radius;
        const cc = rx * rx + ry * ry - radius * radius;
        const discriminant = bb * bb - aa * cc;
        if (discriminant <= 0) continue;
        const delay = cc / (-bb + Math.sqrt(discriminant));
        result.push({ kind: 'pair', key: `p:${i}:${j}`, i, j, delay: Math.max(0, delay) });
      }
    }
    return result;
  }
  step() {
    const candidates = this.candidates();
    candidates.sort((a, b) => a.delay - b.delay || (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
    const e = candidates[0]; if (!e) return null;
    const tolerance = 64 * Number.EPSILON * Math.max(1, this.time + e.delay);
    for (const other of candidates.slice(1)) {
      if (other.delay - e.delay > tolerance) break;
      const ids = e.kind === 'pair' ? [e.i, e.j] : [e.i];
      if (ids.includes(other.i) || (other.kind === 'pair' && ids.includes(other.j))) throw new Error('REFERENCE_MULTIPLE_CONTACT');
    }
    for (const p of this.particles) { p.x += p.vx * e.delay; p.y += p.vy * e.delay; }
    this.time += e.delay;
    const a = this.particles[e.i];
    if (e.kind === 'wall') {
      if (e.axis === 'x') a.vx = -a.vx; else a.vy = -a.vy;
    } else {
      const b = this.particles[e.j];
      const dx = b.x - a.x, dy = b.y - a.y, length = Math.hypot(dx, dy);
      const nx = dx / length, ny = dy / length;
      const av = a.vx * nx + a.vy * ny, bv = b.vx * nx + b.vy * ny;
      const newAv = ((a.mass - b.mass) * av + 2 * b.mass * bv) / (a.mass + b.mass);
      const newBv = ((b.mass - a.mass) * bv + 2 * a.mass * av) / (a.mass + b.mass);
      a.vx += (newAv - av) * nx; a.vy += (newAv - av) * ny;
      b.vx += (newBv - bv) * nx; b.vy += (newBv - bv) * ny;
    }
    this.collisions++;
    return { ...e, time: this.time };
  }
}
