import { selectTVRecords, tvSegments, tvCSV } from './tv-history.js';
const $=id=>document.getElementById(id),fmt=x=>x==null?'样本不足':Number(x).toPrecision(5),esc=x=>String(x??'未知').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export class TVCharts {
  constructor(send){this.send=send;this.view=null;this.key=null;for(const id of ['tv-sort','tv-direction','tv-branch'])$(id).onchange=()=>this.render();
    $('tv-recording').onchange=()=>send({type:'tv-history-recording',enabled:$('tv-recording').checked});
    $('tv-clear').onclick=()=>send({type:'tv-history-clear'});
    $('tv-export').onclick=()=>{const csv=tvCSV(this.filtered()),url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download='d1-tv-history.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};}
  filtered(){return selectTVRecords(this.view?.records??[],{branch:$('tv-branch').value,sort:$('tv-sort').value,direction:$('tv-direction').value});}
  update(data){if(!('correlations' in data))return;this.view=data.correlations?.tvHistory??null;
    $('tv-recording').checked=this.view?.enabled??true;$('tv-recording').disabled=!data.correlations?.fluxReference;
    const current=this.view?.current;
    $('tv-current').textContent=current?`最近完整窗口 (${current.start.toFixed(4)}, ${current.end.toFixed(4)}] T₀ · 分支 ${current.branch} / ${current.epoch} / 段 ${current.group} · TV=${fmt(current.tv)}${current.insufficient?'（样本不足，描述值）':''} · 真实碰撞 ${current.collisions} · MC ESS=${fmt(current.ess)} · ${current.status}`:'样本不足 · 当前 D1 时段尚无完整统计窗口';
    const key=JSON.stringify([this.view?.revision,this.view?.active?.group,this.view?.active?.epoch]);
    if(data.type==='ready'||key!==this.key){this.key=key;this.render();}}
  render(){const rows=this.filtered();$('tv-history-status').textContent=`显示 ${rows.length} / ${this.view?.records.length??0} 条完整窗口；上限 200 条；因超上限已丢弃最早 ${this.view?.dropped??0} 条。${this.view?.enabled===false?'记录已关闭，新窗口仍正常计算。':''}`;
    $('tv-history-table').innerHTML=rows.map(r=>`<tr><td>${r.number}</td><td>(${r.start.toFixed(4)}, ${r.end.toFixed(4)}]</td><td>${esc(r.branch)}<br><small>${esc(r.epoch)} / 段 ${r.group}</small></td><td>${fmt(r.tv)}</td><td>${r.collisions}</td><td>${fmt(r.ess)}</td><td>${r.insufficient?'样本不足；':''}${esc(r.status)}</td><td><details><summary>详情</summary><div class="tv-record-details"><p>N=${r.particles}；初态种子=${esc(r.seed)}；预设=${esc(r.preset)}</p><p>区域=${esc(r.options.region)}；网格=${esc(r.options.grid)}；窗口=${r.options.window} T₀；每次提议=${r.options.proposals}</p><p>P00 / P01 / P10 / P11：<br>实际：${r.real?.map(fmt).join(' / ')??'样本不足'}<br>参考：${r.reference?.map(fmt).join(' / ')??'样本不足'}<br>Δ：${r.difference?.map(fmt).join(' / ')??'样本不足'}</p><p>各测度提议数（全域/几何/入射/通量）：${Object.values(r.proposals).join(' / ')}<br>提议=${r.counts.proposed}；区域内=${r.counts.region}；有效几何=${r.counts.geometry}；入射=${r.counts.incoming}；越墙拒绝=${r.counts.wallRejected}；空池=${r.counts.emptyPool}；小池=${r.counts.smallPool}</p></div></details></td></tr>`).join('');
    $('tv-export').disabled=!rows.length;this.plot(rows);}
  plot(rows){const c=$('tv-trend'),ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);ctx.font='14px sans-serif';ctx.fillStyle='#344c55';ctx.fillText('TV（0～1）· 每点对应完整窗口末时刻',12,20);
    ctx.strokeStyle='#becdd2';ctx.beginPath();ctx.moveTo(50,35);ctx.lineTo(50,275);ctx.lineTo(700,275);ctx.stroke();ctx.fillText('1',20,45);ctx.fillText('0',20,278);
    if(!rows.length)return;const lo=Math.min(...rows.map(r=>r.end)),hi=Math.max(...rows.map(r=>r.end)),x=t=>50+(hi===lo?325:650*(t-lo)/(hi-lo)),y=v=>275-230*v;
    for(const segment of tvSegments(rows)){ctx.strokeStyle='#177b83';ctx.beginPath();let pen=false;for(const r of segment){if(r.tv==null){pen=false;continue;}if(pen)ctx.lineTo(x(r.end),y(r.tv));else ctx.moveTo(x(r.end),y(r.tv));pen=true;}ctx.stroke();
      for(const r of segment){ctx.strokeStyle=r.insufficient?'#b36a16':'#177b83';ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();if(r.tv==null){ctx.moveTo(x(r.end),285);ctx.lineTo(x(r.end)-5,293);ctx.lineTo(x(r.end)+5,293);ctx.closePath();ctx.stroke();}else{ctx.arc(x(r.end),y(r.tv),r.insufficient?5:3,0,2*Math.PI);if(r.insufficient)ctx.stroke();else ctx.fill();}}}
    ctx.fillStyle='#344c55';ctx.fillText(`${lo.toFixed(3)} → ${hi.toFixed(3)} T₀`,50,310);}
}
