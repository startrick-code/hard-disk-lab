/** Worker-side orchestration. Uses existing engines/recorders unchanged. */
import {CorrelationController} from './correlations.js';
import {validateConfig,modeFromFlags,PROJECT_VERSION,stableJSON} from './experiment-config.js';
import {tvCSV} from './tv-history.js';
export function preparedObservers(engine,config,branch='A',experiment='single'){
  const c=new CorrelationController();if(Object.values(config.recorders).some(Boolean)){
    c.set(true);c.bind(engine,branch,experiment);
    // Arm D3 before D1 generates its first batch. No discarded/repeated MC draws.
    c.enableD3(config.recorders.d3);
    c.enableFlux(config.recorders.d1,config.d1);
    c.enableD2(config.recorders.d2);
    if(c.flux?.error)throw Error(c.flux.error);
  }return c;
}
export function actualConfig(engine,c,dynamics='single',options={},speed=.25){
  const flags={d1:!!c.flux,d2:c.d2.enabled,d3:c.d3.enabled};
  return {mode:modeFromFlags(flags),dynamics,count:engine.state().particles.length,seed:engine.seed,preset:engine.metadata?.preset??'unknown',d1:c.flux?structuredClone(c.flux.options):null,recorders:flags,speed,options:structuredClone(options),branch:c.lab?.options.branch??'A',epoch:c.lab?.options.experiment??null,group:c.tvHistory.active?.group??null,timeOrigin:engine.timeOrigin};
}
export function integrity(c,details=true){
  const d=c.d3,f=c.flux,through=f?.active?.through??null,start=f?.active?.start??null;
  const partial=f&&through>start,completed=f?.index??0,issues=[];
  if(f?.error)issues.push(f.error);if(c.d2.error)issues.push(c.d2.error);if(d.error)issues.push(d.error);
  if(c.d2.audits.some(a=>!a.fullCoverage))issues.push('D2窗口未完整覆盖');if(c.d2.audits.some(a=>a.fullCoverage&&a.d1!==a.d2))issues.push('D1/D2窗口真实碰撞计数不一致');if(f&&c.d2.enabled&&c.d2.audits.filter(a=>a.group===c.tvHistory.active?.group).length<completed)issues.push('D2缺少已完成窗口覆盖核对');
  if(d.truncated)issues.push('D3 dataset 截断');if(c.d2.truncated)issues.push('D2 dataset 截断');
  if(d.missing.length||d.missingLedgerDropped)issues.push('D3 missing_interval');
  if(d.windows.some(w=>w.status!=='complete_capture'))issues.push('D3 incomplete_capture');
  if(d.summaryDropped||c.tvHistory.dropped||c.d2.auditsDropped)issues.push('历史摘要有界缓冲已丢弃旧项');
  if(f&&(!c.tvHistory.enabled||c.tvHistory.records.length+c.tvHistory.dropped<completed))issues.push('D1 TV历史未完整保留（清空或关闭记录）');
  if((d.enabled||d.count||d.windows.length)&&d.windows.length+d.summaryDropped<completed)issues.push('D3缺少已完成窗口摘要');
  return {recorders:{d1:f?'enabled':'not_recorded',d2:c.d2.enabled?'recording':c.d2.events.length?'paused_recording':'not_recorded',d3:!d.enabled&&!d.count&&!d.windows.length?'not_recorded':d.truncated?'truncated':d.windows.some(w=>w.status!=='complete_capture')||d.missing.length?'incomplete_capture':d.enabled?'recording':'paused_recording'},status:issues.length?'incomplete_capture':partial?'in_progress':completed?'complete_capture':'not_yet_complete',issues,openWindow:partial,completedWindows:completed,d3Windows:details?structuredClone(d.windows):undefined,d3WindowCounts:{complete_capture:d.windows.filter(w=>w.status==='complete_capture').length,incomplete_capture:d.windows.filter(w=>w.status!=='complete_capture').length},missing_interval:details?structuredClone(d.missing):undefined,missingIntervalsCount:d.missing.length,dataset_truncated:d.truncated,d3SummaryDropped:d.summaryDropped,missingLedgerDropped:d.missingLedgerDropped,tvDropped:c.tvHistory.dropped};
}
export class ConsoleRun {
  constructor(){this.config=null;this.id=null;this.outcome=null;this.group=null;this.start=0;this.actions=[];this.actionsDropped=0;}
  begin(config,id,engine,c){this.config=validateConfig(config);this.id=id;this.outcome=null;this.group=c.tvHistory.active?.group??null;this.start=engine.time;this.actions=[];this.actionsDropped=0;}
  legacy(){this.config=null;this.id=null;this.outcome=null;this.actions=[];}
  note(action,time){if(!this.config)return;this.actions.push({action,time});if(this.actions.length>100){this.actions.shift();this.actionsDropped++;}}
  check(engine,c){
    if(!this.config||this.outcome)return false;
    const cfg=this.config,s=integrity(c,false);
    if(cfg.recorders.d3&&c.d3.enabled&&(c.d3.truncated||c.d3.error)){this.outcome={status:'incomplete',reason:'D3-A容量截断或记录错误；未成功完成',time:engine.time};return true;}
    const flags={d1:!!c.flux,d2:c.d2.enabled,d3:c.d3.enabled};
    if(cfg.stop.kind!=='manual'&&(stableJSON(flags)!==stableJSON(cfg.recorders)||cfg.recorders.d1&&(c.tvHistory.active?.group!==this.group||stableJSON(c.flux?.options)!==stableJSON(cfg.d1)))){this.outcome={status:'configuration_changed',reason:'手动更改了统计段或开关，自动结束条件已失效；请重新应用配置',time:engine.time};return true;}
    const reached=cfg.stop.kind==='time'?engine.time>=this.start+cfg.stop.time:cfg.stop.kind==='windows'?c.flux?.index>=cfg.stop.windows:false;
    if(!reached)return false;
    const ready=s.issues.length===0&&(!cfg.recorders.d3||!s.openWindow);
    this.outcome={status:ready?'completed':'incomplete',reason:ready?'已在既有采样边界完成目标并暂停':'达到目标，但存在缺失、截断或未闭合参考窗口；数据不完整',time:engine.time,requested:structuredClone(cfg.stop)};return true;
  }
  view(engine,c,dynamics,options,speed,running){
    const actual=actualConfig(engine,c,dynamics,options,speed);
    const health=integrity(c,false);health.lastStatTime=c.flux?.lastTime??null;health.unobservedTail=!!c.flux&&engine.time>c.flux.lastTime;if(health.unobservedTail){health.openWindow=true;if(health.status==='complete_capture'||health.status==='not_yet_complete')health.status='in_progress';}
    if(c.tvHistory.active&&c.flux&&(c.tvHistory.active.seed!==engine.seed||c.tvHistory.active.particles!==actual.count||stableJSON(c.tvHistory.active.options)!==stableJSON(actual.d1)))health.issues.push('当前配置与统计元信息不一致');
    if(this.config){for(const key of ['d1','d2','d3'])if(this.config.recorders[key]&&!actual.recorders[key])health.issues.push(key+'记录器已关闭，与已应用配置不一致');}
    if(health.issues.length)health.status='incomplete_capture';
    return {version:PROJECT_VERSION,id:this.id,applied:structuredClone(this.config),actual,running,start:this.start,time:engine.time,integrity:health,outcome:this.outcome,actions:structuredClone(this.actions),actionsDropped:this.actionsDropped};
  }
  snapshot(){return structuredClone({config:this.config,id:this.id,outcome:this.outcome,group:this.group,start:this.start,actions:this.actions,actionsDropped:this.actionsDropped});}
  restore(s){if(!s){this.legacy();return;}this.config=validateConfig(s.config);for(const k of ['id','outcome','group','start','actions','actionsDropped'])this[k]=structuredClone(s[k]);}
}
/** Paused export cut. All data keep original group/branch/epoch identifiers. */
export function exportManifest(view,c,selection){
  return {schema:'hard-disk-console-export/v1',projectVersion:PROJECT_VERSION,createdAt:new Date().toISOString(),runId:view.id,applied:view.applied,actual:view.actual,physicalTime:{start:view.start,end:view.time,unit:'T0',timeOrigin:view.actual.timeOrigin},recordCounts:{d1:c.tvHistory.records.length,d1Completed:c.flux?.index??0,d2:c.d2.events.length,d3:c.d3.count},integrity:{...view.integrity,d3Windows:structuredClone(c.d3.windows),missing_interval:structuredClone(c.d3.missing)},outcome:view.outcome,actions:view.actions,actionsDropped:view.actionsDropped,files:selection,contexts:{tvGroups:[...new Set(c.tvHistory.records.map(r=>r.group))],d2Segments:c.d2.segments.map(s=>structuredClone(s)),d3Segments:[...new Map(c.d3.usages.map(u=>[u.segment,{segment:u.segment,...u.batch.context}])).values()]},warnings:['TV不作独立性证明；MC ESS不是实际碰撞有效样本量','多分支/epoch/参数段保留原标识，不自动合并总体','导出时暂停；末窗口未闭合或摘要清空均如实标记']};
}
export function streamBundle(c,manifest,post=postMessage,done=()=>{}){
  function* content(){yield {type:'bundle-start',manifest};
    const files=[];if(manifest.files.tv)files.push(['d1-tv.csv',[tvCSV(c.tvHistory.records)]]);if(manifest.files.d2)files.push(['d2-real-collisions.csv',[c.d2.csv()]]);if(manifest.files.d3)files.push(['d3-reference.csv',c.d3.csvChunks()]);files.push(['experiment-config.json',[JSON.stringify(manifest,null,2)]]);
    for(const [name,chunks]of files){yield{type:'bundle-file',name};for(const text of chunks)for(let k=0;k<text.length;k+=32768)yield{type:'bundle-chunk',chunk:text.slice(k,k+32768)};yield{type:'bundle-file-end'};}
    yield{type:'bundle-end'};
  }
  const it=content();const pump=()=>{try{const r=it.next();if(r.done){done();return;}post(r.value);setTimeout(pump,0);}catch(e){post({type:'bundle-error',message:e.message});done();}};pump();
}
