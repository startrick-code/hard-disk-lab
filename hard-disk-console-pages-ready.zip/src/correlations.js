import { D3Recorder } from './d3-reference.js';
import { D2Recorder } from './d2-events.js';
import { TVHistory } from './tv-history.js';
import { FluxReferenceLab, validateFluxOptions } from './flux-reference.js';
/** Passive statistics. No dependency on collision mathematics or physical RNG. */
import { SeededRandom } from './random.js';
const copy = x => structuredClone(x);
export function binaryMetrics(table) {
  if (table.length !== 4 || table.some(x => !Number.isFinite(x) || x < 0)) throw Error('INVALID_TABLE');
  const n = table.reduce((a,b)=>a+b,0), rows=[table[0]+table[1],table[2]+table[3]], cols=[table[0]+table[2],table[1]+table[3]];
  if (!n) return { n, mi:null, conditional:null, insufficient:true, expected:[0,0,0,0] };
  let mi=0; table.forEach((v,k)=>{if(v) mi+=v/n*Math.log(v*n/(rows[k>>1]*cols[k%2]));});
  const expected=table.map((_,k)=>rows[k>>1]*cols[k%2]/n);
  return {n,mi,conditional:rows[1] ? table[3]/rows[1]-cols[1]/n : null,expected,insufficient:expected.some(v=>v<10)};
}
export function pearson(pairs) {
  if (!pairs.length) return null;
  const x=pairs.reduce((s,p)=>s+p[0],0)/pairs.length,y=pairs.reduce((s,p)=>s+p[1],0)/pairs.length;
  let xx=0,yy=0,xy=0; for(const [a,b] of pairs){xx+=(a-x)**2;yy+=(b-y)**2;xy+=(a-x)*(b-y);}
  return xx===0||yy===0 ? null : xy/Math.sqrt(xx*yy);
}
function shuffle(a,rng){for(let i=a.length-1;i>0;i--){const j=Math.floor(rng.next()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
export function randomMatching(n,rng){const ids=shuffle(Array.from({length:n},(_,i)=>i),rng),out=[];for(let i=0;i+1<n;i+=2)out.push([ids[i],ids[i+1]]);return out;}
const energy=p=>.5*p.mass*(p.vx*p.vx+p.vy*p.vy);
function analyze(samples,rng){
  const table=[0,0,0,0]; for(const s of samples)table[(s[0]>0?2:0)+(s[1]>0?1:0)]++;
  const metrics=binaryMetrics(table), refs=[];
  for(let k=0;k<32;k++){const b=shuffle(samples.map(s=>s[1]),rng),t=[0,0,0,0];samples.forEach((s,i)=>t[(s[0]>0?2:0)+(b[i]>0?1:0)]++);refs.push(binaryMetrics(t).mi);}
  const valid=refs.filter(x=>x!==null).sort((a,b)=>a-b);
  return {...metrics,table,rho:pearson(samples.map(s=>[s[2],s[3]])),permutation:valid.length?{mean:valid.reduce((a,b)=>a+b,0)/valid.length,low:valid[0],high:valid[valid.length-1],repeats:32}:null};
}
export class CorrelationLab {
  constructor({seed=12345,branch='A',experiment='single',window=1,bucket=.2,capacity=20000}={}){
    if(!Number.isFinite(window)||window<=0||!Number.isFinite(bucket)||bucket<=0||!Number.isInteger(capacity)||capacity<1||capacity>20000)throw Error('INVALID_STATISTICS_LIMIT');
    this.options={seed,branch,experiment,window,bucket,capacity};this.rng=new SeededRandom(seed);this.events=[];this.history=[];this.latest=null;this.error=null;this.origin=null;this.lastTime=null;
  }
  prune(time){this.events=this.events.filter(e=>e.time>time-Math.max(this.options.window,this.options.bucket));}
  ingest(event){if(this.error)return;this.prune(event.time);if(this.events.length>=this.options.capacity){this.error='STATISTICS_CAPACITY: 当前窗口记录已满，统计已停止；物理引擎继续。请重置统计。';return;}this.events.push(copy(event));}
  sample(state){
    if(this.error)return this.latest;
    if(this.lastTime===state.time)return this.latest;
    if(this.lastTime!==null&&state.time<this.lastTime)throw Error('STATISTICS_TIME_REVERSED');
    this.origin??=state.time;this.lastTime=state.time;this.prune(state.time);
    const ids=randomMatching(state.particles.length,this.rng), fixed=ids.map(([i,j])=>{const a=state.particles[i],b=state.particles[j];return[a.vx,b.vx,energy(a),energy(b)];});
    // Non-overlapping physical-time bins. No accumulation across nonstationary epochs.
    const start=this.origin+Math.floor((state.time-this.origin)/this.options.bucket)*this.options.bucket;
    const events=this.events.filter(e=>e.time>=start&&e.time<=state.time);
    const before=events.map(e=>[e.before[0].vx,e.before[1].vx,e.energyBefore[0],e.energyBefore[1]]),after=events.map(e=>[e.after[0].vx,e.after[1].vx,e.energyAfter[0],e.energyAfter[1]]);
    this.latest={time:state.time,branch:this.options.branch,experiment:this.options.experiment,start,end:state.time,fixed:analyze(fixed,this.rng),before:analyze(before,this.rng),after:analyze(after,this.rng),matching:ids};
    this.history.push({time:state.time,...Object.fromEntries(['fixed','before','after'].map(k=>[k,{mi:this.latest[k].mi,rho:this.latest[k].rho,permutation:this.latest[k].permutation?{mean:this.latest[k].permutation.mean}:null}]))});if(this.history.length>1024)this.history.shift();return this.latest;
  }
  network(time,n){const edges=new Map(),partners=Array.from({length:n},()=>new Set()),last=Array(n).fill(null);let count=0;
    for(const e of this.events){if(e.time<=time-this.options.window||e.time>time)continue;count++;const key=`${e.i}:${e.j}`,edge=edges.get(key)||{i:e.i,j:e.j,count:0,last:e.time};edge.count++;edge.last=e.time;edges.set(key,edge);partners[e.i].add(e.j);partners[e.j].add(e.i);last[e.i]=last[e.j]=e.time;}
    return {time,window:this.options.window,count,edges:[...edges.values()],partners:partners.map(s=>s.size),last,repeatRatio:count?(count-edges.size)/count:null};
  }
  view(state){return {latest:copy(this.latest),history:copy(this.history),network:this.network(state.time,state.particles.length),error:this.error,retained:this.events.length,capacity:this.options.capacity};}
  snapshot(){return copy({schema:'correlation/v1',options:this.options,rng:this.rng.state,events:this.events,history:this.history,latest:this.latest,error:this.error,origin:this.origin,lastTime:this.lastTime});}
  static restore(s){if(s.schema!=='correlation/v1'||!Array.isArray(s.events)||!Array.isArray(s.history)||s.events.length>s.options.capacity||s.history.length>1024)throw Error('INVALID_STATISTICS_SNAPSHOT');const lab=new CorrelationLab(s.options);lab.rng=new SeededRandom(s.rng);for(const k of ['events','history','latest','error','origin','lastTime'])lab[k]=copy(s[k]);return lab;}
}
/** Wrap only this instance: calls the original step exactly once. All data are copies. */
export function observeCollisions(engine,lab){
  const original=engine.step;
  function observed(){const next=engine.nextEvent(),pre=next?.kind==='pair'?engine.state().particles:null;const event=original.call(engine);
    if(event?.kind==='pair'){const post=engine.state().particles,ids=[event.i,event.j],before=ids.map(i=>({vx:pre[i].vx,vy:pre[i].vy})),after=ids.map(i=>({vx:post[i].vx,vy:post[i].vy}));
      const record={globalEvent:event.collision,pairEvent:engine.pairCollisions,time:event.time,i:event.i,j:event.j,normal:copy(event.normal),contact:ids.map(i=>({x:post[i].x,y:post[i].y})),before,after,incoming:-((before[0].vx-before[1].vx)*event.normal.x+(before[0].vy-before[1].vy)*event.normal.y),energyBefore:ids.map(i=>energy(pre[i])),energyAfter:ids.map(i=>energy(post[i])),branch:lab.options.branch,experiment:lab.options.experiment};lab.ingest(record);lab.onCollision?.(record);}
    return event;}
  engine.step=observed;return ()=>{if(engine.step===observed)engine.step=original;};
}
/** Selected branch only. Changing branch/engine starts an explicitly new statistical epoch. */
export class CorrelationController {
  constructor(){this.enabled=false;this.lab=null;this.engine=null;this.detach=null;this.epoch=0;this.window=1;this.fluxEnabled=false;this.fluxOptions={};this.flux=null;this.tvHistory=new TVHistory();this.d2=new D2Recorder();this.d3=new D3Recorder();}
  bind(engine,branch='A',experiment='single',saved=null){if(!this.enabled||!engine)return;if(this.engine===engine&&!saved)return;this.detach?.();this.engine=engine;this.lab=saved?CorrelationLab.restore(saved):new CorrelationLab({window:this.window,seed:((engine.seed??1)^0xa5a5a5a5)>>>0,branch,experiment:`${experiment}/epoch-${++this.epoch}`});this.detach=observeCollisions(engine,this.lab);if(!saved)this.lab.sample(engine.state());this.startFlux();this.configureD2();this.lab.onCollision=event=>{this.flux?.ingest(event);if(this.d2.enabled)this.d2.ingest(event);};}
  startFlux(saved=null){
    this.flux=null;if(!this.fluxEnabled||!this.engine||!this.lab)return;
    this.flux=saved?FluxReferenceLab.restore(saved):new FluxReferenceLab(this.fluxOptions,{seed:((this.engine.seed??1)^0x51f15e5d)>>>0,branch:this.lab.options.branch,experiment:this.lab.options.experiment});
    const state=this.engine.state(),store=this.tvHistory;
    const group=saved&&store.active?store.active.group:store.begin({branch:this.lab.options.branch,epoch:this.lab.options.experiment,options:this.flux.options,particles:state.particles.length,seed:this.engine.seed,preset:this.engine.metadata?.preset??'unknown'});
    this.flux.onComplete=result=>{store.append(result,group);if(this.d2.segments.length)this.d2.completeWindow(result,group);this.observeD3('complete',result);};
    this.attachD3(saved!==null);
    if(!saved)this.flux.sample(state);
  }
  observeD3(method,...args){try{return this.d3[method](...args);}catch(e){this.d3.error='D3_RECORDING_ERROR: '+e.message;this.d3.pending=null;}}
  attachD3(preserve=false){if(!this.flux)return;const state=this.engine.state();this.d3.configure({seed:this.engine.seed,branch:this.lab.options.branch,epoch:this.lab.options.experiment,experiment:this.lab.options.experiment,particles:state.particles.length,preset:this.engine.metadata?.preset??'unknown',time_origin:state.timeOrigin,origin:this.flux.origin??state.time,group:this.tvHistory.active?.group,region:this.flux.options.region,grid:this.flux.options.grid,window_duration:this.flux.options.window,proposals_per_batch:this.flux.options.proposals},preserve);
    this.flux.observer=this.d3.enabled?{begin:(...args)=>this.observeD3('begin',...args),proposal:row=>this.observeD3('proposal',row),end:()=>this.observeD3('end'),use:interval=>this.observeD3('use',interval)}:null;
  }
  enableD3(enabled){this.d3.setEnabled(enabled);this.attachD3();}
  enableFlux(enabled,options={}){const validated=validateFluxOptions(options);this.fluxEnabled=enabled===true;this.fluxOptions=validated;this.startFlux();this.configureD2();}
  configureD2(){if(!this.engine||!this.lab)return;const state=this.engine.state();this.d2.configure({seed:this.engine.seed,branch:this.lab.options.branch,epoch:this.lab.options.experiment,particles:state.particles.length,preset:this.engine.metadata?.preset??'unknown',box:state.box,radius:state.particles[0].radius,mass:state.particles[0].mass,timeOrigin:state.timeOrigin,d1:this.flux?{group:this.tvHistory.active?.group,origin:this.flux.origin,options:this.flux.options}:null},this.engine.time,this.engine.collisions);}
  enableD2(enabled){this.configureD2();this.d2.setEnabled(enabled,this.engine.time,this.engine.collisions);}
  clearD2(){this.d2.clear(this.engine.time,this.engine.collisions);}
  reset(){this.detach?.();this.engine=null;this.lab=null;this.flux=null;this.tvHistory=new TVHistory();this.d2=new D2Recorder();this.d3=new D3Recorder();}
  set(enabled,window=this.window){if(![.2,1,2].includes(window))throw Error('INVALID_WINDOW');this.window=window;this.enabled=enabled;if(!enabled)this.fluxEnabled=false;this.reset();}
  sample(state){if(this.enabled&&this.lab){this.lab.sample(state);this.d2.advance(state.time);this.flux?.sample(state);if(this.d2.enabled)this.d2.refresh(state.time);}}
  view(state){return this.enabled&&this.lab&&state?{...this.lab.view(state),tvHistory:this.tvHistory.view(),d2:this.d2.view(),d3:this.d3.view(),...(this.fluxEnabled?{fluxReference:this.flux?.view()}:{} )}:null;}
  snapshot(){return {enabled:this.enabled,epoch:this.epoch,window:this.window,lab:this.lab?.snapshot()??null,tvHistory:this.tvHistory.snapshot(),d2:this.d2.snapshot(),d3:this.d3.snapshot(),...(this.fluxEnabled?{fluxReference:this.flux?.snapshot(),fluxOptions:this.fluxOptions}:{})};}
  restore(saved,engine,branch,experiment){this.reset();this.fluxEnabled=false;this.enabled=saved?.enabled===true;this.epoch=saved?.epoch??0;this.window=saved?.window??1;this.bind(engine,branch,experiment,saved?.lab);if(saved?.tvHistory)this.tvHistory=TVHistory.restore(saved.tvHistory);if(saved?.fluxReference){this.fluxEnabled=true;this.fluxOptions=validateFluxOptions(saved.fluxOptions);this.startFlux(saved.fluxReference);if(!saved.tvHistory)for(const result of this.flux.history)this.tvHistory.append(result);}if(saved?.d2)this.d2=D2Recorder.restore(saved.d2);else this.configureD2();if(saved?.d3){this.d3=D3Recorder.restore(saved.d3);this.attachD3(true);}}
}
