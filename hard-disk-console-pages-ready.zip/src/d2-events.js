/** Passive real-event recorder. No RNG, collision solver or reference proposal imports. */
import { inRegion } from './flux-reference.js';
const clone=x=>structuredClone(x);
export const D2_CAPACITY=20000;
const categories=['00','mixed','11'];
export function d1WindowAt(time,origin,width){
  if(!Number.isFinite(time)||!Number.isFinite(origin)||!Number.isFinite(width)||width<=0||time<=origin)return null;
  let index=Math.max(0,Math.floor((time-origin)/width));if(!Number.isSafeInteger(index)||!(origin+(index+1)*width>origin+index*width))return null;
  while(index>0&&time<=origin+index*width)index--;
  while(time>origin+(index+1)*width)index++;
  return {index:index+1,start:origin+index*width,end:origin+(index+1)*width};
}
export function indicatorACF(labels,category,maxLag=20){
  const invalid=!Array.isArray(labels)||!categories.includes(category)||labels.some(x=>!categories.includes(x));
  const n=invalid?0:labels.length,p=n?labels.filter(x=>x===category).length/n:null;
  const denominator=n?labels.reduce((s,x)=>s+((x===category?1:0)-p)**2,0):0;
  return {category,n,mean:p,status:invalid?'无效样本':!denominator?'零方差或样本不足':n<40?'样本不足，描述性估计':'描述性估计，未校准不确定性',
    lags:Array.from({length:Math.min(20,Math.max(0,maxLag))},(_,i)=>{const lag=i+1,pairs=Math.max(0,n-lag);let value=null;
      if(!invalid&&denominator>0&&pairs>=2){let sum=0;for(let j=0;j<pairs;j++)sum+=((labels[j]===category?1:0)-p)*((labels[j+lag]===category?1:0)-p);value=sum/denominator;}
      return {lag,pairs,value};})};
}
function summary(values){if(!values.length)return {n:0,mean:null,min:null,max:null,std:null};let mean=0,m2=0,n=0,min=Infinity,max=-Infinity;
 for(const v of values){n++;const delta=v-mean;mean+=delta/n;m2+=delta*(v-mean);min=Math.min(min,v);max=Math.max(max,v);}return {n,mean,min,max,std:n>1?Math.sqrt(Math.max(0,m2/(n-1))):null};}
export function describeEvents(events){
  if(!Array.isArray(events))return {error:'无效样本',n:0};
  if(events.some((e,k)=>!e||!Number.isFinite(e.time)||!Number.isInteger(e.i)||!Number.isInteger(e.j)||e.i===e.j||!categories.includes(e.category3)||k>0&&e.time<events[k-1].time))return {error:'无效或时间无序样本',n:events.length};
  const segments=new Set(events.map(e=>e.segment));if(segments.size>1)return {error:'不同记录段不得合并自相关',n:events.length};
  let shared=0;const system=[],waits=[],last=new Map(),byParticle=new Map();
  events.forEach((e,k)=>{if(k){const p=events[k-1];if([p.i,p.j].some(id=>id===e.i||id===e.j))shared++;system.push(e.time-p.time);}
    for(const id of [e.i,e.j]){if(last.has(id)){const dt=e.time-last.get(id);waits.push(dt);if(!byParticle.has(id))byParticle.set(id,[]);byParticle.get(id).push(dt);}last.set(id,e.time);}});
  return {n:events.length,adjacentPairs:Math.max(0,events.length-1),sharedParticleRatio:events.length>1?shared/(events.length-1):null,
    systemIntervals:summary(system),particleIntervals:summary(waits),byParticle:[...byParticle].map(([id,v])=>({id,...summary(v)})),
    acf:categories.map(c=>indicatorACF(events.map(e=>e.category3),c)),effectiveSampleSize:'无法可靠估计'};
}
export class D2Recorder {
  constructor(capacity=D2_CAPACITY){if(!Number.isInteger(capacity)||capacity<1||capacity>D2_CAPACITY)throw Error('INVALID_D2_CAPACITY');
    this.capacity=capacity;this.enabled=false;this.events=[];this.segments=[];this.context=null;this.active=null;this.nextSequence=1;this.nextSegment=1;this.lastGlobal=null;this.truncated=false;this.error=null;this.audits=[];this.auditsDropped=0;this.revision=0;this.analysis=null;this.lastAnalysisTime=null;this.selection={segment:'latest',window:'all'};
  }
  configure(context,time,globalEvent){if(JSON.stringify(this.context)===JSON.stringify(context))return;this.close(time);this.context=clone(context);if(this.enabled&&!this.truncated)this.begin(time,globalEvent);}
  begin(time,globalEvent){if(!this.context)return;if(this.segments.length>=200){this.truncated=true;this.error='D2_SEGMENT_CAPACITY: 记录段达到200，记录已停止；请先导出并清空';this.revision++;return;}
    const s={id:this.nextSegment++,context:clone(this.context),start:time,through:time,end:null,count:0,windowCounts:{}};this.segments.push(s);this.active=s;this.lastGlobal=globalEvent;this.analysis=null;this.lastAnalysisTime=null;this.selection={segment:'latest',window:'all'};this.revision++;}
  close(time){if(this.active){this.active.through=Math.max(this.active.through,time);this.active.end=this.active.through;this.active=null;}this.revision++;}
  setEnabled(value,time,globalEvent){const enabled=value===true;if(enabled===this.enabled)return;this.close(time);this.enabled=enabled;if(enabled&&!this.truncated)this.begin(time,globalEvent);}
  ingest(event){if(!this.enabled||this.truncated||!this.active)return false;
    const s=this.active,c=s.context;
    if(!Number.isSafeInteger(event.globalEvent)||event.globalEvent<=this.lastGlobal)return false;
    if(!Number.isFinite(event.time)||event.time<s.through||![event.i,event.j].every(id=>Number.isInteger(id)&&id>=0&&id<c.particles)||event.i===event.j||event.before?.length!==2||!event.before.every(v=>Number.isFinite(v.vx)&&Number.isFinite(v.vy))||event.contact?.length!==2||!event.contact.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y))||!Number.isFinite(event.normal?.x)||!Number.isFinite(event.normal?.y)){
      this.error='D2_INVALID_EVENT: 原始事件无效，记录已停止';this.truncated=true;this.revision++;return false;}
    if(this.events.length>=this.capacity){this.truncated=true;this.error=`D2_TRUNCATED: 达到${this.capacity}条容量，已停止接收；保存部分不能视作完整样本`;s.end=event.time;this.revision++;return false;}
    const direction=event.before.map(v=>v.vx>0?'1':'0').join(''),category3=direction==='00'?'00':direction==='11'?'11':'mixed';
    const reference=c.d1,midpoint={x:(event.contact[0].x+event.contact[1].x)/2,y:(event.contact[0].y+event.contact[1].y)/2};
    const regionMatch=reference?inRegion(midpoint,c.box,c.radius,reference.options.region):null;
    const window=reference?d1WindowAt(event.time,reference.origin,reference.options.window):null;
    const r={sequence:this.nextSequence++,globalEvent:event.globalEvent,pairEvent:event.pairEvent,time:event.time,i:event.i,j:event.j,before:clone(event.before),contact:clone(event.contact),normal:clone(event.normal),direction,category3,regionMatch,window,segment:s.id};
    this.events.push(r);s.count++;s.through=event.time;if(window){s.windowCounts[window.index]??=0;if(regionMatch)s.windowCounts[window.index]++;}this.lastGlobal=event.globalEvent;this.revision++;return true;
  }
  advance(time){if(this.enabled&&!this.truncated&&this.active)this.active.through=Math.max(time,this.active.through);}
  completeWindow(result,referenceGroup){
    const matches=this.segments.filter(s=>s.context.d1?.group===referenceGroup&&s.context.branch===result.metadata.branch&&s.context.epoch===result.metadata.experiment);
    if(!matches.length)return;
    const w=d1WindowAt(result.end,matches[0].context.d1.origin,result.options.window);if(!w)return;
    const rows=matches.filter(s=>s.start<result.end&&(s.end??s.through)>result.start),count=rows.reduce((n,s)=>n+(s.windowCounts[w.index]??0),0);
    if(!rows.length)return;
    const full=rows.length===1&&rows[0].start<=result.start&&rows[0].through>=result.end&&!this.truncated;
    this.audits.push({group:referenceGroup,branch:result.metadata.branch,epoch:result.metadata.experiment,window:w.index,start:result.start,end:result.end,d1:result.distributions.actual.n,d2:count,fullCoverage:full,status:full?(count===result.distributions.actual.n?'计数一致':'计数不一致，需诊断'):'记录未覆盖完整窗口/中途关闭或截断，不可比较'});
    if(this.audits.length>200){this.audits.shift();this.auditsDropped++;}this.revision++;
  }
  clear(time,globalEvent){this.events=[];this.segments=[];this.active=null;this.truncated=false;this.error=null;this.audits=[];this.auditsDropped=0;this.analysis=null;this.lastAnalysisTime=null;this.selection={segment:'latest',window:'all'};if(this.enabled)this.begin(time,globalEvent);this.revision++;}
  refresh(time,force=false,selection=null){if(selection)this.selection={...this.selection,...selection};if(!force&&(!this.enabled||this.lastAnalysisTime!==null&&time-this.lastAnalysisTime<.2))return;
    const id=this.selection.segment==='latest'?this.segments.at(-1)?.id:Number(this.selection.segment),segment=this.segments.find(s=>s.id===id);
    let events=this.events.filter(e=>e.segment===id);const w=this.selection.window==='all'?null:Number(this.selection.window);
    if(w!==null)events=events.filter(e=>e.regionMatch&&e.window?.index===w);
    this.analysis={updatedAt:time,segment:id,window:w,scope:w===null?'本记录段全部真实粒子碰撞':'该D1窗口内且满足区域条件的真实碰撞（筛选后的相邻事件）',context:clone(segment?.context??null),...describeEvents(events)};this.lastAnalysisTime=time;
  }
  view(){return clone({enabled:this.enabled,count:this.events.length,capacity:this.capacity,truncated:this.truncated,error:this.error,revision:this.revision,segments:this.segments.map(s=>({id:s.id,start:s.start,end:s.end,through:s.through,count:s.count,branch:s.context.branch,epoch:s.context.epoch,region:s.context.d1?.options.region??null,windows:Object.keys(s.windowCounts).map(Number)})),analysis:this.analysis,audits:this.audits,auditsDropped:this.auditsDropped});}
  snapshot(){return clone({schema:'d2-events/v1',...Object.fromEntries(['capacity','enabled','events','segments','context','active','nextSequence','nextSegment','lastGlobal','truncated','error','audits','auditsDropped','revision','analysis','lastAnalysisTime','selection'].map(k=>[k,this[k]]))});}
  static restore(s){if(s?.schema!=='d2-events/v1'||!Array.isArray(s.events)||s.events.length>s.capacity||!Array.isArray(s.segments)||s.segments.length>200||!Array.isArray(s.audits)||s.audits.length>200)throw Error('INVALID_D2_SNAPSHOT');const d=new D2Recorder(s.capacity);for(const k of Object.keys(d))if(k in s)d[k]=clone(s[k]);d.active=s.active?d.segments.find(x=>x.id===s.active.id):null;return d;}
  csv(){const header=['sequence','global_event_including_walls','particle_pair_event','time','particle_i','particle_j','vix_before','viy_before','vjx_before','vjy_before','xi_contact','yi_contact','xj_contact','yj_contact','nx','ny','direction4','direction3','d1_region_match','d1_window','window_start','window_end','segment','seed','branch','epoch','particles','preset','d1_group','d1_origin','d1_region','d1_grid','d1_window_width','d1_proposals','recording_start','recording_end','covered_through','box_width','box_height','radius','mass','time_origin','dataset_truncated'];
    const quote=x=>`"${String(x??'').replaceAll('"','""')}"`,contexts=new Map(this.segments.map(s=>[s.id,s]));
    const rows=this.events.map(e=>{const s=contexts.get(e.segment),c=s.context,d=c.d1;return[e.sequence,e.globalEvent,e.pairEvent,e.time,e.i,e.j,e.before[0].vx,e.before[0].vy,e.before[1].vx,e.before[1].vy,e.contact[0].x,e.contact[0].y,e.contact[1].x,e.contact[1].y,e.normal.x,e.normal.y,e.direction,e.category3,e.regionMatch,e.window?.index,e.window?.start,e.window?.end,e.segment,c.seed,c.branch,c.epoch,c.particles,c.preset,d?.group,d?.origin,d?.options.region,d?.options.grid,d?.options.window,d?.options.proposals,s.start,s.end,s.through,c.box.x,c.box.y,c.radius,c.mass,c.timeOrigin,this.truncated];});
    return '\uFEFF'+[header,...rows].map(r=>r.map(quote).join(',')).join('\r\n')+'\r\n';}
}
