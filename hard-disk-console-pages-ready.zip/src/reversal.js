import { HardDiskEngine } from './engine.js';
/** Returns both position-return error and velocity error relative to NEGATED initial velocities. */
export function reversalTest(config, duration = 5, sampleCount = 100) {
  const engine = new HardDiskEngine(config), initial = engine.state();
  const reference = [initial];
  for (let i = 1; i <= sampleCount; i++) {
    engine.advanceTo(initial.time + duration * i / sampleCount); reference.push(engine.state());
  }
  const outwardCollisions = engine.collisions;
  const outwardPairCollisions = engine.pairCollisions;
  engine.reverseVelocities();
  let maxTrajectoryPositionError = 0, maxTrajectoryNegatedVelocityError = 0;
  for (let i = 1; i <= sampleCount; i++) {
    engine.advanceTo(initial.time + duration + duration * i / sampleCount);
    const state = engine.state(), ref = reference[sampleCount - i];
    state.particles.forEach((p, k) => {
      maxTrajectoryPositionError = Math.max(maxTrajectoryPositionError, Math.hypot(p.x - ref.particles[k].x, p.y - ref.particles[k].y));
      maxTrajectoryNegatedVelocityError = Math.max(maxTrajectoryNegatedVelocityError, Math.hypot(p.vx + ref.particles[k].vx, p.vy + ref.particles[k].vy));
    });
  }
  const returned = engine.state();
  const errors = returned.particles.map((p, i) => ({
    position: Math.hypot(p.x - initial.particles[i].x, p.y - initial.particles[i].y),
    negatedVelocity: Math.hypot(p.vx + initial.particles[i].vx, p.vy + initial.particles[i].vy)
  }));
  return { duration, outwardCollisions, returnCollisions: engine.collisions - outwardCollisions,
    outwardPairCollisions, returnPairCollisions: engine.pairCollisions - outwardPairCollisions,
    maxPositionError: Math.max(...errors.map(e => e.position)),
    maxNegatedVelocityError: Math.max(...errors.map(e => e.negatedVelocity)), errors,
    rmsPositionError: Math.sqrt(errors.reduce((s, e) => s + e.position ** 2, 0) / errors.length),
    rmsNegatedVelocityError: Math.sqrt(errors.reduce((s, e) => s + e.negatedVelocity ** 2, 0) / errors.length),
    maxTrajectoryPositionError, maxTrajectoryNegatedVelocityError,
    strictBenchmarkEligible: !(engine.diagnostics.counts.STABILIZATION_COLLISION || engine.diagnostics.counts.GRAZING || engine.diagnostics.counts.NUMERICAL_GRAZING_AMBIGUITY),
    maxRelativeEnergyError: engine.maxRelativeEnergyError, diagnostics: engine.diagnostics };
}
