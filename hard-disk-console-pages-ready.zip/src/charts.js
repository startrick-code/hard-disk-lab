import { SampleHistory } from './statistics.js';

/** Canvas charts consume sample copies only; rendering never advances the engine. */
export class StatisticsCharts {
  constructor() {
    this.history = new SampleHistory(); this.latest = null; this.dirty = true;
    this.grid = document.getElementById('density-grid');
    for (let row = 2; row >= 0; row--) for (let col = 0; col < 5; col++) {
      const cell = document.createElement('div'); cell.className = 'density-cell'; cell.dataset.index = row * 5 + col;
      this.grid.appendChild(cell);
    }
  }
  update(data) {
    if (Array.isArray(data.history)) { this.history.clear(); data.history.forEach(point => this.history.push(point)); }
    if (data.sampleRecord) this.history.push(data.sampleRecord);
    this.latest = data.statistics; this.enabled = data.statisticsEnabled; this.dirty = true;
    document.getElementById('statistics-enabled').checked = Boolean(this.enabled);
    document.getElementById('statistics-panels').hidden = !this.enabled;
    document.getElementById('statistics-status').textContent = !this.enabled ? '统计已关闭；物理计算继续' :
      `每 0.02 T₀ 采样 · 保留 ${this.history.length} / ${this.history.capacity} 点${this.history.dropped ? ` · 已移除 ${this.history.dropped} 个最早样本` : ''}`;
    if (!this.latest) return;
    const { spatial, speed, time, count } = this.latest;
    document.getElementById('entropy').textContent = spatial.entropy.toFixed(6);
    document.getElementById('statistics-time').textContent = time.toFixed(6);
    document.getElementById('grid-total').textContent = `${spatial.counts.reduce((s, n) => s + n, 0)} / ${count}`;
    document.getElementById('speed-total').textContent = `${speed.counts.reduce((s, n) => s + n, 0)} / ${count}`;
    document.getElementById('reference-temperature').textContent = speed.reference.defined ? speed.reference.referenceTemperature.toFixed(6) : '零能量，连续参考未定义';
    for (const cell of this.grid.children) {
      const i = Number(cell.dataset.index), number = spatial.counts[i], density = spatial.densities[i];
      cell.style.backgroundColor = `rgba(31,139,150,${0.04 + 0.5 * Math.min(1, number / Math.max(1, count / 5))})`;
      cell.replaceChildren(); const strong = document.createElement('strong'), span = document.createElement('span');
      strong.textContent = `${number} 粒子`; span.textContent = `ρ ${density.toFixed(1)}`; cell.append(strong, span);
      cell.title = `第 ${i % 5 + 1} 列，第 ${Math.floor(i / 5) + 1} 行（从下向上）；面积 ${spatial.cellArea.toPrecision(5)} L₀²`;
    }
    document.getElementById('boundary-note').textContent = spatial.boundaryAssignments ?
      `${spatial.boundaryAssignments} 个容差内边界残差归入边界格；粒子坐标未修改。` : '分箱范围为粒子中心可达矩形 [r,W−r] × [r,H−r]。';
    const tbody = document.getElementById('speed-table'); tbody.replaceChildren();
    for (let i = 0; i < 9; i++) {
      const tr = document.createElement('tr');
      const label = i === 8 ? `≥ ${speed.edges[8].toFixed(3)}` : `[${speed.edges[i].toFixed(3)}, ${speed.edges[i + 1].toFixed(3)})`;
      const values = [label, speed.counts[i], speed.probabilities[i].toFixed(4), speed.reference.defined ? speed.reference.probabilities[i].toFixed(4) : '未定义'];
      values.forEach(value => { const td = document.createElement('td'); td.textContent = value; tr.appendChild(td); }); tbody.appendChild(tr);
    }
  }
  paint() {
    if (!this.dirty || !this.enabled || !this.latest) return;
    this.dirty = false; this.entropyChart(); this.speedChart();
  }
  setup(id) {
    const canvas = document.getElementById(id), ctx = canvas.getContext('2d'), w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h); ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, w, h);
    ctx.font = '14px -apple-system, sans-serif'; ctx.lineWidth = 1; ctx.strokeStyle = '#d8e3e6';
    return { ctx, w, h, left: 58, right: w - 22, top: 22, bottom: h - 50 };
  }
  entropyChart() {
    const { ctx, left, right, top, bottom } = this.setup('entropy-chart');
    const points = this.history.toArray(), t0 = points[0]?.time ?? 0, t1 = points[points.length - 1]?.time ?? t0;
    const xmax = t1 === t0 ? t0 + 0.02 : t1, ymax = Math.log(15);
    const x = t => left + (right - left) * (t - t0) / (xmax - t0), y = h => bottom - (bottom - top) * h / ymax;
    ctx.fillStyle = '#56717b'; ctx.textAlign = 'right';
    for (const value of [0, 1, 2, ymax]) {
      ctx.beginPath(); ctx.moveTo(left, y(value)); ctx.lineTo(right, y(value)); ctx.stroke(); ctx.fillText(value === ymax ? 'ln 15' : String(value), left - 8, y(value) + 5);
    }
    ctx.textAlign = 'left'; ctx.fillText(`${t0.toFixed(2)}`, left, bottom + 23); ctx.textAlign = 'right'; ctx.fillText(`${xmax.toFixed(2)} T₀`, right, bottom + 23);
    ctx.strokeStyle = '#116f7d'; ctx.lineWidth = 2; ctx.beginPath();
    points.forEach((p, i) => { if (i === 0) ctx.moveTo(x(p.time), y(p.entropy)); else ctx.lineTo(x(p.time), y(p.entropy)); }); ctx.stroke();
    if (points.length === 1) { ctx.fillStyle = '#116f7d'; ctx.beginPath(); ctx.arc(x(t0), y(points[0].entropy), 3, 0, 2 * Math.PI); ctx.fill(); }
  }
  speedChart() {
    const { ctx, left, right, top, bottom } = this.setup('speed-chart'), { speed } = this.latest;
    const theory = speed.reference.probabilities, maximum = Math.max(0.1, ...speed.probabilities, ...(theory ?? [])) * 1.15;
    const band = (right - left) / 9, y = value => bottom - (bottom - top) * value / maximum;
    ctx.fillStyle = '#56717b'; ctx.textAlign = 'right';
    for (const value of [0, maximum / 2, maximum]) {
      ctx.strokeStyle = '#d8e3e6'; ctx.beginPath(); ctx.moveTo(left, y(value)); ctx.lineTo(right, y(value)); ctx.stroke(); ctx.fillText(value.toFixed(2), left - 8, y(value) + 5);
    }
    speed.probabilities.forEach((value, i) => {
      const center = left + band * (i + 0.5); ctx.fillStyle = '#62b9bf'; ctx.fillRect(center - band * 0.3, y(value), band * 0.6, bottom - y(value));
      if (theory) { ctx.strokeStyle = '#bd6937'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(center - band * 0.34, y(theory[i])); ctx.lineTo(center + band * 0.34, y(theory[i])); ctx.stroke(); }
      ctx.fillStyle = '#56717b'; ctx.textAlign = 'center'; ctx.font = '12px -apple-system, sans-serif';
      ctx.fillText(i === 8 ? '溢出' : `${speed.edges[i].toFixed(2)}`, center, bottom + 20);
    });
    ctx.textAlign = 'right'; ctx.fillText('速率箱 / V₀', right, bottom + 41);
  }
}
