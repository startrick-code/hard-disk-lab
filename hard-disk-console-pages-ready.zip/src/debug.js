import {ConsoleUI} from './console-ui.js';
import { D3Charts } from './d3-charts.js';
import { D2Charts } from './d2-charts.js';
import { TVCharts } from './tv-charts.js';
import { FluxCharts } from './flux-charts.js';
import { CorrelationCharts } from './correlation-charts.js';
import { StatisticsCharts } from './charts.js';
import { ExperimentCharts } from './experiment-charts.js';
const $ = id => document.getElementById(id);
let worker, activeMode = 'single';
const canvas = $('canvas'), ctx = canvas.getContext('2d');
let current, running = false, lastPaint = -Infinity, lastError, initializationRequest = 0;
const charts = new StatisticsCharts();
const experimentCharts = new ExperimentCharts();
const correlationCharts = new CorrelationCharts();
const fluxCharts = new FluxCharts(message => worker.postMessage(message));
const tvCharts = new TVCharts(message => worker.postMessage(message));
const d3Charts = new D3Charts(message => worker.postMessage(message));
const d2Charts = new D2Charts(message => worker.postMessage(message));
function setNumericSelect(id, value) {
  const select = $(id); let option = [...select.options].find(item => Number(item.value) === value);
  if (!option) { option = document.createElement('option'); option.value = String(value); option.textContent = `${value}（快照参数）`; select.appendChild(option); }
  select.value = option.value;
}
function selectWorker(mode) {
  worker?.terminate(); activeMode = mode;
  worker = new Worker(new URL(mode === 'single' ? './worker.js' : './experiment-worker.js', import.meta.url), { type: 'module' });
  const ownedWorker=worker;worker.onmessage=event=>{if(worker===ownedWorker)receive(event);};
  worker.onerror = event => { $('status').textContent = `计算模块错误：${event.message}`; $('status').classList.add('error'); };
  $('mode').value = mode; $('experiment-options').hidden = mode === 'single'; $('experiment-panels').hidden = mode === 'single';
  $('chaos-options').hidden = mode !== 'chaos'; $('reversal-options').hidden = mode !== 'reversal';
  $('reverse').disabled = $('rebase').disabled = mode !== 'single';
  $('step').textContent = mode === 'single' ? '下一事件' : '下一共同采样';
  worker.postMessage({ type: 'speed', value: Number($('speed').value) });
}
function init() {
  const seed = Number($('seed').value), count = Number($('count').value);
  if (!Number.isInteger(seed) || seed < 0 || seed > 4294967295) { $('status').textContent = '种子必须是 0～4294967295 的整数'; return; }
  lastError = null; $('status').classList.remove('error');
  if (activeMode !== $('mode').value) selectWorker($('mode').value);
  const direction = { '+x': { x: 1, y: 0 }, '-x': { x: -1, y: 0 }, '+y': { x: 0, y: 1 }, '-y': { x: 0, y: -1 } }[$('direction').value];
  worker.postMessage({ type: 'init', seed, count, preset: $('preset').value, statistics: $('statistics-enabled').checked, requestId: ++initializationRequest,
    options: { mode: activeMode, delta: Number($('delta').value), angle: Number($('angle').value), particle: Number($('particle').value),
      direction, reversalTime: Number($('reversal-time').value) } });
}
function download(snapshot) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' }));
  const a = document.createElement('a'); a.href = url; a.download = snapshot.schema === 'hard-disk-experiment/v1' ? `hard-disk-${snapshot.options.mode}-t-${snapshot.commonTime.toFixed(6)}.json` : `hard-disk-seed-${snapshot.seed}-t-${snapshot.time.toFixed(6)}.json`; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function receive({ data }) {
  if(consoleUI.handleBundle(data))return;
  if (data.type === 'ready' && data.requestId !== undefined) document.body.dataset.initialization = String(data.requestId);
  charts.update(data);
  correlationCharts.update(data);
  fluxCharts.update(data);
  tvCharts.update(data);
  d3Charts.update(data);
  if (data.type.startsWith('d3-export-')) return;
  d2Charts.update(data);
  if (data.type === 'd2-export') return;
  experimentCharts.update(data);
  if (data.state) {
    current = data.state; running = data.running;
    $('time').textContent = current.time.toFixed(6); $('pairs').textContent = current.pairCollisions.toLocaleString(); $('walls').textContent = current.wallCollisions.toLocaleString();
    $('energy').textContent = current.signedEnergyError.toExponential(3); $('max-energy').textContent = current.maxRelativeEnergyError.toExponential(3); $('momentum').textContent = current.momentumBalance.norm.toExponential(3);
    $('diagnostics').textContent = JSON.stringify({ counts: current.diagnostics.counts, halted: current.halted, wallImpulse: current.wallImpulse, interventionImpulse: current.interventionImpulse, latestExamples: current.diagnostics.examples.slice(-5) }, null, 2);
  }
  $('play').textContent = running ? '暂停' : '运行'; $('play').disabled = Boolean(current?.halted) || Boolean(data.complete) || Boolean(data.experimentHalted); $('step').disabled = running || Boolean(current?.halted) || Boolean(data.complete) || Boolean(data.experimentHalted);
  if (data.type === 'error') {
    lastError = data.error; $('status').classList.add('error'); $('status').textContent = `已停止：${data.error.code ?? data.error.message}`;
    $('diagnostics').textContent += '\n' + JSON.stringify(data.error, null, 2);
  } else if (!lastError) $('status').textContent = running ? '运行中 · 固定物理时刻采样' : '已暂停';
  if (data.type === 'snapshot') download(data.snapshot);
  consoleUI.update(data);
  if (data.type === 'audit') $('diagnostics').textContent += '\n穿透审计：' + JSON.stringify(data.audit);
}
$('play').onclick = () => worker.postMessage({ type: running ? 'pause' : 'play' });
$('reset').onclick = init;
$('mode').onchange = () => { selectWorker($('mode').value); init(); };
$('branch').onchange = () => worker.postMessage({ type: 'branch', branch: $('branch').value });
$('log-scale').onchange = () => { experimentCharts.dirty = true; };
for (const [id, type] of [['step', 'step'], ['save', 'snapshot'], ['audit', 'audit'], ['reverse', 'reverse'], ['rebase', 'rebase']]) $(id).onclick = () => { lastError = null; $('status').classList.remove('error'); worker.postMessage({ type }); };
$('speed').onchange = () => worker.postMessage({ type: 'speed', value: Number($('speed').value) });
$('correlations-enabled').onchange = () => worker.postMessage({ type: 'correlations', enabled: $('correlations-enabled').checked, window: Number($('correlation-window').value) });
$('correlation-window').onchange = () => $('correlations-enabled').onchange();
$('statistics-enabled').onchange = () => worker.postMessage({ type: 'statistics', enabled: $('statistics-enabled').checked });
$('load').onchange = async () => {
  try {
    const snapshot = JSON.parse(await $('load').files[0].text()); lastError = null;
    const mode = snapshot.schema === 'hard-disk-experiment/v1' ? snapshot.options.mode : 'single';
    const initial = mode === 'single' ? snapshot : snapshot.initial;
    $('seed').value = initial.seed ?? 1; $('count').value = initial.particles.length; $('preset').value = initial.metadata?.preset ?? 'uniform';
    if (mode !== 'single') {
      $('particle').value = snapshot.options.particle; $('reversal-time').value = snapshot.options.reversalTime;
      setNumericSelect('delta', snapshot.options.delta); setNumericSelect('angle', snapshot.options.angle);
      const d = snapshot.options.direction;
      if (d.y === 0) $('direction').value = d.x >= 0 ? '+x' : '-x'; else if (d.x === 0) $('direction').value = d.y >= 0 ? '+y' : '-y';
      if (snapshot.view) { $('statistics-enabled').checked = snapshot.view.statisticsEnabled; $('speed').value = snapshot.view.playbackSpeed; }
    }
    if (mode !== activeMode) selectWorker(mode);
    worker.postMessage({ type: 'restore', snapshot, requestId: ++initializationRequest });
  }
  catch (error) { $('status').textContent = `快照读取失败：${error.message}`; }
  $('load').value = '';
};
document.addEventListener('visibilitychange', () => { if (document.hidden) worker.postMessage({ type: 'pause' }); });
function paint(timestamp) {
  requestAnimationFrame(paint);
  if (!current || timestamp - lastPaint < 1000 / 30) return;
  lastPaint = timestamp; const { box, particles } = current;
  charts.paint();
  if (activeMode !== 'single') experimentCharts.paint();
  ctx.fillStyle = '#102630'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  const scale = canvas.width / box.x;
  ctx.strokeStyle = '#2b4752'; ctx.lineWidth = 1;
  const r = particles[0].radius, x0 = r * scale, x1 = (box.x - r) * scale, y0 = r * scale, y1 = (box.y - r) * scale;
  for (let i = 0; i <= 5; i++) { const x = x0 + (x1 - x0) * i / 5; ctx.beginPath(); ctx.moveTo(x, y0); ctx.lineTo(x, y1); ctx.stroke(); }
  for (let i = 0; i <= 3; i++) { const y = y0 + (y1 - y0) * i / 3; ctx.beginPath(); ctx.moveTo(x0, y); ctx.lineTo(x1, y); ctx.stroke(); }
  particles.forEach((p, i) => {
    const x = p.x * scale, y = canvas.height - p.y * scale;
    ctx.fillStyle = i === 0 ? '#ffc57a' : '#78d7db'; ctx.beginPath(); ctx.arc(x, y, p.radius * scale, 0, Math.PI * 2); ctx.fill();
  });
}
async function prepareConsole(config){
  worker.postMessage({type:'pause'});
  const candidate=new Worker(new URL(config.dynamics==='single'?'./worker.js':'./experiment-worker.js',import.meta.url),{type:'module'}),requestId=++initializationRequest;
  try {const data=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('准备超时；未切换实验')),30000);candidate.onerror=e=>{clearTimeout(timer);reject(Error(e.message));};candidate.onmessage=({data})=>{if(data.type==='error'){clearTimeout(timer);reject(Error(data.error?.message??'准备失败'));}else if(data.type==='ready'&&data.requestId===requestId){clearTimeout(timer);resolve(data);}};candidate.postMessage({type:'prepare-experiment',config,requestId,runId:'run-'+Date.now().toString(36)+'-'+requestId});});
    worker.terminate();worker=candidate;activeMode=config.dynamics;worker.onmessage=event=>{if(worker===candidate)receive(event);};worker.onerror=event=>{$('status').textContent='计算模块错误：'+event.message;};
    $('mode').value=config.dynamics;$('experiment-options').hidden=config.dynamics==='single';$('experiment-panels').hidden=config.dynamics==='single';$('chaos-options').hidden=config.dynamics!=='chaos';$('reversal-options').hidden=config.dynamics!=='reversal';$('reverse').disabled=$('rebase').disabled=config.dynamics!=='single';
    $('seed').value=config.seed;setNumericSelect('count',config.count);$('preset').value=config.preset;$('speed').value=config.speed;lastError=null;$('status').classList.remove('error');receive({data});
  }catch(e){candidate.terminate();throw e;}
}
const consoleUI=new ConsoleUI({send:message=>worker.postMessage(message),prepare:prepareConsole});
selectWorker('single'); init(); requestAnimationFrame(paint);
