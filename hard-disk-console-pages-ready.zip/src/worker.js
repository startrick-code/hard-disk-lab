import {ConsoleRun,preparedObservers,exportManifest,streamBundle} from './console-runtime.js';
import {validateConfig} from './experiment-config.js';
const consoleRun=new ConsoleRun();let bundleBusy=false,stepOnce=false;
import { streamD3Export } from './d3-reference.js';
import { CorrelationController } from './correlations.js';
let correlations = new CorrelationController();
import { HardDiskEngine } from './engine.js';
import { createModel } from './model.js';
import { sampleStatistics, SAMPLE_INTERVAL, SampleHistory } from './statistics.js';

let engine, running = false, timer = null, target = 0.02, speed = 0.25, sampleOrigin = 0, sampleIndex = 1;
const sampleInterval = SAMPLE_INTERVAL, history = new SampleHistory();
let statisticsEnabled = true;
function observe(state) { return statisticsEnabled ? sampleStatistics(state, engine.initialEnergy, engine.geometryTolerance) : null; }
function record(stats, state) {
  if (!stats) return null;
  const point = { time: state.time, entropy: stats.spatial.entropy, collisions: state.collisions, energyError: state.signedEnergyError };
  history.push(point); return point;
}
function restartSampling() {
  sampleOrigin = engine.time; sampleIndex = 1; target = sampleOrigin + sampleInterval;
  history.clear(); const state = engine.state(); record(observe(state), state);
}
function stop() { stepOnce=false; running = false; clearTimeout(timer); timer = null; }
function send(type = 'state', extra = {}) {
  const state = engine?.state(), statistics = state && type !== 'error' ? observe(state) : null;
  postMessage({ type, console:engine?consoleRun.view(engine,correlations,'single',{},speed,running):null, correlations: correlations.view(state), state, statistics, statisticsEnabled, running, ...extra });
}
function pump() {
  if (!running || !engine) return;
  const started = performance.now(); let count = 0, reached = false;
  try {
    while (count < 500 && performance.now() - started < 4) {
      const result = engine.advanceTo(target, 1); count += result.processed;
      if (result.reached) { reached = true; break; }
    }
    if (reached) {
      const state = engine.state(); correlations.sample(state); if(consoleRun.check(engine,correlations)||stepOnce){stepOnce=false;stop();} const statistics = observe(state), sampleRecord = record(statistics, state);
      postMessage({ type: 'sample', console:consoleRun.view(engine,correlations,'single',{},speed,running), correlations: correlations.view(state), state, statistics, statisticsEnabled, running, sampleTime: target, sampleRecord });
      sampleIndex++; target = sampleOrigin + sampleIndex * sampleInterval;
      if(running)timer = setTimeout(pump, Math.max(0, sampleInterval / speed * 1000 - (performance.now() - started)));
    } else timer = setTimeout(pump, 0);
  } catch (error) { stop(); send('error', { error: { code: error.code, message: error.message, details: error.details }, snapshot: engine.snapshot() }); }
}
onmessage = ({ data }) => {
  if(bundleBusy&&data.type!=='pause'){postMessage({type:'bundle-busy'});return;}
  try {
    if(['d3-clear','d2-clear','tv-history-clear','flux-reference','d2-recording','d3-recording','correlations','branch','reverse','rebase'].includes(data.type))consoleRun.note(data.type,engine?.time??0);
    switch (data.type) {
      case 'prepare-experiment': {
        stop();const config=validateConfig(data.config);if(config.dynamics!=='single')throw Error('请选择对应动力学Worker');
        const nextEngine=new HardDiskEngine(createModel(config.seed,config.count,config.preset));
        const nextObservers=preparedObservers(nextEngine,config);
        correlations.detach?.();engine=nextEngine;correlations=nextObservers;speed=config.speed;statisticsEnabled=true;
        consoleRun.begin(config,data.runId,engine,correlations);restartSampling();send('ready',{prepared:true,requestId:data.requestId,history:history.toArray()});break;
      }
      case 'console-step': if(!running){stepOnce=true;running=true;pump();} break;
      case 'bundle-export': {
        stop();send('status');bundleBusy=true;
        const view=consoleRun.view(engine,correlations,'single',{},speed,running);
        streamBundle(correlations,exportManifest(view,correlations,data.selection),m=>postMessage(m),()=>{bundleBusy=false;});break;
      }

      case 'init':
        stop(); consoleRun.legacy(); engine = new HardDiskEngine(createModel(data.seed, data.count, data.preset)); statisticsEnabled = data.statistics !== false;
        correlations.reset(); correlations.bind(engine); restartSampling(); send('ready', { history: history.toArray(), requestId: data.requestId }); break;
      case 'play': if(consoleRun.outcome&&consoleRun.config){consoleRun.note('resume_as_manual',engine.time);consoleRun.config.stop.kind='manual';consoleRun.outcome=null;}
        if (!running) { running = true; send('status'); pump(); } break;
      case 'pause': stop(); send('status'); break;
      case 'step': stop(); engine.step(); correlations.sample(engine.state()); restartSampling(); send('state', { history: history.toArray() }); break;
      case 'reverse': stop(); engine.reverseVelocities(); correlations.reset(); correlations.bind(engine); restartSampling(); send('state', { history: history.toArray() }); break;
      case 'speed':
        if (!Number.isFinite(data.value) || data.value <= 0 || data.value > 2) throw new Error('Invalid playback speed');
        speed = data.value; break;
      case 'snapshot': send('snapshot', { requestId: data.requestId, snapshot: correlations.enabled||consoleRun.config ? { ...engine.snapshot(), correlations: correlations.snapshot(), sampling: {sampleOrigin,sampleIndex,target}, ...(consoleRun.config?{consoleSession:{...consoleRun.snapshot(),playbackSpeed:speed}}:{}) } : engine.snapshot() }); break;
      case 'restore':
        stop(); consoleRun.restore(data.snapshot.consoleSession); if(data.snapshot.consoleSession){const savedSpeed=data.snapshot.consoleSession.playbackSpeed;if(!Number.isFinite(savedSpeed)||savedSpeed<=0||savedSpeed>2)throw Error('Invalid saved console speed');speed=savedSpeed;} engine = HardDiskEngine.restore(data.snapshot); correlations.restore(data.snapshot.correlations, engine); restartSampling(); if(data.snapshot.sampling){const q=data.snapshot.sampling;if(!Number.isFinite(q.sampleOrigin)||!Number.isSafeInteger(q.sampleIndex)||q.sampleIndex<1||!Number.isFinite(q.target)||q.target<engine.time)throw Error('INVALID_SAMPLE_CLOCK');sampleOrigin=q.sampleOrigin;sampleIndex=q.sampleIndex;target=q.target;} send('ready', { history: history.toArray(),requestId:data.requestId }); break;
      case 'rebase': stop(); engine.rebaseTimeOrigin(); correlations.reset(); correlations.bind(engine); restartSampling(); send('state', { history: history.toArray() }); break;
      case 'audit': send('audit', { audit: engine.audit() }); break;
      case 'd3-recording': correlations.enableD3(data.enabled); send('correlations'); break;
      case 'd3-clear': correlations.d3.clear(); send('correlations'); break;
      case 'd3-export': streamD3Export(correlations.d3); break;
      case 'd2-recording': if(data.enabled && !correlations.enabled)correlations.set(true); correlations.bind(engine); correlations.enableD2(data.enabled); send('correlations'); break;
      case 'd2-clear': correlations.clearD2(); send('correlations'); break;
      case 'd2-analysis': correlations.d2.refresh(engine.time,true,data.selection); send('correlations'); break;
      case 'd2-export': postMessage({type:'d2-export',csv:correlations.d2.csv()}); break;
      case 'tv-history-clear': correlations.tvHistory.clear(); send('correlations'); break;
      case 'tv-history-recording': correlations.tvHistory.setEnabled(data.enabled); send('correlations'); break;
      case 'flux-reference': if(data.enabled && !correlations.enabled)correlations.set(true); correlations.bind(engine); correlations.enableFlux(data.enabled, data.options); send('correlations'); break;
      case 'correlations': correlations.set(data.enabled === true, data.window); correlations.bind(engine); send('correlations'); break;
      case 'statistics':
        statisticsEnabled = data.enabled !== false; history.clear(); send('statistics', { history: [] }); break;
      case 'statistics-history': send('statistics-history', { history: history.toArray(), dropped: history.dropped, capacity: history.capacity }); break;
    }
  } catch (error) { stop(); send('error', { error: { code: error.code, message: error.message, details: error.details }, snapshot: engine?.snapshot() }); }
};
