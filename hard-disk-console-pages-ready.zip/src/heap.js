/** Indexed min heap: exactly one entry per interaction key, no stale tombstones. */
export class IndexedMinHeap {
  constructor() { this.items = []; this.indices = new Map(); }
  get size() { return this.items.length; }
  peek() { return this.items[0]; }
  static less(a, b) { return a.time < b.time || (a.time === b.time && a.key < b.key); }
  swap(i, j) {
    [this.items[i], this.items[j]] = [this.items[j], this.items[i]];
    this.indices.set(this.items[i].key, i); this.indices.set(this.items[j].key, j);
  }
  up(i) {
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (!IndexedMinHeap.less(this.items[i], this.items[p])) break;
      this.swap(i, p); i = p;
    }
    return i;
  }
  down(i) {
    for (;;) {
      let m = i, l = i * 2 + 1, r = l + 1;
      if (l < this.size && IndexedMinHeap.less(this.items[l], this.items[m])) m = l;
      if (r < this.size && IndexedMinHeap.less(this.items[r], this.items[m])) m = r;
      if (m === i) return i;
      this.swap(i, m); i = m;
    }
  }
  set(event) {
    if (!Number.isFinite(event.time)) throw new TypeError('Nonfinite heap time');
    const i = this.indices.get(event.key);
    if (i === undefined) {
      this.indices.set(event.key, this.size); this.items.push(event); this.up(this.size - 1);
    } else { this.items[i] = event; this.down(this.up(i)); }
  }
  delete(key) {
    const i = this.indices.get(key);
    if (i === undefined) return;
    const last = this.items.pop(); this.indices.delete(key);
    if (i < this.size) {
      this.items[i] = last; this.indices.set(last.key, i); this.down(this.up(i));
    }
  }
  pop() { const e = this.peek(); if (e) this.delete(e.key); return e; }
  clear() { this.items = []; this.indices.clear(); }
  assertValid() {
    if (this.indices.size !== this.size) throw new Error('Index cardinality');
    this.items.forEach((e, i) => {
      if (this.indices.get(e.key) !== i) throw new Error('Index mismatch');
      if (i && IndexedMinHeap.less(e, this.items[(i - 1) >> 1])) throw new Error('Heap ordering');
    });
  }
}
