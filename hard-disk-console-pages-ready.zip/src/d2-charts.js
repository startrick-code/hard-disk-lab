const $=id=>document.getElementById(id),fmt=x=>x==null?'未定义':Number(x).toPrecision(5);
export class D2Charts {
  constructor(send){this.send=send;this.lastKey=null;
    $('d2-enabled').onchange=()=>send({type:'d2-recording',enabled:$('d2-enabled').checked});
    $('d2-clear').onclick=()=>send({type:'d2-clear'});$('d2-export').onclick=()=>send({type:'d2-export'});
    $('d2-refresh').onclick=()=>$('d2-segment').onchange();
    for(const id of ['d2-segment','d2-window'])$(id).onchange=()=>{if(id==='d2-segment')$('d2-window').value='all';send({type:'d2-analysis',selection:{segment:$('d2-segment').value,window:$('d2-window').value}});};
    $('d2-category').onchange=()=>this.plot();}
  update(data){if(data.type==='d2-export'){const url=URL.createObjectURL(new Blob([data.csv],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download='d2-real-collisions.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);return;}
    if(!('correlations' in data))return;const d=data.correlations?.d2;this.data=d;
    $('d2-enabled').checked=d?.enabled??false;$('d2-export').disabled=!d?.count;
    $('d2-status').textContent=d?`${d.count} / ${d.capacity} 条真实粒子碰撞 · ${d.enabled?'记录开启':'记录关闭'}${d.truncated?' · 数据已截断，不能作为完整样本':''}${d.error?' · '+d.error:''}`:'D2 未开启';
    const key=JSON.stringify([d?.analysis?.updatedAt,d?.analysis?.n,d?.analysis?.segment,d?.analysis?.window,d?.segments.map(s=>[s.id,s.windows]),d?.audits.length,d?.audits.at(-1)?.end]);if(key===this.lastKey&&data.type!=='ready')return;this.lastKey=key;
    const selected=$('d2-segment').value||'latest',choicesKey=JSON.stringify([selected,d?.segments.map(s=>[s.id,s.windows])]);if(choicesKey!==this.choicesKey){this.choicesKey=choicesKey;$('d2-segment').replaceChildren();const add=(el,value,text)=>{const option=document.createElement('option');option.value=value;option.textContent=text;el.appendChild(option);};add($('d2-segment'),'latest','最新连续记录段');for(const s of d?.segments??[])add($('d2-segment'),String(s.id),`段${s.id} · ${s.branch} · ${s.epoch} · ${s.count}事件`);$('d2-segment').value=[...$('d2-segment').options].some(o=>o.value===selected)?selected:'latest';
    const sid=$('d2-segment').value==='latest'?d?.segments.at(-1)?.id:Number($('d2-segment').value),segment=d?.segments.find(s=>s.id===sid),win=$('d2-window').value||'all';$('d2-window').replaceChildren();add($('d2-window'),'all','本段全部真实碰撞');for(const w of segment?.windows??[])add($('d2-window'),String(w),`D1窗口 ${w} · 仅区域内`);$('d2-window').value=[...$('d2-window').options].some(o=>o.value===win)?win:'all';}
    const a=d?.analysis;$('d2-analysis-status').textContent=a?`分析段 ${a.segment} · ${a.scope} · N=${a.n} · 更新至t=${fmt(a.updatedAt)} T₀ · ${a.error??'ESS：无法可靠估计'} · 统计显示可能滞后至下一次0.2 T₀更新；可手动刷新`:'暂无分析样本；开启后连续运行或点击刷新';
    const intervals=(s)=>s?`n=${s.n}，均值=${fmt(s.mean)}，标准差=${fmt(s.std)}，最小=${fmt(s.min)}，最大=${fmt(s.max)} T₀`:'未定义';
    $('d2-intervals').textContent=a&&!a.error?`相邻事件共享粒子比例=${fmt(a.sharedParticleRatio)}（${a.adjacentPairs}对）；系统相邻事件时间间隔：${intervals(a.systemIntervals)}；同一粒子相邻参与间隔合并：${intervals(a.particleIntervals)}`:'样本不足';
    $('d2-particles').textContent=a?.byParticle?.map(p=>`${p.id}：${intervals(p)}`).join('\n')??'';
    $('d2-acf-table').innerHTML=(a?.acf??[]).map(c=>`<tr><td>${c.category}</td><td>${fmt(c.mean)}</td><td>${c.status}</td><td>${c.lags.map(l=>`${l.lag}: ${fmt(l.value)} (${l.pairs}对)`).join('；')}</td></tr>`).join('');
    $('d2-audits').innerHTML=(d?.audits??[]).slice(-20).reverse().map(w=>`<tr><td>${w.branch}/${w.epoch}</td><td>(${w.start.toFixed(4)},${w.end.toFixed(4)}]</td><td>${w.d1}</td><td>${w.d2}</td><td>${w.status}</td></tr>`).join('');
    $('d2-audit-note').textContent=`保留最近200项窗口核对，已丢弃旧核对 ${d?.auditsDropped??0} 项；此操作不删除原始事件。表中仅显示最近20项。`;this.plot();}
  plot(){const c=$('d2-acf'),ctx=c.getContext('2d');ctx.clearRect(0,0,c.width,c.height);ctx.font='14px sans-serif';ctx.fillStyle='#344c55';ctx.fillText('指示变量 ACF · 横轴为事件序号滞后 k（不是物理时间）',12,20);ctx.strokeStyle='#c6d0d3';for(const [v,label]of [[1,'1'],[0,'0'],[-1,'−1']]){const y=150-v*105;ctx.beginPath();ctx.moveTo(45,y);ctx.lineTo(700,y);ctx.stroke();ctx.fillStyle='#344c55';ctx.fillText(label,10,y+4);}const filter=$('d2-category').value;
    for(const [index,a] of (this.data?.analysis?.acf??[]).entries()){if(filter!=='all'&&filter!==a.category)continue;ctx.strokeStyle=['#177b83','#b36a16','#ad416a'][index];ctx.beginPath();let pen=false;for(const p of a.lags){if(p.value===null){pen=false;continue;}const x=45+(p.lag-1)/19*650,y=150-p.value*105;if(pen)ctx.lineTo(x,y);else ctx.moveTo(x,y);pen=true;}ctx.stroke();}
    ctx.fillStyle='#344c55';ctx.fillText('1',45,280);ctx.fillText('20',680,280);}
}
