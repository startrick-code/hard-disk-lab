/** UI configuration only. Does not generate particles or reference proposals. */
export const PROJECT_VERSION='d3a-console-1.0.0';
export const MODE_NAMES={basic:'基础动力学',d1:'D1 独立参考与 TV 统计',d2:'D2 碰撞时间关联',d3a:'D3-A 连续速度参考实验'};
export function presetConfig(mode='basic'){
  if(!(mode in MODE_NAMES))throw Error('未知实验模式');
  return {mode,dynamics:'single',count:100,seed:1,preset:'uniform',d1:{region:'all',window:mode==='basic'?.2:1,grid:'3x2',proposals:128},recorders:{d1:mode!=='basic',d2:['d2','d3a'].includes(mode),d3:mode==='d3a'},speed:.25,stop:{kind:'manual',time:2,windows:2},options:{mode:'single',particle:0,delta:1e-8,angle:1e-8,direction:{x:1,y:0},reversalTime:2}};
}
export function validateConfig(value){
  const c=structuredClone(value),fail=m=>{throw Error(m);};
  if(!(c.mode in MODE_NAMES)||!['single','chaos','reversal'].includes(c.dynamics))fail('实验模式无效');
  if(!Number.isInteger(c.count)||c.count<50||c.count>200)fail('N 必须为50～200的整数');
  if(!Number.isInteger(c.seed)||c.seed<0||c.seed>4294967295)fail('Seed 必须为0～4294967295的整数');
  if(!['uniform','left','mono-speed'].includes(c.preset))fail('初态无效');
  if(![.2,.5,1].includes(c.d1?.window)||!['3x2','5x3'].includes(c.d1.grid)||![128,512,2048].includes(c.d1.proposals)||!['all','left','right','interior','wall'].includes(c.d1.region))fail('D1参数无效');
  for(const k of ['d1','d2','d3'])if(typeof c.recorders?.[k]!=='boolean')fail('记录器开关无效');
  if(c.recorders.d3&&!c.recorders.d1)fail('D3-A 必须启用 D1；不会自动创建另一套抽样');
  if(!Number.isFinite(c.speed)||c.speed<=0||c.speed>2)fail('播放速度必须在(0,2] T₀/现实秒');
  if(!['manual','time','windows'].includes(c.stop?.kind)||!Number.isFinite(c.stop.time)||c.stop.time<=0||c.stop.time>10000||!Number.isSafeInteger(c.stop.windows)||c.stop.windows<1||c.stop.windows>200)fail('停止条件无效（时间0～10000 T₀，窗口数1～200）');
  if(c.stop.kind==='windows'&&!c.recorders.d1)fail('按完整D1窗口暂停需要启用D1');
  if(c.dynamics!=='single'&&c.stop.kind==='windows')fail('多系统会在反演或切换分支时更换统计epoch；请改用物理时间或手动暂停');
  c.options={...c.options,mode:c.dynamics};
  const o=c.options;
  if(!Number.isSafeInteger(o.particle)||o.particle<0||o.particle>=c.count||!Number.isFinite(o.delta)||o.delta<0||!Number.isFinite(o.angle)||!Number.isFinite(o.reversalTime)||o.reversalTime<=0||o.reversalTime>20||!Number.isFinite(o.direction?.x)||!Number.isFinite(o.direction?.y)||Math.hypot(o.direction.x,o.direction.y)===0)fail('高级实验参数无效');
  if(o.sampleInterval!==undefined&&(!Number.isFinite(o.sampleInterval)||o.sampleInterval<.005||o.sampleInterval>.1))fail('高级采样间隔无效');
  return c;
}
export function estimateCapacity(c){
  const time=c.stop.kind==='time'?c.stop.time:c.stop.kind==='windows'?c.stop.windows*c.d1.window:null;
  const rows=time===null?null:Math.ceil(time/.02-1e-10)*c.d1.proposals;
  return {capacity:20000,estimatedRows:c.recorders.d3?rows:0,warning:!c.recorders.d3?null:rows===null?'手动结束无法预估容量；20,000条上限保持不变':rows>20000?'预计D3-A容量不足：请减少提议数、时长或窗口数；仍可记录，但会如实截断':'按固定0.02 T₀采样估算；额外单步/跨边界用途可能增加记录数'};
}
export function configKey(c){const v=structuredClone(c);delete v.speed;return stableJSON(v);}
export function modeFromFlags(flags){return flags.d3?'d3a':flags.d2?'d2':flags.d1?'d1':'basic';}

export function stableJSON(v){return JSON.stringify(v,(_,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);}
