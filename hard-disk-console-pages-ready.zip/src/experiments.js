import { HardDiskEngine } from './engine.js';
import { PhysicsError, positionAt } from './physics.js';
import { spatialStatistics, SampleHistory } from './statistics.js';

export const EXPERIMENT_SCHEMA = 'hard-disk-experiment/v1';
export const EXPERIMENT_VERSION = '1.0.0';
export const REVERSAL_TOLERANCE = 1e-8;
export const REFERENCE_EVENT_LIMIT = 20000;
const clone = value => JSON.parse(JSON.stringify(value));
const fail = (code, details = {}) => { throw new PhysicsError(code, details); };
const finite = (...xs) => { if (!xs.every(Number.isFinite)) fail('EXPERIMENT_NONFINITE'); };
function freeze(value) { Object.freeze(value); for (const v of Object.values(value)) if (v && typeof v === 'object' && !Object.isFrozen(v)) freeze(v); return value; }

export function modelUnits(snapshot) {
  const length = snapshot.box.x, speed = Math.sqrt(2 * snapshot.initialEnergy / (snapshot.particles.length * snapshot.particles[0].mass));
  finite(length, speed); if (length <= 0 || speed <= 0) fail('EXPERIMENT_ZERO_SPEED_SCALE');
  return { length, speed, time: length / speed };
}
/** Euclidean distance for fixed particle IDs, with explicit velocity sign for reversal. */
export function deviations(a, b, units, reverseReference = false) {
  if (a.particles.length !== b.particles.length) fail('EXPERIMENT_PARTICLE_COUNT');
  let dx2 = 0, dv2 = 0;
  a.particles.forEach((p, i) => {
    const q = b.particles[i];
    dx2 += (p.x - q.x) ** 2 + (p.y - q.y) ** 2;
    dv2 += (p.vx + (reverseReference ? q.vx : -q.vx)) ** 2 + (p.vy + (reverseReference ? q.vy : -q.vy)) ** 2;
  });
  const n = a.particles.length, position = Math.sqrt(dx2 / n), velocity = Math.sqrt(dv2 / n);
  finite(position, velocity);
  return { position, velocity, normalizedPosition: position / units.length, normalizedVelocity: velocity / units.speed,
    phase: Math.sqrt(dx2 / n / units.length ** 2 + dv2 / n / units.speed ** 2) };
}
/** Explicit intervention through a validated new snapshot, never externally writes engine storage. */
export function perturbPosition(snapshot, particle, delta, direction = { x: 1, y: 0 }) {
  const s = clone(snapshot), p = s.particles[particle];
  finite(delta, direction.x, direction.y);
  if (!p || !Number.isSafeInteger(particle) || delta < 0) fail('POSITION_PERTURBATION_PARAMETERS');
  const norm = Math.hypot(direction.x, direction.y); if (norm === 0) fail('POSITION_PERTURBATION_PARAMETERS');
  if (delta === 0) return { engine: HardDiskEngine.restore(s), intervention: { kind: 'position', time: s.time, particle, requestedDelta: 0, actualDx: 0, actualDy: 0, deltaMomentum: { x: 0, y: 0 }, energyChange: 0 } };
  const pos = positionAt(p, s.time), dx = delta * s.box.x * direction.x / norm, dy = delta * s.box.x * direction.y / norm;
  Object.assign(p, { x: pos.x + dx, y: pos.y + dy, at: s.time, version: p.version + 1 });
  if (p.x < p.radius || p.x > s.box.x - p.radius || p.y < p.radius || p.y > s.box.y - p.radius) fail('POSITION_PERTURBATION_OUTSIDE', { particle });
  for (let j = 0; j < s.particles.length; j++) if (j !== particle) {
    const q = s.particles[j], qpos = positionAt(q, s.time), gap = Math.hypot(p.x - qpos.x, p.y - qpos.y) - p.radius - q.radius;
    if (gap < 0) fail('POSITION_PERTURBATION_OVERLAP', { particle, other: j, gap });
  }
  const engine = HardDiskEngine.restore(s);
  return { engine, intervention: { kind: 'position', time: s.time, particle, requestedDelta: delta,
    actualDx: p.x - pos.x, actualDy: p.y - pos.y, deltaMomentum: { x: 0, y: 0 }, energyChange: engine.state().energy - HardDiskEngine.restore(snapshot).state().energy } };
}
export function rotateVelocity(engine, particle, angle) {
  finite(angle); const s = engine.snapshot(), p = s.particles[particle];
  if (!p || !Number.isSafeInteger(particle)) fail('VELOCITY_PERTURBATION_PARAMETERS');
  if (angle === 0) return { engine, intervention: { kind: 'rotation', time: s.time, particle, angle: 0, deltaMomentum: { x: 0, y: 0 }, energyChange: 0 } };
  const pos = positionAt(p, s.time), before = { vx: p.vx, vy: p.vy }, c = Math.cos(angle), sn = Math.sin(angle);
  Object.assign(p, pos, { vx: c * before.vx - sn * before.vy, vy: sn * before.vx + c * before.vy, at: s.time, version: p.version + 1 });
  const rotated = HardDiskEngine.restore(s), deltaMomentum = { x: p.mass * (p.vx - before.vx), y: p.mass * (p.vy - before.vy) };
  rotated.addImpulse('intervention', deltaMomentum);
  return { engine: rotated, intervention: { kind: 'rotation', time: s.time, particle, angle, deltaMomentum,
    energyChange: rotated.state().energy - engine.state().energy } };
}

/** Read-only forward piecewise free-flight history. Only comparisons can query it. */
export class ForwardReference {
  #initial;
  #tracks;
  #events;
  constructor(state) {
    this.#initial = clone(state); this.#tracks = state.particles.map(p => [{ time: state.time, x: p.x, y: p.y, vx: p.vx, vy: p.vy }]);
    this.#events = []; this.maxTime = state.time;
  }
  get eventCount() { return this.#events.length; }
  ensureCapacity() { if (this.eventCount >= REFERENCE_EVENT_LIMIT) fail('REFERENCE_CAPACITY', { limit: REFERENCE_EVENT_LIMIT }); }
  record(event, state) {
    this.ensureCapacity();
    this.#events.push({ time: event.time, uncertainty: event.uncertainty, key: event.key, kind: event.kind });
    for (const i of event.kind === 'pair' ? [event.i, event.j] : [event.i]) {
      const p = state.particles[i]; this.#tracks[i].push({ time: state.time, x: p.x, y: p.y, vx: p.vx, vy: p.vy });
    }
    this.maxTime = state.time;
  }
  static latest(records, time) {
    let lo = 0, hi = records.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (records[mid].time <= time) lo = mid + 1; else hi = mid; }
    return lo - 1;
  }
  at(time) {
    finite(time); if (time < this.#initial.time || time > this.maxTime) fail('REFERENCE_TIME_RANGE', { time, maxTime: this.maxTime });
    const particles = this.#tracks.map((track, i) => {
      const p = track[ForwardReference.latest(track, time)], dt = time - p.time;
      return { ...this.#initial.particles[i], x: p.x + p.vx * dt, y: p.y + p.vy * dt, vx: p.vx, vy: p.vy, at: time };
    });
    const index = ForwardReference.latest(this.#events, time);
    const nearby = [this.#events[index], this.#events[index + 1]].filter(Boolean);
    const collisionAmbiguous = nearby.some(e => Math.abs(e.time - time) <= e.uncertainty);
    return { time, box: { ...this.#initial.box }, particles, collisionAmbiguous };
  }
  snapshot() { return clone({ initial: this.#initial, tracks: this.#tracks, events: this.#events, maxTime: this.maxTime }); }
  static restore(s) {
    if (!s || s.events.length > REFERENCE_EVENT_LIMIT || s.tracks.length !== s.initial.particles.length) fail('REFERENCE_SNAPSHOT');
    const ref = new ForwardReference(s.initial); finite(s.maxTime);
    const recordCount = s.tracks.reduce((n, track) => n + track.length, 0);
    if (recordCount > s.tracks.length + 2 * REFERENCE_EVENT_LIMIT) fail('REFERENCE_SNAPSHOT');
    for (const track of s.tracks) {
      if (!track.length) fail('REFERENCE_SNAPSHOT');
      track.forEach((p, i) => { finite(p.time, p.x, p.y, p.vx, p.vy); if (i && p.time < track[i - 1].time) fail('REFERENCE_SNAPSHOT'); });
    }
    s.events.forEach((e, i) => { finite(e.time, e.uncertainty); if (i && e.time < s.events[i - 1].time) fail('REFERENCE_SNAPSHOT'); });
    ref.#tracks = clone(s.tracks); ref.#events = clone(s.events); ref.maxTime = s.maxTime; return ref;
  }
}

/** Synchronization controller; no collision math, no trajectory replay, no renderer dependencies. */
export class ExperimentSession {
  #source;
  #forkSource = null;
  #reference = null;
  #history = new SampleHistory();
  constructor(config, options = {}) {
    this.options = freeze(clone({ mode: 'chaos', delta: 1e-8, particle: 0, direction: { x: 1, y: 0 }, angle: 1e-8,
      reversalTime: 2, sampleInterval: 0.02, validateEveryEvent: false, ...options }));
    const o = this.options;
    if (!['chaos', 'reversal'].includes(o.mode)) fail('EXPERIMENT_MODE');
    finite(o.sampleInterval, o.reversalTime, o.delta, o.angle);
    if (o.sampleInterval < 0.005 || o.sampleInterval > 0.1 || o.reversalTime <= 0 || o.reversalTime > 20) fail('EXPERIMENT_PARAMETERS');
    const a = config.schema === 'hard-disk/v1' ? HardDiskEngine.restore(config) : new HardDiskEngine(config);
    this.#source = freeze(a.snapshot()); this.units = modelUnits(this.#source);
    if (!Number.isSafeInteger(o.particle) || o.particle < 0 || o.particle >= this.#source.particles.length) fail('EXPERIMENT_PARTICLE_INDEX');
    this.engines = { A: a }; this.intervention = null;
    if (o.mode === 'chaos') { const p = perturbPosition(this.#source, o.particle, o.delta, o.direction); this.engines.B = p.engine; this.intervention = p.intervention; }
    else this.#reference = new ForwardReference(a.state());
    this.phase = o.mode === 'chaos' ? 'chaos' : 'forward'; this.origin = a.time; this.commonTime = a.time;
    this.requestedForkTime = this.origin + o.reversalTime * this.units.time; this.actualForkTime = this.requestedForkTime;
    this.interval = o.sampleInterval * this.units.time; this.tick = 1; this.postTick = 1;
    this.pendingTarget = null; this.cursor = 0; this.complete = false; this.lastError = null;
    this.reliability = { threshold: REVERSAL_TOLERANCE, firstExceededTime: null, trustworthy: true, reasons: [] };
    this.last = this.observe(); this.#history.push(this.last.point);
  }
  sourceSnapshot() { return clone(this.#source); }
  forkSnapshot() { return this.#forkSource ? clone(this.#forkSource) : null; }
  referenceAt(time) { if (!this.#reference) fail('REFERENCE_UNAVAILABLE'); return this.#reference.at(time); }
  history() { return this.#history.toArray(); }
  planTarget() {
    if (this.phase === 'forward') return Math.min(this.origin + this.tick * this.interval, this.actualForkTime);
    if (this.phase === 'reversed') return Math.min(this.actualForkTime + this.postTick * this.interval, 2 * this.actualForkTime - this.origin);
    return this.origin + this.tick * this.interval;
  }
  fork() {
    const source = this.engines.A.snapshot(), a = HardDiskEngine.restore(source), b = HardDiskEngine.restore(source), c = HardDiskEngine.restore(source);
    try { b.reverseVelocities(); c.reverseVelocities(); }
    catch (e) {
      if (e.code !== 'REVERSAL_AT_COLLISION') throw e;
      this.actualForkTime = source.time + Math.max(1e-9 * this.units.time, 8 * this.engines.A.timeTolerance(source.time));
      return false; // explicitly move the requested instant, then physically advance A
    }
    const rotated = rotateVelocity(c, this.options.particle, this.options.angle);
    this.#forkSource = freeze(source); this.engines = { A: a, B: b, C: rotated.engine }; this.intervention = rotated.intervention;
    this.phase = 'reversed'; this.postTick = 1; return true;
  }
  advanceBatch({ maxEvents = 500, maxMillis = 4, now = () => performance.now() } = {}) {
    if (this.lastError) fail('EXPERIMENT_HALTED', this.lastError);
    if (this.complete) return { reached: true, complete: true, processed: 0 };
    if (!Number.isSafeInteger(maxEvents) || maxEvents < 1 || maxEvents > 500 || maxMillis <= 0) fail('EXPERIMENT_BATCH');
    if (this.pendingTarget === null) { this.pendingTarget = this.planTarget(); this.cursor = 0; }
    const start = now(); let processed = 0;
    try {
      const keys = Object.keys(this.engines);
      while (this.cursor < keys.length && processed < maxEvents && now() - start < maxMillis) {
        const key = keys[this.cursor], engine = this.engines[key], next = engine.nextEvent();
        if (next && next.time <= this.pendingTarget) {
          if (this.phase === 'forward') this.#reference.ensureCapacity();
          if (this.options.validateEveryEvent) engine.audit();
          const event = engine.step(); processed++;
          if (this.options.validateEveryEvent) engine.audit();
          if (this.phase === 'forward') this.#reference.record(event, engine.state());
        } else {
          engine.advanceTo(this.pendingTarget, 0);
          if (this.phase === 'forward') this.#reference.maxTime = engine.time;
          this.cursor++;
        }
      }
      if (this.cursor !== keys.length) return { reached: false, complete: false, processed };
      this.commonTime = this.pendingTarget; this.pendingTarget = null; this.cursor = 0;
      if (this.phase === 'forward' && this.commonTime === this.actualForkTime) this.fork();
      while (this.origin + this.tick * this.interval <= this.commonTime) this.tick++;
      if (this.phase === 'reversed' && this.commonTime > this.actualForkTime) this.postTick++;
      this.complete = this.phase === 'reversed' && this.commonTime === 2 * this.actualForkTime - this.origin;
      this.last = this.observe(); this.#history.push(this.last.point);
      return { reached: true, complete: this.complete, processed };
    } catch (e) { this.lastError = { code: e.code ?? 'EXPERIMENT_INTERNAL', message: e.message, time: this.commonTime }; throw e; }
  }
  /** Read-only calculations happen only after the synchronization barrier. */
  observe() {
    const states = Object.fromEntries(Object.entries(this.engines).map(([key, e]) => [key, e.state()]));
    const audits = Object.fromEntries(Object.entries(this.engines).map(([key, e]) => [key, e.audit()]));
    if (Object.values(states).some(s => s.time !== this.commonTime)) fail('EXPERIMENT_UNSYNCHRONIZED');
    const entropy = Object.fromEntries(Object.entries(states).map(([key, s]) => [key, spatialStatistics(s).entropy]));
    let comparison = null, referenceEntropy = null, referenceAmbiguous = false;
    if (this.options.mode === 'chaos') comparison = { AB: deviations(states.A, states.B, this.units) };
    else if (this.phase === 'reversed') {
      // Exact endpoint identities avoid subtractive roundoff below a nonzero origin.
      // Only the comparison query changes; physical time/state is never adjusted.
      const referenceTime = this.commonTime === this.actualForkTime ? this.actualForkTime :
        this.commonTime === 2 * this.actualForkTime - this.origin ? this.origin : 2 * this.actualForkTime - this.commonTime;
      const reference = this.#reference.at(referenceTime);
      referenceAmbiguous = reference.collisionAmbiguous; referenceEntropy = spatialStatistics(reference).entropy;
      const B = deviations(states.B, reference, this.units, true), C = deviations(states.C, reference, this.units, true);
      if (referenceAmbiguous) { B.velocity = B.normalizedVelocity = B.phase = null; C.velocity = C.normalizedVelocity = C.phase = null; }
      comparison = { B, C, referenceTime, referenceAmbiguous };
      const reasons = [];
      if (B.normalizedPosition > REVERSAL_TOLERANCE || (!referenceAmbiguous && B.normalizedVelocity > REVERSAL_TOLERANCE)) reasons.push('B_BASELINE_THRESHOLD_EXCEEDED');
      if (['STABILIZATION_COLLISION', 'GRAZING', 'NUMERICAL_GRAZING_AMBIGUITY'].some(code => states.B.diagnostics.counts[code])) reasons.push('B_DEGENERATE_OR_STABILIZED');
      if (reasons.length) {
        this.reliability.trustworthy = false;
        if (this.reliability.firstExceededTime === null) this.reliability.firstExceededTime = this.commonTime;
        this.reliability.reasons = [...new Set([...this.reliability.reasons, ...reasons])];
      }
    }
    const point = { time: this.commonTime, AEntropy: entropy.A, BEntropy: entropy.B ?? null, CEntropy: entropy.C ?? null, referenceEntropy,
      dx: comparison?.AB?.normalizedPosition ?? null, dv: comparison?.AB?.normalizedVelocity ?? null, phase: comparison?.AB?.phase ?? null,
      BPosition: comparison?.B?.normalizedPosition ?? null, BVelocity: comparison?.B?.normalizedVelocity ?? null,
      CPosition: comparison?.C?.normalizedPosition ?? null, CVelocity: comparison?.C?.normalizedVelocity ?? null, referenceAmbiguous };
    return { mode: this.options.mode, time: this.commonTime, phase: this.phase, states, audits, entropy, comparison, point,
      requestedForkTime: this.requestedForkTime, actualForkTime: this.actualForkTime, units: { ...this.units },
      intervention: clone(this.intervention), reliability: clone(this.reliability), complete: this.complete };
  }
  snapshot() {
    return clone({ schema: EXPERIMENT_SCHEMA, experimentVersion: EXPERIMENT_VERSION, options: this.options, initial: this.#source,
      engines: Object.fromEntries(Object.entries(this.engines).map(([key, e]) => [key, e.snapshot()])), forkSource: this.#forkSource,
      reference: this.#reference?.snapshot() ?? null, phase: this.phase, origin: this.origin, commonTime: this.commonTime,
      requestedForkTime: this.requestedForkTime, actualForkTime: this.actualForkTime, tick: this.tick, postTick: this.postTick,
      pendingTarget: this.pendingTarget, cursor: this.cursor, complete: this.complete, lastError: this.lastError,
      reliability: this.reliability, intervention: this.intervention, history: this.history(), historyDropped: this.#history.dropped, last: this.last });
  }
  static restore(snapshot) {
    if (snapshot.schema !== EXPERIMENT_SCHEMA || snapshot.experimentVersion !== EXPERIMENT_VERSION) fail('EXPERIMENT_SNAPSHOT_SCHEMA');
    const s = clone(snapshot); if (s.history.length > 4096) fail('EXPERIMENT_SNAPSHOT_HISTORY');
    const session = new ExperimentSession(s.initial, s.options);
    session.engines = Object.fromEntries(Object.entries(s.engines).map(([key, p]) => [key, HardDiskEngine.restore(p)]));
    const expected = s.options.mode === 'chaos' ? 'A,B' : s.phase === 'reversed' ? 'A,B,C' : 'A';
    if (Object.keys(session.engines).join(',') !== expected) fail('EXPERIMENT_SNAPSHOT_BRANCHES');
    for (const field of ['origin', 'commonTime', 'requestedForkTime', 'actualForkTime', 'tick', 'postTick', 'cursor']) finite(s[field]);
    if (s.pendingTarget !== null) finite(s.pendingTarget);
    if (s.cursor < 0 || s.cursor >= Object.keys(s.engines).length || !Number.isSafeInteger(s.tick) || s.tick < 1 || !Number.isSafeInteger(s.postTick) || s.postTick < 1) fail('EXPERIMENT_SNAPSHOT_SCHEDULER');
    for (const field of ['phase', 'origin', 'commonTime', 'requestedForkTime', 'actualForkTime', 'tick', 'postTick', 'pendingTarget', 'cursor', 'complete', 'lastError', 'reliability', 'intervention', 'last']) session[field] = s[field];
    session.#forkSource = s.forkSource ? freeze(s.forkSource) : null;
    session.#reference = s.reference ? ForwardReference.restore(s.reference) : null;
    session.#history.clear(); s.history.forEach(p => session.#history.push(p)); session.#history.dropped = s.historyDropped;
    return session;
  }
}
