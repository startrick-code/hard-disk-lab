import {ConsoleRun,preparedObservers,exportManifest,streamBundle} from './console-runtime.js';
import {validateConfig} from './experiment-config.js';
const consoleRun=new ConsoleRun();let bundleBusy=false,stepOnce=false;
import { streamD3Export } from './d3-reference.js';
import { CorrelationController } from './correlations.js';
let correlations = new CorrelationController();
function bindCorrelation() { correlations.bind(session?.engines[selected], selected, session?.phase); }
import { ExperimentSession, EXPERIMENT_SCHEMA } from './experiments.js';
import { createModel } from './model.js';
import { sampleStatistics } from './statistics.js';

let session, running = false, timer = null, speed = 0.25, selected = 'A', statisticsEnabled = true;
function stop() { running = false; clearTimeout(timer); timer = null; }
function packet(type = 'state', extra = {}) {
  const view = session?.last;
  if (view && !view.states[selected]) selected = 'A';
  const state = view?.states[selected], engine = session?.engines[selected];
  const statistics = state && statisticsEnabled && type !== 'error' ? sampleStatistics(state, engine.initialEnergy, engine.geometryTolerance) : null;
  postMessage({ type, console:engine?consoleRun.view(engine,correlations,session.options.mode,session.options,speed,running):null, correlations: correlations.view(state), state, statistics, statisticsEnabled, running, selected, experiment: view,
    pendingTarget: session?.pendingTarget, complete: session?.complete, experimentHalted: session?.lastError, sampleRecord: type === 'sample' && statistics ?
      { time: state.time, entropy: statistics.spatial.entropy, collisions: state.collisions, energyError: state.signedEnergyError } : null, ...extra });
}
function selectedHistory() {
  return session.history().filter(p => p[`${selected}Entropy`] !== null && p[`${selected}Entropy`] !== undefined)
    .map(p => ({ time: p.time, entropy: p[`${selected}Entropy`] }));
}
function saved() { return { ...session.snapshot(), correlations: correlations.snapshot(), ...(consoleRun.config?{consoleSession:consoleRun.snapshot()}:{}), view: { selected, statisticsEnabled, playbackSpeed: speed } }; }
function pump() {
  if (!running || !session) return;
  const start = performance.now();
  try {
    bindCorrelation(); const result = session.advanceBatch(); bindCorrelation();
    if (result.reached) { correlations.sample(session.last.states[selected]);
      if (result.complete||consoleRun.check(session.engines[selected],correlations)) stop();
      packet('sample', { experimentPoint: session.last.point });
      if (running) timer = setTimeout(pump, Math.max(0, session.interval / speed * 1000 - (performance.now() - start)));
    } else timer = setTimeout(pump, 0);
  } catch (error) { stop(); packet('error', { error: { code: error.code, message: error.message, details: error.details }, snapshot: session.snapshot() }); }
}
onmessage = ({ data }) => {
  if(bundleBusy&&data.type!=='pause'){postMessage({type:'bundle-busy'});return;}
  try {
    if(['d3-clear','d2-clear','tv-history-clear','flux-reference','d2-recording','d3-recording','correlations','branch','reverse','rebase'].includes(data.type))consoleRun.note(data.type,session?.commonTime??0);
    switch (data.type) {
      case 'prepare-experiment': {
        stop();const config=validateConfig(data.config);if(config.dynamics==='single')throw Error('请选择单系统Worker');
        const nextSession=new ExperimentSession(createModel(config.seed,config.count,config.preset),config.options);
        const nextObservers=preparedObservers(nextSession.engines.A,config,'A',nextSession.phase);
        correlations.detach?.();session=nextSession;correlations=nextObservers;selected='A';speed=config.speed;statisticsEnabled=true;
        consoleRun.begin(config,data.runId,session.engines.A,correlations);packet('ready',{prepared:true,requestId:data.requestId,history:selectedHistory(),experimentHistory:session.history()});break;
      }
      case 'console-step': onmessage({data:{type:'step'}});break;
      case 'bundle-export': {
        stop();packet('status');bundleBusy=true;
        const view=consoleRun.view(session.engines[selected],correlations,session.options.mode,session.options,speed,running);
        streamBundle(correlations,exportManifest(view,correlations,data.selection),m=>postMessage(m),()=>{bundleBusy=false;});break;
      }

      case 'init':
        stop(); consoleRun.legacy(); session = new ExperimentSession(createModel(data.seed, data.count, data.preset), data.options);
        statisticsEnabled = data.statistics !== false; selected = 'A'; correlations.reset(); bindCorrelation();
        packet('ready', { requestId: data.requestId, history: selectedHistory(), experimentHistory: session.history() }); break;
      case 'play': if(consoleRun.outcome&&consoleRun.config){consoleRun.note('resume_as_manual',session.commonTime);consoleRun.config.stop.kind='manual';consoleRun.outcome=null;} if (!running && !session.complete && !session.lastError) { running = true; packet('status'); pump(); } break;
      case 'pause': stop(); packet('status'); break;
      case 'step': // One synchronized sampling interval; never display partially advanced branches.
        stop(); running = true; const runOne = () => {
          try { bindCorrelation(); const r = session.advanceBatch(); bindCorrelation(); if (!r.reached) timer = setTimeout(runOne, 0); else { correlations.sample(session.last.states[selected]); consoleRun.check(session.engines[selected],correlations); stop(); packet('sample', { experimentPoint: session.last.point }); } }
          catch (e) { stop(); packet('error', { error: { code: e.code, message: e.message }, snapshot: session.snapshot() }); }
        }; runOne(); break;
      case 'speed':
        if (!Number.isFinite(data.value) || data.value <= 0 || data.value > 2) throw Error('Invalid playback speed'); speed = data.value; break;
      case 'branch':
        if (!session.last.states[data.branch]) throw Error('Branch has not been created'); selected = data.branch; bindCorrelation();
        packet('branch', { history: selectedHistory() }); break;
      case 'd3-recording': correlations.enableD3(data.enabled); packet('correlations'); break;
      case 'd3-clear': correlations.d3.clear(); packet('correlations'); break;
      case 'd3-export': streamD3Export(correlations.d3); break;
      case 'd2-recording': if(data.enabled && !correlations.enabled)correlations.set(true); bindCorrelation(); correlations.enableD2(data.enabled); packet('correlations'); break;
      case 'd2-clear': correlations.clearD2(); packet('correlations'); break;
      case 'd2-analysis': correlations.d2.refresh(session.commonTime,true,data.selection); packet('correlations'); break;
      case 'd2-export': postMessage({type:'d2-export',csv:correlations.d2.csv()}); break;
      case 'tv-history-clear': correlations.tvHistory.clear(); packet('correlations'); break;
      case 'tv-history-recording': correlations.tvHistory.setEnabled(data.enabled); packet('correlations'); break;
      case 'flux-reference': if(data.enabled && !correlations.enabled)correlations.set(true); bindCorrelation(); correlations.enableFlux(data.enabled, data.options); packet('correlations'); break;
      case 'correlations': correlations.set(data.enabled === true, data.window); bindCorrelation(); packet('correlations'); break;
      case 'statistics': statisticsEnabled = data.enabled !== false; packet('statistics', { history: selectedHistory() }); break;
      case 'snapshot': packet('snapshot', { snapshot: saved() }); break;
      case 'restore':
        if (data.snapshot.schema !== EXPERIMENT_SCHEMA) throw Error('Load a multi-system experiment snapshot in this mode');
        stop(); consoleRun.restore(data.snapshot.consoleSession); session = ExperimentSession.restore(data.snapshot); selected = data.snapshot.view?.selected ?? 'A';
        if (data.snapshot.view) {
          statisticsEnabled = data.snapshot.view.statisticsEnabled !== false;
          const savedSpeed = data.snapshot.view.playbackSpeed;
          if (!Number.isFinite(savedSpeed) || savedSpeed <= 0 || savedSpeed > 2) throw Error('Invalid saved playback speed');
          speed = savedSpeed;
        }
        correlations.restore(data.snapshot.correlations, session.engines[selected], selected, session.phase);
        packet('ready', { requestId: data.requestId, history: selectedHistory(), experimentHistory: session.history() }); break;
      case 'audit': packet('audit', { audit: Object.fromEntries(Object.entries(session.engines).map(([k, e]) => [k, e.audit()])) }); break;
      case 'experiment-history': packet('experiment-history', { experimentHistory: session.history(), snapshot: session.snapshot() }); break;
      case 'reverse': case 'rebase': throw Error('Use the original single-system debug mode for manual interventions');
    }
  } catch (error) { stop(); packet('error', { error: { code: error.code, message: error.message, details: error.details }, snapshot: session?.snapshot() }); }
};
