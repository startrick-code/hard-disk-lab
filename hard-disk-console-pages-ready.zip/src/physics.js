export const DEFAULT_TOLERANCES = Object.freeze({ position: 1e-12, significantPenetration: 1e-10, discriminantUlps: 64, timeUlps: 64, conservationUlps: 4096 });
export class PhysicsError extends Error {
  constructor(code, details = {}) { super(code); this.name = 'PhysicsError'; this.code = code; this.details = details; }
}
export function finite(...values) {
  if (!values.every(Number.isFinite)) throw new PhysicsError('FLOAT_NONFINITE', { values });
}
export function positionAt(p, time) {
  const dt = time - p.at;
  const x = p.x + p.vx * dt, y = p.y + p.vy * dt;
  finite(dt, x, y); return { x, y };
}
export function energy(particles) {
  let sum = 0, correction = 0;
  for (const p of particles) {
    const value = 0.5 * p.mass * (p.vx * p.vx + p.vy * p.vy);
    finite(value);
    const next = value - correction, total = sum + next;
    correction = (total - sum) - next; sum = total;
  }
  finite(sum); return sum;
}
/** r = r_i-r_j, u = v_i-v_j; a*t²+2b*t+c=0. Scale u to avoid v² overflow. */
export function pairDelay(p, q, time, geometryTolerance, diagnose = () => {}, discriminantUlps = 64) {
  const aPos = positionAt(p, time), bPos = positionAt(q, time);
  const rx = aPos.x - bPos.x, ry = aPos.y - bPos.y;
  const ux = p.vx - q.vx, uy = p.vy - q.vy, radius = p.radius + q.radius;
  const distance = Math.hypot(rx, ry), gap = distance - radius;
  finite(rx, ry, ux, uy, radius, distance);
  if (gap < -geometryTolerance) throw new PhysicsError('OVERLAP', { gap });
  if (gap < 0) diagnose('NUMERICAL_OVERLAP', { gap });
  const scale = Math.max(Math.abs(ux), Math.abs(uy));
  if (scale === 0) {
    if (Math.abs(gap) <= geometryTolerance) diagnose('RESTING_CONTACT', { gap });
    return null;
  }
  const sx = ux / scale, sy = uy / scale;
  const a = sx * sx + sy * sy, b = rx * sx + ry * sy;
  const cross = rx * sy - ry * sx;
  const d = a * radius * radius - cross * cross;
  finite(a, b, cross, d);
  if (b >= 0) return null;
  const dTolerance = discriminantUlps * Number.EPSILON * (b * b + a * (distance * distance + radius * radius));
  finite(dTolerance);
  if (d !== 0 && Math.abs(d) <= dTolerance) {
    // Independent closest-approach geometric check. It does not flip the sign of D.
    const closestGap = Math.abs(cross) / Math.sqrt(a) - radius;
    const geometricUncertainty = discriminantUlps * Number.EPSILON * Math.max(distance, radius);
    if (Math.abs(closestGap) <= geometricUncertainty) throw new PhysicsError('NUMERICAL_GRAZING_AMBIGUITY', { discriminant: d, discriminantTolerance: dTolerance, closestGap });
    diagnose('NEAR_GRAZING_RESOLVED', { discriminant: d, closestGap });
  }
  if (d < 0) {
    if (d >= -dTolerance) diagnose('NEAR_GRAZING_MISS', { discriminant: d });
    return null;
  }
  if (d === 0) { diagnose('GRAZING', { discriminant: d }); return null; }
  // Only a within-tolerance negative gap is treated as an explicitly logged zero-time contact.
  const c = gap * (distance + radius);
  const delay = gap < 0 ? 0 : (c / (-b + Math.sqrt(d))) / scale;
  if (gap < 0) diagnose('STABILIZATION_COLLISION', { gap });
  finite(c, delay);
  if (delay < 0) throw new PhysicsError('NEGATIVE_TIME', { delay });
  if (gap > 0 && delay === 0) throw new PhysicsError('TIME_UNDERFLOW', { gap, scale });
  return delay;
}
export function wallDelay(p, axis, side, box, time, tolerance, diagnose = () => {}) {
  const pos = positionAt(p, time), v = axis === 'x' ? p.vx : p.vy;
  const gap = side === 0 ? pos[axis] - p.radius : box[axis] - p.radius - pos[axis];
  finite(gap);
  if (gap < -tolerance) throw new PhysicsError('OUTSIDE_BOX', { axis, side, gap });
  if (gap < 0) diagnose('NUMERICAL_WALL_OVERLAP', { axis, side, gap });
  if (side === 0 ? v >= 0 : v <= 0) return null;
  const delay = Math.max(0, gap) / Math.abs(v);
  finite(delay);
  if (gap > 0 && delay === 0) throw new PhysicsError('TIME_UNDERFLOW', { gap, v });
  return delay;
}
export function elasticPair(p, q, time, tolerance) {
  const rp = positionAt(p, time), rq = positionAt(q, time);
  const dx = rp.x - rq.x, dy = rp.y - rq.y, d = Math.hypot(dx, dy);
  finite(d);
  if (d === 0 || Math.abs(d - p.radius - q.radius) > tolerance) {
    throw new PhysicsError('CONTACT_RESIDUAL', { distance: d, radius: p.radius + q.radius });
  }
  const nx = dx / d, ny = dy / d;
  const normalSpeed = (p.vx - q.vx) * nx + (p.vy - q.vy) * ny;
  finite(normalSpeed);
  if (normalSpeed >= 0) throw new PhysicsError('NON_APPROACHING_EVENT', { normalSpeed });
  const massSum = p.mass + q.mass;
  finite(massSum);
  const ip = 2 * (q.mass / massSum) * normalSpeed;
  const iq = 2 * (p.mass / massSum) * normalSpeed;
  const result = { p: { vx: p.vx - ip * nx, vy: p.vy - ip * ny },
    q: { vx: q.vx + iq * nx, vy: q.vy + iq * ny }, normal: { x: nx, y: ny }, normalSpeed };
  finite(result.p.vx, result.p.vy, result.q.vx, result.q.vy);
  return result;
}
