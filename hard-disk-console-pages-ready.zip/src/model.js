import { SeededRandom } from './random.js';

export const ENGINE_VERSION = '1.0.0-phase1';
/** Internal L0=V0=T0=m=1. Gaussian components; normalization only at initialization. */
export function createModel(seed = 1, count = 100, preset = 'uniform') {
  if (!Number.isInteger(count) || count < 50 || count > 200) throw new TypeError('N must be 50..200');
  if (!['uniform', 'left', 'mono-speed'].includes(preset)) throw new TypeError('Unknown preset');
  const box = { x: 1, y: 0.6 }, radius = Math.sqrt(0.01 * box.x * box.y / (count * Math.PI));
  const rng = new SeededRandom(seed), particles = [];
  let attempts = 0;
  while (particles.length < count) {
    if (++attempts > 1000000) throw new Error('INITIALIZATION_CAPACITY');
    const x = radius + ((preset === 'left' ? 0.5 : 1) - 2 * radius) * rng.next();
    const y = radius + (0.6 - 2 * radius) * rng.next();
    if (particles.some(p => Math.hypot(x - p.x, y - p.y) <= 2 * radius + 1e-12)) continue;
    let vx, vy;
    if (preset === 'mono-speed') {
      const angle = 2 * Math.PI * rng.next(); vx = Math.cos(angle); vy = Math.sin(angle);
    } else {
      const mag = Math.sqrt(-2 * Math.log(1 - rng.next())), angle = 2 * Math.PI * rng.next();
      vx = mag * Math.cos(angle); vy = mag * Math.sin(angle);
    }
    particles.push({ x, y, vx, vy, radius, mass: 1 });
  }
  const rms = Math.sqrt(particles.reduce((s, p) => s + p.vx * p.vx + p.vy * p.vy, 0) / count);
  for (const p of particles) { p.vx /= rms; p.vy /= rms; }
  return { box, particles, seed, rngState: rng.state, statisticalRngState: (seed ^ 0xA5A5A5A5) >>> 0,
    metadata: { preset, occupancy: 0.01, units: { length: 'L₀', speed: 'V₀', time: 'T₀', mass: 'm' },
      velocityNormalization: 'initial RMS to 1; no momentum constraint', placement: 'sequential rejection; not equilibrium ensemble sampling' } };
}
