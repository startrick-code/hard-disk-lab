/** Mulberry32: explicit serializable uint32 state, no Math.random. */
export class SeededRandom {
  constructor(seed) {
    if (!Number.isInteger(seed) || seed < 0 || seed > 0xffffffff) throw new TypeError('Seed must be uint32');
    this.state = seed >>> 0;
  }
  next() {
    this.state = (this.state + 0x6D2B79F5) >>> 0;
    let t = this.state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
}
export function createGas(seed = 1, count = 24, size = 20, radius = 0.35) {
  if (!Number.isInteger(count) || count < 1 || !Number.isFinite(size) || !Number.isFinite(radius) || radius <= 0 || size <= 2 * radius) throw new TypeError('Invalid gas parameters');
  const rng = new SeededRandom(seed), particles = [];
  let attempts = 0;
  while (particles.length < count) {
    if (++attempts > 100000) throw new Error('INITIALIZATION_CAPACITY');
    const x = radius + (size - 2 * radius) * rng.next(), y = radius + (size - 2 * radius) * rng.next();
    if (particles.some(p => Math.hypot(x - p.x, y - p.y) <= 2 * radius + 1e-8 * size)) continue;
    const angle = 2 * Math.PI * rng.next(), speed = 0.5 + rng.next();
    particles.push({ x, y, vx: speed * Math.cos(angle), vy: speed * Math.sin(angle), radius, mass: 1 });
  }
  return { box: { x: size, y: size }, particles, seed, rngState: rng.state };
}
