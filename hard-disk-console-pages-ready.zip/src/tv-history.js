/** Stores already-computed complete D1 windows. No physics, sampling or RNG imports. */
const copy=x=>structuredClone(x);
export const TV_CAPACITY=200;
export class TVHistory {
  constructor(){this.records=[];this.active=null;this.current=null;this.sequence=0;this.nextNumber=1;this.lastEnd=null;this.dropped=0;this.enabled=true;this.revision=0;}
  begin(context){this.active={...copy(context),group:++this.sequence};this.current=null;this.lastEnd=null;this.revision++;return this.active.group;}
  append(result,group=this.active?.group){
    if(!result?.complete||result.through!==result.end||group!==this.active?.group||!(result.end>result.start)||this.lastEnd!==null&&result.end<=this.lastEnd)return false;
    const context=this.active;
    if(result.metadata.branch!==context.branch||result.metadata.experiment!==context.epoch||JSON.stringify(result.options)!==JSON.stringify(context.options))return false;
    const d=result.distributions;
    const record={number:null,group,start:result.start,end:result.end,branch:context.branch,epoch:context.epoch,
      tv:result.totalVariation,collisions:d.actual.n,ess:d.flux.ess,status:result.status,
      insufficient:result.status==='不足以判断'||result.totalVariation===null,
      particles:context.particles,seed:context.seed,preset:context.preset,options:copy(result.options),
      real:copy(d.actual.probability),reference:copy(d.flux.probability),difference:copy(result.difference),
      counts:copy(result.counts),proposals:Object.fromEntries(['global','geometry','incoming','flux'].map(k=>[k,d[k].proposals]))};
    this.lastEnd=result.end;this.current=copy(record);this.revision++;
    if(!this.enabled)return false;
    record.number=this.nextNumber++;this.current=copy(record);this.records.push(record);
    if(this.records.length>TV_CAPACITY){this.records.shift();this.dropped++;}return true;
  }
  clear(){this.records=[];this.dropped=0;this.revision++;} // Keep completed-window watermark and current summary.
  setEnabled(enabled){this.enabled=enabled===true;this.revision++;}
  view(){return copy({records:this.records,current:this.current,active:this.active,enabled:this.enabled,dropped:this.dropped,capacity:TV_CAPACITY,revision:this.revision});}
  snapshot(){return copy({schema:'d1-tv/v1',...this.view(),sequence:this.sequence,nextNumber:this.nextNumber,lastEnd:this.lastEnd});}
  static restore(s){
    if(s?.schema!=='d1-tv/v1'||!Array.isArray(s.records)||s.records.length>TV_CAPACITY||!Number.isSafeInteger(s.sequence)||!Number.isSafeInteger(s.nextNumber)||!Number.isSafeInteger(s.dropped)||s.dropped<0)throw Error('INVALID_TV_SNAPSHOT');
    const h=new TVHistory();for(const k of ['records','current','active','enabled','dropped','revision','sequence','nextNumber','lastEnd'])h[k]=copy(s[k]);return h;
  }
}
export function selectTVRecords(records,{branch='all',sort='time',direction='desc'}={}){
  const field={time:'end',tv:'tv',collisions:'collisions',ess:'ess'}[sort]??'end',sign=direction==='asc'?1:-1;
  return records.filter(r=>branch==='all'||r.branch===branch).slice().sort((a,b)=>{
    if(a[field]===null&&b[field]!==null)return 1;if(b[field]===null&&a[field]!==null)return -1;
    return sign*((a[field]??0)-(b[field]??0))||a.number-b.number;
  });
}
export function tvSegments(records){const groups=new Map();for(const r of records){if(!groups.has(r.group))groups.set(r.group,[]);groups.get(r.group).push(r);}return [...groups.values()].map(rs=>rs.sort((a,b)=>a.end-b.end));}
export function tvCSV(records){
  const columns=['number','start','end','branch','epoch','group','tv','collisions','ess','status','particles','seed','preset','region','grid','window','proposalsPerSample',...['real','reference','difference'].flatMap(k=>['00','01','10','11'].map(b=>`${k}_${b}`)),...['global','geometry','incoming','flux'].map(k=>`proposals_${k}`),'proposed','regionCandidates','wallRejected','emptyPool','validGeometry','incomingCandidates','smallPool'];
  const quote=v=>`"${String(v??'').replaceAll('"','""')}"`;
  const rows=records.map(r=>[r.number,r.start,r.end,r.branch,r.epoch,r.group,r.tv,r.collisions,r.ess,r.status,r.particles,r.seed,r.preset,r.options.region,r.options.grid,r.options.window,r.options.proposals,...['real','reference','difference'].flatMap(k=>r[k]??[null,null,null,null]),...['global','geometry','incoming','flux'].map(k=>r.proposals[k]),r.counts.proposed,r.counts.region,r.counts.wallRejected,r.counts.emptyPool,r.counts.geometry,r.counts.incoming,r.counts.smallPool]);
  return '\uFEFF'+[columns,...rows].map(row=>row.map(quote).join(',')).join('\r\n')+'\r\n';
}
